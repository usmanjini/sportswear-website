<section class="banner_section">
        <div class="container-fluid">
            <div class="row ">
        
                <div class="col-12">
                
                   <div class="banner_conteiner" style="background-image:url(uploads/SOCCER.jpg);">
                       <div class="banner_text">
                           <h1 style="color:#FFF;">American football <br>Uniforms</h1>
                            <p style="color:#FFF;">Quality Range of American Football Uniforms</p>
                            <a style="color:#FFF;" href="http://loviaal.com/Sports-Uniforms/American-Football-Uniform/92-52-0/page=1">View Now</a>
                        </div>
                   </div>
                 </div>
               
                
            </div>
        </div>
    </section>