

<?php 



 require_once("config.php");

echo	$id = $_REQUEST["id"]."";

echo	$qty = $_REQUEST["qty"]."";

echo	$sizeraw = $_REQUEST["size"]."";

echo	$colorraw = $_REQUEST["color"]."";



/*	$size_idx = explode("-",$sizeraw );

	$size_Name = getProductsSizeName($size_idx[0]);

	$size_id=$size_idx[0];	

	$color_id = $_REQUEST["color_id"]."";

	$color_Name = getProductsColorName($color_id);

	$price=$size_idx[1];

	$final_price= $qty * $price;*/







//echo $id;exit;

if (trim($qty)==""){

	$qty = 10;

}



$sql = "SELECT * FROM tbl_basket WHERE product_id = '".$id."' AND sid = '".$sId."' AND inquiry_no = 0";	

$qry1 = mysql_query($sql) or die(mysql_error());





if (mysql_num_rows($qry1)==0){

	 mysql_query("INSERT INTO tbl_basket (product_id,sid,qty,size_name,color_name) VALUES ('".$id."','".$sId."','".$qty."','".$sizeraw."','".$colorraw."')") or die(mysql_error());

		

}else{

	$fld= mysql_fetch_array($qry1);



	mysql_query("UPDATE tbl_basket SET qty = ".$qty." WHERE product_id='".$id."' AND sid = '".$sId."' AND inquiry_no = 0") or die(mysql_error());

}



echo "<script>window.top.location='http://loviaal.com/basket'</script>";

exit;

?>