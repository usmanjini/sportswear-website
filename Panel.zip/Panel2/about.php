<?php require_once("config.php");
$dynamicsID="2";

$Pagename = "About Us";
$page_name= "About Us | ".$web_title."";

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
     <title><?=$page_name?></title>
    <?php if ($meta==1){?>
    <meta name="description" content="<?=$seo_desc?>">
     <?php }?>
   <?php include("css-inc.php");?>
  
</head>

<body>

<!-- Main Wrapper Start -->
    <!--header area start-->
    <?php include("header-inc.php");?>
    <!--header area end-->
 
    <!--breadcrumbs area start-->
    
    <!--breadcrumbs area end-->
    
        <!--about section area -->
    <div class="about_section">
        <div class="container">  
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="about_content">
                    
                        <h1 align="center" style="margin-top:20px;">Welcome To Loviaal</h1>
                        <p>  <?=dynamics($dynamicsID);?></p>
                      
                          
                    </div>
                </div>
                
            </div>
        </div>     
    </div>
    <!--about section end-->


    <!--counterup area -->
    
    <!--counterup end-->

    <!--about progress bar -->
    
    <!--about progress bar end -->
    
    
       <!--footer area start-->
    <?php include("footer-inc.php");?>
    <!--footer area end-->


<!-- JS
============================================ -->

<!-- Plugins JS -->
<script src="assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>



</body>

</html>