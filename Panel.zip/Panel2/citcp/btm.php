<link rel="stylesheet" type="text/css" href="styles.css">
<table width="755" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="1"><img src="img/spacer.gif" width="1" height="1"></td>
  </tr>
  <tr> 
    <td height="28" align="center" bgcolor="1C5A8D"><table width="96%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="lbtm">&copy; Copyrights 2010 - 11 All rights reserved by: <span class="lbtm2">
            <?=$Company?>
            </span></td>
          <td align="right" class="lbtm">Designed &amp; Developed by: <span class="lbtm2"><a href="<?=$owner_email?>" target="_blank" class="lbtm2"><?=$owner?></a></span></td>
        </tr>
      </table></td>
  </tr>
</table>
