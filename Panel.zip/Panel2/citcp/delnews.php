<?
require("connection.php");
require("chksession.php");
if($_REQUEST["RecID"]){
$qry=mysql_query("delete from tbl_news where recid='".$_REQUEST["RecID"]."'") or die("Invalid Values: " . mysql_error());
$qryRank=mysql_query("select * from tbl_news order by rank") or die("Invalid Sql: " . mysql_error());
	if($qryRank){
		$rows=mysql_num_rows($qryRank);
			if($rows>0){
				for($i=1;$i<=$rows;$i++){
					$data=mysql_fetch_row($qryRank);
					$qry=mysql_query("update tbl_news set Rank='".$i."' where recid='".$data[0]."'") or die("Invalid Values: " . mysql_error());
				}
			}
	}
}
header('Location:mnews.php#n');
?>