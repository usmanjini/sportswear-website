<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
if($_REQUEST["MainID"]){
$qrychk=mysql_query("select * from tbl_sub where MainID='".$_REQUEST["MainID"]."'") or die(mysql_error());
$chkrows=mysql_num_rows($qrychk);
$qrypchk=mysql_query("select * from tbl_items where MainID='".$_REQUEST["MainID"]."'") or die(mysql_error());
$chkprows=mysql_num_rows($qrypchk);
if($chkrows>0){
	header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID.'&mess=Main+Category+cannot+be+deleted+because+it+contains+sub+categories');
}else if($chkprows>0){
	header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID.'&mess=Main+Category+cannot+be+deleted+because+it+contains+products');
}else{
$qry=mysql_query("select MainImg from tbl_main where Mainid='".$_REQUEST["MainID"]."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){
	$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$imgdel=$mainimgs.$data[0];
	}
}
$qry=mysql_query("delete from tbl_main where MainId='".$_REQUEST["MainID"]."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){

	if (file_exists($imgdel)){
		unlink($imgdel);
	}
}
$qryRank=mysql_query("select * from tbl_main where SecID='".$SecID."' and MSecID='".$MSecID."' order by rank") or die("Invalid Sql: " . mysql_error());
	if($qryRank){
		$rows=mysql_num_rows($qryRank);
			if($rows>0){
				for($i=1;$i<=$rows;$i++){
					$data=mysql_fetch_row($qryRank);
					$qry=mysql_query("update tbl_main set Rank='".$i."' where MainID='".$data[3]."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
				}
			}
	}
	header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID.'&mess=Main+Category+deleted+successfully');
}
}
?>