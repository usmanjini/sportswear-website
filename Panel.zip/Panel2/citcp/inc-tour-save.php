<?php
if (isset($_POST['act'])){
	$pictup = $_POST["picup"]."";
	$dropoff = $_POST["dropoff"]."";
	$distance = $_POST["distance"]."";	
	$act = $_POST['act']."";
	if (trim($act)=="add"){
		$qryDup = mysql_query("SELECT * FROM tbl_tour_routes WHERE (picup_point = ".$pictup." AND drop_point = ".$dropoff.") OR (drop_point = ".$pictup." AND picup_point = ".$dropoff.")");
		$rcDup = mysql_num_rows($qryDup);
		mysql_free_result($qryDup);
		if ($rcDup==0){
			$sqlInsert = "INSERT INTO tbl_tour_routes (picup_point,drop_point,distance) VALUES (".$pictup.",".$dropoff.",".$distance.");";
			//echo $sqlInsert;exit;
			mysql_query($sqlInsert);
			header("location:tour-routes.php?msg=Record+saved+successfully");
			exit;
		}else if($rcDup==1){
			$msg = "You have already entered these point";
		}
	}
}

?>