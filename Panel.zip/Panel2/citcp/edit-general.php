<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
$qryG = mysql_query("SELECT * FROM tbl_general WHERE row_id = ".$_REQUEST['row_id']."");
$fldG = mysql_fetch_array($qryG);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('title').focus();
	}
	function chkFo(){
		var fld = document.getElementById('title');
		if (fld.value==""){
			alert('Please enter the title');
			fld.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="550" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              <?=$title?></td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="550" border="0" cellpadding="1" cellspacing="2">
                                <form action="update-gener.php?id=<?=$_REQUEST['id']?>&row_id=<?=$_REQUEST['row_id']?>" method="post" name="frmgen" onSubmit="return chkFo();" enctype="multipart/form-data">
<input type="hidden" id="ids" name="ids" value="<?=$_REQUEST['id']?>">                                
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="title" type="text" class="txtdefault" id="title" value="<?=$fldG['title'].""?>">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <? if ($link==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>link:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="link" type="text" class="txtdefault" id="link" value="<?=$fldG['link'].""?>">
                                      &nbsp;<font color="#FF0000">For example: http://www.domainname.com</font></td>
                                  </tr>                                                    
                                  <? } ?>   
                                  <? if ($detail_s==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Detail:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea name="detail1" cols="35" rows="4" class="txtnews1" id="detail1"><?=$fldG['detail_s'].""?></textarea></td>
                                  </tr>                  
                                  <? } ?> 
                                  <? if ($detail_l==true){?>
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg.js"></script> 
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script language="JavaScript">WYSIWYG.attach('pdetail');</script>                                   
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Full Detail:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea  name="pdetail" cols="50" rows="15" class="txt_id_sub" id="textarea"><?=$fldG['detail_l'].""?></textarea></td>
                                  </tr>                  
                                  <? } ?>                                                                                 
                                  <? if ($file1==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fldG['file1'].""?>" width="<?=$wfile1/2 ?>"></td>
                                  </tr>                                  
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
                                      <span class="error"><?=$wfile1?> x <?=$hfile1?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file2==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fldG['file2'].""?>" width="<?=$wfile2/2 ?>"></td>
                                  </tr>                                    
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file2" type="file" class="txtdefault" id="file2" style="width:200px;"/>
                                      <span class="error"><?=$wfile2?> x <?=$hfile2?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file3==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fldG['file3'].""?>" width="<?=$wfile3/2 ?>"></td>
                                  </tr>                                    
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file3" type="file" class="txtdefault" id="file3" style="width:200px;"/>
                                      <span class="error"><?=$wfile3?> x <?=$hfile3?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file4==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fldG['file4'].""?>" width="<?=$wfile4/2 ?>"></td>
                                  </tr>                                    
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file4" type="file" class="txtdefault" id="file4" style="width:200px;"/>
                                      <span class="error"><?=$wfile4?> x <?=$hfile4?></span></td>
                                  </tr>                                  <? } ?>                                                                    
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="submit" value="Save <?=$title?>" ></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>