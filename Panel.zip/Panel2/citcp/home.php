<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">

</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="90%" border="1" cellpadding="0" cellspacing="0" bordercolor="<?=$Clr1 ?>">
<form name="form1" id="form1" method="post" action="save_home.php">
<input type="hidden" value="<?=$_REQUEST["id"]?>" id="gen_id" name="gen_id">
                      <?
					  	$sql = "SELECT * FROM tbl_home WHERE gen_id = ".$_REQUEST["id"].";";
						$qry = mysql_query($sql);
						while ($fld = mysql_fetch_array($qry)){
                      ?>
                      
                          <tr>
                            <td width="25%" align="center" bgcolor="<?=$Clr1 ?>" class="mhead">&nbsp;</td> 
                            <td width="75%" height="23" align="center" bgcolor="<?=$Clr1 ?>" class="mhead"><?=$fld["title"].""?></td>
                          </tr>
                            <tr>
                              <td align="center" valign="middle" bgcolor="<?=$Clr3?>" class="menu"> Title(SEO)</td> 
                            <td height="43" align="left" valign="middle" bgcolor="<?=$Clr3?>" class="menu"><input name="seo_title" type="text"  id="seo_title" value="<?=$fld["seo_title"].""?>" size="40">
                                      &nbsp;<font color="#FF0000">*
                                     </td>
                          </tr>
                         
                             <tr>
                               <td align="center" valign="top" bgcolor="<?=$Clr3?>" class="menu"> Keywords(SEO)</td> 
                            <td height="20" align="left" valign="top" bgcolor="<?=$Clr3?>" class="menu"><textarea name="seo_keywords" cols="30" rows="10" class="txt_id_sub" id="seo_keywords"><?=$fld["seo_keywords"].""?></textarea></td>
                          </tr>
                             <tr>
                               <td align="center" valign="top" bgcolor="<?=$Clr3?>" class="menu">Description(SEO)</td> 
                            <td height="20" align="left" valign="top" bgcolor="<?=$Clr3?>" class="menu"><textarea name="seo_desc" cols="30" rows="10" class="txt_id_sub" id="seo_desc"><?=$fld["seo_desc"].""?></textarea></td>
                          </tr>
                          <tr>
                            <td align="left" valign="middle">&nbsp;</td> 
                            <td height="30" align="left" valign="middle"><input type="submit" value="Save <?=$fld["title"].""?>"></td>
                          </tr>
                      <?
					  }
                      ?>
                      </form>    
                      </table></td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>