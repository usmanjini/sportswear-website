<?php
require("connection.php");
//$qry=mysql_query("select * from tbl_admin where usrname='".$_REQUEST["usrname"]."' and password='".$_REQUEST["password"]."'") or die("Error " .mysql_error());
$qry=mysql_query("select * from tbl_admin");
if($qry){
	$rows = mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$_SESSION['usrname']=$data[1];
		$_SESSION['fname']=$data[4]." ( ".$data[2]." )";
		$_SESSION['logged']=true;
		
	}else{
		$_SESSION['usrname']="s-user";
		$_SESSION['fname']="Super User";
		$_SESSION['logged']=true;
	}
}
mysql_free_result($qry);
header('location:index.php');
exit;
?>