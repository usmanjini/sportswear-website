<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
$isSpecial=$_REQUEST["isSpecial"];
if($ItmID<>""){
if($isSpecial=="y"){
$qry=mysql_query("update tbl_items set isSpecial='y' where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
}elseif($isSpecial=="n"){
$qry=mysql_query("update tbl_items set isSpecial='n' where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
}
}
header('Location:mitem.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID.'&SubID='.$SubID.'&mess=Item+updated+successfully');
?>