<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
$id = $_REQUEST["id"];
mysql_query("DELETE FROM tbl_tour_routes WHERE row_id = ".$id."");
header("location:tour-routes.php");
exit;
?>