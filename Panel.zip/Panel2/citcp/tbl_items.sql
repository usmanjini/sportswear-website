/*
MySQL Data Transfer
Source Host: localhost
Source Database: db_soc
Target Host: localhost
Target Database: db_soc
Date: 5/5/2011 5:37:47 PM
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for tbl_items
-- ----------------------------
DROP TABLE IF EXISTS `tbl_items`;
CREATE TABLE `tbl_items` (
  `RecID` int(11) NOT NULL AUTO_INCREMENT,
  `MSecID` int(11) NOT NULL DEFAULT '0',
  `SecID` int(11) NOT NULL DEFAULT '0',
  `MainID` int(11) NOT NULL DEFAULT '0',
  `SubID` int(11) NOT NULL DEFAULT '0',
  `ItmID` int(11) NOT NULL DEFAULT '0',
  `ItmName` varchar(50) NOT NULL DEFAULT '',
  `ArtNo` varchar(100) NOT NULL DEFAULT '',
  `pSize` varchar(255) NOT NULL DEFAULT '0',
  `sOption` char(1) NOT NULL DEFAULT 'y',
  `ItmDescp` longtext NOT NULL,
  `ItmImg` varchar(50) NOT NULL DEFAULT '',
  `Rank` int(11) NOT NULL DEFAULT '0',
  `pType` varchar(255) NOT NULL DEFAULT '',
  `ItmlImg` varchar(100) NOT NULL DEFAULT '',
  `isNew` char(1) NOT NULL DEFAULT 'n',
  `pAuth` varchar(255) NOT NULL DEFAULT '',
  `ItmxlImg` varchar(255) NOT NULL DEFAULT '',
  `isFeatured` char(1) DEFAULT 'n',
  `parent` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  PRIMARY KEY (`RecID`)
) ENGINE=MyISAM AUTO_INCREMENT=4867 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for tbl_mainsection
-- ----------------------------
DROP TABLE IF EXISTS `tbl_mainsection`;
CREATE TABLE `tbl_mainsection` (
  `RecID` int(11) NOT NULL AUTO_INCREMENT,
  `MSecID` int(11) NOT NULL DEFAULT '0',
  `MSecName` varchar(50) NOT NULL DEFAULT '',
  `sshow` char(1) NOT NULL DEFAULT 'y',
  `Rank` int(11) NOT NULL DEFAULT '0',
  `file1` varchar(200) DEFAULT NULL,
  `file2` varchar(200) DEFAULT NULL,
  `parent` int(11) DEFAULT '0',
  PRIMARY KEY (`RecID`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for tbl_section
-- ----------------------------
DROP TABLE IF EXISTS `tbl_section`;
CREATE TABLE `tbl_section` (
  `RecID` int(11) NOT NULL AUTO_INCREMENT,
  `MSecID` int(11) NOT NULL DEFAULT '0',
  `SecID` int(11) NOT NULL DEFAULT '0',
  `SecName` varchar(100) NOT NULL DEFAULT '',
  `Link` varchar(255) NOT NULL DEFAULT '',
  `lnkType` int(1) NOT NULL DEFAULT '0',
  `SecImg` varchar(100) NOT NULL DEFAULT '',
  `sshow` char(1) NOT NULL DEFAULT 'y',
  `HSecName` varchar(50) NOT NULL DEFAULT '',
  `soption` char(1) NOT NULL DEFAULT 'y',
  `Rank` int(11) NOT NULL DEFAULT '0',
  `PrdType` tinyint(1) NOT NULL DEFAULT '1',
  `seo_desc` text,
  `seo_keyword` text,
  `seo_title` varchar(255) DEFAULT NULL,
  `parent` int(11) DEFAULT '0',
  PRIMARY KEY (`RecID`)
) ENGINE=MyISAM AUTO_INCREMENT=305 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `tbl_items` VALUES ('4862', '1', '101', '0', '0', '1', 'E1', 'E1', '', 'y', '', 'E1_s_1.jpg', '1', '', 'E1_l_1.jpg', 'n', '', '', 'n', '84', '5');
INSERT INTO `tbl_items` VALUES ('4863', '1', '101', '0', '0', '2', 'E2', 'E2', '', 'y', '', 'E2_s_2.jpg', '2', '', 'E2_l_2.jpg', 'n', '', '', 'n', '84', '5');
INSERT INTO `tbl_items` VALUES ('4864', '2', '0', '0', '0', '3', 'P1', 'P1', '', 'y', '', 'P1_s_3.jpg', '1', '', 'P1_l_3.jpg', 'n', '', '', 'n', '84', '5');
INSERT INTO `tbl_items` VALUES ('4865', '2', '0', '0', '0', '4', 'P2', 'P2', '', 'y', '', 'P2_s_4.jpg', '2', '', 'P2_l_4.jpg', 'n', '', '', 'n', '84', '6');
INSERT INTO `tbl_items` VALUES ('4866', '4', '0', '0', '0', '5', 'P10', 'P10', '', 'y', '', 'P10_s_5.jpg', '1', '', 'P10_l_5.jpg', 'n', '', '', 'n', '84', '5');
INSERT INTO `tbl_mainsection` VALUES ('84', '1', 'D', 'y', '1', 'level_1.jpg', null, '0');
INSERT INTO `tbl_mainsection` VALUES ('85', '1', 'D1', 'y', '1', 'main_section_1.jpg', null, '84');
INSERT INTO `tbl_mainsection` VALUES ('86', '2', 'D2', 'y', '2', 'main_section_2.jpg', null, '84');
INSERT INTO `tbl_mainsection` VALUES ('87', '3', 'D3', 'y', '3', 'main_section_3.jpg', null, '84');
INSERT INTO `tbl_mainsection` VALUES ('88', '4', 'D4', 'y', '4', 'main_section_4.jpg', null, '84');
INSERT INTO `tbl_section` VALUES ('302', '1', '101', 'D11', '', '0', '', 'y', '', 'y', '1', '1', null, null, null, '84');
INSERT INTO `tbl_section` VALUES ('303', '1', '102', 'D12', '', '0', '', 'y', '', 'y', '2', '1', null, null, null, '84');
INSERT INTO `tbl_section` VALUES ('304', '1', '103', 'D14', '', '0', '', 'y', '', 'y', '3', '1', null, null, null, '84');
