<?
require("connection.php");
include("chksession.php");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"> 
      <table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"> 
                  <? include("menu.php");?>
                </td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="575" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                    <tr> 
                      <td align="left" valign="top" style="padding-top:10px;"><table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr> 
                            <td> <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                                <tr> 
                                  <td width="12"><img src="img/cc1.jpg" width="12" height="36"></td>
                                  <td width="96%" align="center" background="img/ct1.jpg" class="CPname">Connected 
                                    User Information</td>
                                  <td width="13"><img src="img/cc2.jpg" width="13" height="36"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td><table width="100%" height="116" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="12" height="116" background="img/ctl.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
                                  <td background="img/bg1.jpg"> <table width="80%" border="0" align="center" cellpadding="2" cellspacing="2">
                                      <tr> 
                                        <td width="36%" align="right" class="btn">User 
                                          Name:&nbsp;&nbsp;</td>
                                        <td width="64%" class="USER_Info">&nbsp; 
                                          <?
										  if(isset($_SESSION['usrname'])){echo($_SESSION['usrname']);}
										  ?>                                        </td>
                                      </tr>
                                      <tr> 
                                        <td width="36%" align="right" class="btn"> 
                                          Name:&nbsp;&nbsp;</td>
                                        <td class="USER_Info">&nbsp; 
                                          <?
										  if(isset($_SESSION['fname'])){echo($_SESSION['fname']);}
										  ?>                                        </td>
                                      </tr>
                                      <tr> 
                                        <td align="right" class="btn">Connected 
                                          Date/Time:&nbsp;&nbsp;</td>
                                        <td class="USER_Info">&nbsp; 
                                          <?=date ("l dS F Y h:i:s A");?>                                        </td>
                                      </tr>
                                      <tr> 
                                        <td align="right" class="btn">Via IP:&nbsp;&nbsp;</td>
                                        <td class="USER_Info">&nbsp; 
                                          <?=$uIp?>                                        </td>
                                      </tr>
                                    </table></td>
                                  <td width="13" background="img/ctr.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="13"> <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                                <tr> 
                                  <td width="12"><img src="img/cc4.jpg" width="12" height="13"></td>
                                  <td width="96%" height="13" align="center" valign="bottom" background="img/ctb.jpg"><img src="img/ctb.jpg" width="5" height="13"></td>
                                  <td width="13"><img src="img/cc3.jpg" width="13" height="13"></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="10">&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><? include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top">
<table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr> 
          <td width="13" height="100%" valign="top" background="img/mrshade.jpg">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>