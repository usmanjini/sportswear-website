<?php
	$wysiwyg = $_POST['wysiwyg'];
	$m = $_REQUEST['m']."";
	if (trim($m)=="y"){
		$link = "&m=y";
	}else{
		$link = "";
	}	

	$pic_path = "../uploads/";
	if ($_FILES["file1"]["filImage"] > 0){
	  echo "Error: " . $_FILES["filImage"]["error"] . "<br />";
	  exit;
	}else{
		$file = $_FILES["filImage"]["name"];
		//echo $pic_path.$file;
		//exit;
		 move_uploaded_file($_FILES["filImage"]["tmp_name"],$pic_path.$file);
		 header("location:view_gallery.php?wysiwyg=".$wysiwyg."$link");
	}
?>