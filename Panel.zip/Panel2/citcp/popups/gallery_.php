<?php
	$fil = $_REQUEST['fil'];
	$wysiwyg = $_REQUEST['wysiwyg'];	
?>
<html>
	<head>
    <title>Processing...</title>
    </head>    
	<script language="JavaScript">
    	window.opener.location='gallery.php?fil=<?=$fil?>&wysiwyg=<?=$wysiwyg?>';
	    window.close();
    </script>
</html>