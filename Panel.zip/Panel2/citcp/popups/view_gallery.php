<?php
	$m = $_REQUEST['m']."";
	if (trim($m)=="y"){
		$show = 0;
		$link = "remove.php?wysiwyg=".$_REQUEST['wysiwyg']."&m=y";
	}else{
		$show = 1;
		$link = "remove.php?wysiwyg=".$_REQUEST['wysiwyg']."";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Web Gallery</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="../uploadsstyle.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style1 {
	color: #FFFFFF;
	font-family:Arial;
	font-size:16px;
	font-weight:bold;
}

-->
</style>
		<link rel="stylesheet" href="engine/css/lightbox.css" type="text/css" media="screen" /> 
<script src="engine/js/prototype.js" type="text/javascript"></script>
<script src="engine/js/scriptaculous.js?load=effects,builder" type="text/javascript"></script>
<script src="engine/js/lightbox.js" type="text/javascript"></script>

		<style>
			.gallery {
				zoom:1;
				width:auto;				
			}
			.gallery a {
				display:block;
				float:left;
				margin:5px;
				opacity:0.87;
				text-align:center;
			}
			.gallery a:hover {
				opacity:1;
			}
			.gallery a img {
				border:none;
				display:block;
			}
			.gallery a#vlightbox{display:none}
		</style>
<SCRIPT>
	function checkform(){
		if (CheckEmpty(document.form1.filImage,"Please browse the image for upload")==false) return false;		

		return true;
	}
	function CheckEmpty(obj,msg){
		if (obj.value==""){
			alert(msg);	
			obj.focus();
			return false;				
		}else{
			return true;
		}			
	}
	function onLoad(){
		var w = screen.availWidth||screen.width;
		var h = screen.availHeight||screen.height;
		window.moveTo(0,0)
		window.resizeTo(w,h)
	}
</SCRIPT>
</head>

<body onload="onLoad()">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">

  <tr>
  
    <td align="center" valign="top"><table width="800" border="0" cellspacing="0" cellpadding="0" bgcolor="#EFEFEF" height="100%">
      <tr>
        <td height="40" align="center" bgcolor="#666666" colspan="3"><span class="style1">Web Gallery</span></td>
      </tr>
      <?php if (trim($m)=="y"){?>
      <tr>
        <td height="20" colspan="3" align="right" style="padding-right:10px;"><strong><a href="javascript:history.go(-1);" class="base11">&laquo; Back</a></strong></td>
      </tr>
      <tr>
        <td height="20" colspan="3" align="center"><table width="340" border="1" cellpadding="0" cellspacing="0" bordercolor="#666666" style="border-collapse:collapse;">
          <tr>
            <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
<form id="form1" name="form1" enctype="multipart/form-data" onSubmit="return checkform();" method="post" action="uploader.php">
	<input type="hidden" name="wysiwyg" id="wysiwyg" value="<?=$_REQUEST['wysiwyg']?>">            
    <input type="hidden" name="m" id="m" value="y">            
              <tr>
                <td height="30" colspan="2" align="center" bgcolor="#C0C0C0" class="style1">Image Upload</td>
                </tr>
              <tr>
                <td align="right">&nbsp;</td>
                <td align="left">&nbsp;</td>
              </tr>                
              <tr>
                <td width="30%" align="right" class="base11" style="padding-right:10px;">Image : </td>
                <td align="left"><input name="filImage" type="file" class="form_text" id="filImage" style="font-size: 10px; width: 80%;"/></td>
              </tr>
              <tr>
                <td align="right">&nbsp;</td>
                <td height="24" align="left" valign="bottom"><input type="submit" value="Upload Image" style="font-size: 10px;" /></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              </form>
            </table></td>
          </tr>
          
        </table></td>
      </tr>            
      <?php
	  	}
	  	$image_file_path = "../uploads/";
		$d = dir($image_file_path) or die("Wrong path: $image_file_path");	
      ?>
      <tr>
	<?php
	$a = 0;
	while (false !== ($entry = $d->read())) {
		if($entry != '.' && $entry != '..' && !is_dir($dir.$entry)) {
			if ($a==3){
				echo "</tr><tr>";
				$a = 0;
			}
	?>      
        <td align="left" valign="top">

    <table width="260" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>    
      <tr>
        <td width="30" align="left" valign="top">&nbsp;</td>
        <td width="200"><table width="100%" border="1" cellpadding="0" cellspacing="0" bordercolor="#666666" style="border-collapse:collapse;">
          <tr>
            <td><a href="../uploads/<?=$entry?>"  rel="lightbox[gallery]" ><img src="../uploads/<?=$entry?>" width="200" border="0" /></a></td>
          </tr>
        </table></td>
        <td width="30">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td height="22" align="left" valign="top" class="base11"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="24%" height="20" align="left" bgcolor="#FFFFFF"><?php if ($show==1){?>Select<?php }?></td>
            <td width="20%" align="left" bgcolor="#FFFFFF"><?php if ($show==1){?><a href="gallery_.php?fil=<?=$entry?>&wysiwyg=<?=$_REQUEST['wysiwyg']?>"><img src="imgs/tick.jpg" width="16" height="13" border="0" /></a><?php }?></td>
            <td width="42%" align="right" bgcolor="#FFFFFF" class="base11">Remove</td>
            <td width="14%" align="right" valign="middle" bgcolor="#FFFFFF"><a href="<?=$link?>&fil=<?=$entry?>" onclick="javascript:if(confirm('You want to delete this image ?')) return true; else return false"><img src="imgs/publish_x.png" width="12" height="12" border="0" /></a>&nbsp;</td>
          </tr>
        </table></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>  
     <?php 	
	 $a +=1;
	 }
	 	$Images[] = $entry;
		
		}?>    </td>
      </tr>	
	<?php 	 
	  $d->close();
	?>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
