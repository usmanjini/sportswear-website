<?php
	$fil = "../uploads/".$_REQUEST['fil'];
	$m = $_REQUEST['m']."";
	if (trim($m)=="y"){
		$link = "&m=y";
	}else{
		$link = "";
	}
//	echo $fil;
//	exit;
	$wysiwyg = $_REQUEST['wysiwyg'];
	if (file_exists($fil)){
		unlink($fil);
	}
	header("location:view_gallery.php?wysiwyg=$wysiwyg".$link."")
?>