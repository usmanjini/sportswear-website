<?php
	$url = "http://".$_SERVER['HTTP_HOST']."/nc/admin/popups/dfd.jpg";
	echo $url;
?>