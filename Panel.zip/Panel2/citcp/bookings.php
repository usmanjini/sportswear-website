<?
require("connection.php");
include("chksession.php");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"> 
      <table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"> 
                  <? include("menu.php");?>
                </td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="575" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                    <tr> 
                      <td align="left" valign="top" style="padding-top:10px;"><table width="96%" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr> 
                            <td> <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                                <tr> 
                                  <td width="12"><img src="img/cc1.jpg" width="12" height="36"></td>
                                  <td width="96%" align="center" background="img/ct1.jpg" class="CPname">Booking Information </td>
                                  <td width="13"><img src="img/cc2.jpg" width="13" height="36"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td><table width="100%" height="116" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="12" height="116" background="img/ctl.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
                                  <td align="center" background="img/bg1.jpg"><form id="frmBooking" name="frmBooking" method="post" action="view-booking.php" onSubmit="return chk_booking();"><table width="60%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                      <td width="37%" height="26" class="CPname">Select Date : </td>
                                      <td width="63%"><table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                          <td width="80" align="left" valign="middle"><select name="mm" class="booking_combo_links" id="mm" style="width:70px;">
                                              <option value="">Month</option>
                                              <?php for($m=0;$m<=12;$m++){?>
                                              <option value="<?=$m?>">
                                                <?=month_name($m-0,false)?>
                                                </option>
                                              <?php } ?>
                                          </select></td>
                                          <td width="64" align="left" valign="middle"><select name="dd" class="booking_combo_links" id="dd" style="width:55px;">
                                              <option value="">Day</option>
                                              <?php for($d=1;$d<=31;$d++){?>
                                              <option value="<?=$d?>">
                                                <?=$d?>
                                                </option>
                                              <?php } ?>
                                          </select></td>
                                          <td width="80" align="left" valign="middle"><select name="yy" class="booking_combo_links" id="yy" style="width:55px;">
                                              <option value="">Year</option>
                                              <?php for($y=2012;$y<=date("Y")+10;$y++){?>
                                              <option value="<?=$y?>">
                                                <?=$y?>
                                                </option>
                                              <?php } ?>
                                          </select></td>
                                        </tr>
                                      </table></td>
                                    </tr>
                                    <tr>
                                      <td height="26" class="CPname">Booking No : </td>
                                      <td><input type="text" name="booking_no" id="booking_no" class="booking_combo_links" style="width:190px;" onBlur="this.style.backgroundColor = '#ffffff';" /></td>
                                    </tr>
                                    <tr>
                                      <td>&nbsp;</td>
                                      <td height="30"><input name="submit" type="submit" value="Search bookings"></td>
                                    </tr>
                                  </table></form></td>
                                  <td width="13" background="img/ctr.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="13"> <table width="100%" border="0" align="left" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" height="100%">
                                <tr> 
                                  <td width="12"><img src="img/cc4.jpg" width="12" height="13"></td>
                                  <td width="96%" height="13" align="center" valign="bottom" background="img/ctb.jpg"><img src="img/ctb.jpg" width="5" height="13"></td>
                                  <td width="13"><img src="img/cc3.jpg" width="13" height="13"></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="10">&nbsp;</td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top">
<table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr> 
          <td width="13" height="100%" valign="top" background="img/mrshade.jpg">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>