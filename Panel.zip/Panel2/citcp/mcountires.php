<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$zone_id = $_REQUEST["zone_id"]."";
$zone_name = $_REQUEST["zone_name"]."";
$_SESSION["bpage"] = "mcountires.php?zone_id=".$zone_id."&zone_name=".urlencode($zone_name)."";
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('SecName').focus();
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">

					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td height="20" align="right" valign="top"><a href="viewzones.php"><span class="CPname">&laquo; Back </span></a>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="550" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage                               Countries [ <?=$zone_name?> ]</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>	
                              	<td height="20" align="center" class="CPname" colspan="2">Countries of Zone <?=$zone_name?></td>
                              </tr>
                              <tr>
                              <?
							  $sql = "SELECT * FROM tbl_zone_countries WHERE zone_id=".$zone_id." ORDER BY country ASC";
							  $qry = mysql_query($sql);
							  $x=1;
							  while ($fld=mysql_fetch_array($qry)){
							  	if ($x>2){
									echo "</tr><tr>";
									$x=1;
								}
                              ?>
                                <td align="left" valign="top"><table width="271" border="0" cellpadding="1" cellspacing="2">
                                  <tr>
                                    <td width="10%" align="center" valign="middle" bgcolor="<?=$Clr2 ?>"><input type="checkbox" id="chk<?=$fld[0]?>"  name="chk<?=$fld[0]?>" checked onClick="javascript:document.location.href='savecountries.php?id=<?=$fld[0]?>&zone_id=0';"></td>
                                    <td width="90%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;<label for="chk<?=$fld[0]?>"><?=$fld["country"]?></label></td>
                                  </tr>
                                </table>
                                </td>
                              <?
							  	$x++;
							  }
                              ?>  
                                </tr>
<tr>	
                              	<td height="20" align="center" class="CPname" colspan="2">Add Countries to Zone <?=$zone_name?></td>
                              </tr>
                              <tr>
                              <?
							  $sql = "SELECT * FROM tbl_zone_countries WHERE (zone_id=0 OR zone_id IS NULL) ORDER BY country ASC";
							  $qry = mysql_query($sql);
							  $x=1;
							  while ($fld=mysql_fetch_array($qry)){
							  	if ($x>2){
									echo "</tr><tr>";
									$x=1;
								}
                              ?>
                                <td align="left" valign="top"><table width="271" border="0" cellpadding="1" cellspacing="2">
                                  <tr>
                                    <td width="10%" align="center" valign="middle" bgcolor="<?=$Clr2 ?>"><input type="checkbox"  id="chk<?=$fld[0]?>"  name="chk<?=$fld[0]?>" onClick="javascript:document.location.href='savecountries.php?id=<?=$fld[0]?>&zone_id=<?=$zone_id?>';"></td>
                                    <td width="90%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;<label for="chk<?=$fld[0]?>"><?=$fld["country"]?></label></td>
                                  </tr>
                                </table>
                                </td>
                              <?
							  	$x++;
							  }
                              ?>  
                                </tr>                                
                            </table>
                            </td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"></td>
                    </tr>
            </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>