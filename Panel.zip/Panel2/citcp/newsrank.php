<?
require("connection.php");
require("chksession.php");
$RecID = $_REQUEST["RecID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
if($_REQUEST["RecID"]){

	$query = "select * from tbl_news where rank=".$Newrank."";
	$open = mysql_query($query);
	if ($open){
		$rows = mysql_num_rows($open);
		if ($rows>0){
			$frows = mysql_fetch_row($open);
			$GetRecId = $frows[0];
				$Query = "Update tbl_news set rank=".$Newrank." where RecID=".$RecID."";
				$open = mysql_query($Query);
	
				$Query = "Update tbl_news set rank=".$Oldrank." where RecID=".$GetRecId."";
				$open = mysql_query($Query);
		}
	}

}
header('Location:mnews.php');
?>