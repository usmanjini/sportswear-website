<?
require("connection.php");
require("chksession.php");
$id = $_REQUEST["id"];
$ispost = $_REQUEST["ispost"]."";
if (trim($ispost)=="y"){
//-----------Save File 1---------------///
	$file1 = "main_section_".$id.".jpg";
	if ($_FILES["file1"]["error"] > 0){
	  //echo "Error: " . $_FILES["file1"]["error"] . "<br />";
	}else{
		 move_uploaded_file($_FILES["file1"]["tmp_name"],$simgs.$file1);

	}
	mysql_query("UPDATE tbl_mainsection SET file1 = '".$file1."',seo_desc = '".$_REQUEST["seo_desc"]."',seo_keywords = '".$_REQUEST["seo_keywords"]."' WHERE MSecID = $id");
	echo "<script language=javascript>opener.window.location.href='mmainsections.php?lvl=$lvl';</script>";
	echo "<script language=javascript>window.close();</script>";
	exit;
}else{
	$qry = mysql_query("SELECT * FROM tbl_mainsection WHERE MSecID = $id");
	$fld = mysql_fetch_array($qry);
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="styles.css">
<title>Edit Level 2 Image</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td align="center" valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
      <form action="" method="post" enctype="multipart/form-data" name="frmnews" id="frmnews" onsubmit="return checkmsecForm();">
      <input type="hidden" id="ispost" name="ispost" value="y">
        <tr>
          <td height="30" colspan="2" align="center" valign="middle" bgcolor="<?=$Clr2 ?>" class="CPname">Edit Level 2</td>
          </tr>
        <tr>
          <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
          <td align="left" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fld["file1"].""?>" width="82" height="82" /></td>
        </tr>        
        <tr>
          <td width="16%" height="21" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
          <td width="84%" align="left" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
            <span class="error">145 x 430</span></td>
        </tr>
                          <?php if ($seo==true){?>
                                  <tr> 
                                    <td height="23" align="center" colspan="2" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                                  </tr> 
                                  <tr> 
                                    <td height="23" align="center" colspan="2" ><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr bgcolor="<?=$Clr2 ?>">
                                <td width="17%" align="left" valign="top" style="padding-top:4px;"><strong>&nbsp;Description:</strong></td>
                                <td width="83%" align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_desc" cols="40" rows="6" id="seo_desc"><?=$fld["seo_desc"].""?></textarea>
                                </span></td>
                              </tr>
                              <tr bgcolor="<?=$Clr2 ?>">
                                <td align="left" valign="top" style="padding-top:4px;"><span class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></span></td>
                                <td align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"><?=$fld["seo_keywords"].""?></textarea>
                                </span></td>
                              </tr>
                            </table></td>
                                  </tr>           
                          <?php } ?> 
        <tr>
          <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
          <td align="left" bgcolor="<?=$Clr2 ?>"><input type="image" src="img/update.jpg" /></td>
        </tr>
      </form>
    </table></td>
  </tr>
</table>
</body>
</html>
