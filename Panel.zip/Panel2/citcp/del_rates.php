<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$rate_id = $_REQUEST["rates_id"]."";
$sql = "DELETE FROM tbl_rates WHERE rates_id = ".$rate_id."";
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>