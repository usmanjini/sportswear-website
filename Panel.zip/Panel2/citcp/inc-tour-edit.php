<?php
$distance = $_POST["distance"]."";	
$sqlInsert = "UPDATE tbl_tour_routes SET distance = ".$distance." WHERE row_id = ".$id.";";
//echo $sqlInsert;exit;
mysql_query($sqlInsert);
header("location:tour-routes.php?msg=Record+saved+successfully");

?>