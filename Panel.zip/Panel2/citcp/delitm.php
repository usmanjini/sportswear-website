<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
if($_REQUEST["ItmID"]){
$qry=mysql_query("select ItmImg,ItmlImg from tbl_items where ItmID='".$ItmID."' and SubID='".$SubID."' and Mainid='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){
	$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$imgdel=$itmimgs.$data[0];
		$img2del=$itmimgs.$data[1];
	}
}
$qry=mysql_query("delete from tbl_items where ItmID='".$ItmID."' and SubID='".$SubID."' and MainId='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){

	if (file_exists($imgdel)){
		unlink($imgdel);
	}
	if (file_exists($img2del)){
		unlink($img2del);
	}
}
$qryRank=mysql_query("select * from tbl_items where SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."' order by rank") or die("Invalid Sql: " . mysql_error());
	if($qryRank){
		$rows=mysql_num_rows($qryRank);
			if($rows>0){
				for($i=1;$i<=$rows;$i++){
					$data=mysql_fetch_row($qryRank);
					$qry=mysql_query("update tbl_items set Rank='".$i."' where ItmID='".$data[5]."' and SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
				}
			}
	}
}
header("location:mitem.php?lvl=".$lvl."&MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."&mess=Item+deleted+successfully");
?>