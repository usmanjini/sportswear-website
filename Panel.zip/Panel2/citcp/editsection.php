<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$SecID=$_REQUEST['SecID'];
$MSecID=$_REQUEST['MSecID'];
if(!$SecID==''){
	$qry=mysql_query("select SecName,SecImg,soption,seo_desc,seo_keyword from tbl_section where SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid SQL ".mysql_error());
	if($qry){
		$rows=mysql_num_rows($qry);
		if($rows>0){
			$data=mysql_fetch_row($qry);
			$SecName=$data[0];
			$fbImg=$data[1];
			$bImg=$secimgs.$data[1];
			$soption=$data[2];
			$seo_desc = $data[3];
			$seo_keyword = $data[4];
		}
	}
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellpadding="0" cellspacing="0" bgcolor="<?=$Clr2 ?>" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Edit 
                              Section</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form action="updsection.php?lvl=<?=$lvl?>" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checkSeceForm();">
                                  <input type="hidden" name="SecID" value="<?=$SecID ?>">
                                  <input type="hidden" name="MSecID" value="<?=$MSecID ?>">
                                  <tr> 
                                    <td width="30%" align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="70%" align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><input value="<?=$SecName ?>" name="SecName" type="text" class="txtdefault" id="SecName3">
                                      &nbsp;<font color="#FF0000">*</font> </td>
                                  </tr>
                                  <tr> 
                                    <td height="20" align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;&nbsp;<strong>Option:</strong></td>
                                    <td align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="6%"><input name="soption" type="radio" value="y" <? if($soption=='y'){?> checked<? }?>></td>
                                          <td width="13%" class="norm1">Enable</td>
                                          <td width="5%"><input type="radio" name="soption" value="n" <? if($soption=='n'){?> checked<? }?>></td>
                                          <td width="76%" class="norm1">Disable</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                  <!--tr> 
                                    <td height="20" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Image:</strong></td>
                                    <td bgcolor="<?=$Clr3 ?>" class="norm1"> 
                                      <?// if (file_exists($bImg) && $fbImg<>''){?>
                                      <img src="<?=$bImg ?>"> 
                                      <?// }else{echo('&nbsp;No Image');}?>
                                      &nbsp;</td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Re 
                                      Upload Image:</strong></td>
                                    <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="bFile" type="file" class="txtfilefield1" id="bFile"></td>
                                  </tr-->
<?php if ($seo==true){?>
                          <tr> 
                            <td height="25" align="center" colspan="2" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                          </tr>                              
                                  <tr> 
                                    <td height="20" align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><strong>&nbsp;Description:</strong></td>
                                    <td align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><textarea name="seo_desc" cols="40" rows="6" id="seo_desc"><?=$seo_desc?></textarea></td>
                                  </tr>
                                  <tr> 
                                    <td height="20" align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></td>
                                    <td align="left" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"><?=$seo_keyword?></textarea></td>
                                  </tr>   
<?php } ?>
                                  <tr> 
                                    <td bgcolor="<?=$Clr3 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr3 ?>"><input type="image" src="img/update_section.jpg" width="105" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>