<?php
	require("connection.php");
	$id = 9;
	$qry =  mysql_query("SELECT * FROM tbl_items WHERE MSecID  = ".$id."");
	while ($fld=mysql_fetch_array($qry)){
		$file = $itmimgs.$fld["ItmlImg"];
		if (file_exists($file)){
			@unlink($file);
		}
	}
	mysql_free_result($qry);
	mysql_query("DELETE FROM tbl_items WHERE MSecID  = ".$id."");
	mysql_query("DELETE FROM tbl_section WHERE MSecID  = ".$id."");
	mysql_query("DELETE FROM tbl_mainsection WHERE MSecID  = ".$id."");	
	echo "Done";
?>