<?
require("connection.php");
include("chksession.php");
include("fclr.inc");


if (isset($_POST['txtEmail'])) {
	$sql_txt = "update newsletter SET email='{$_POST['txtEmail']}' where email_id = '".$_POST['id']."'";
	if(mysql_query($sql_txt)) {
		$mess = "Email successfully updated !";
	} else {
		$mess = "ERROR / Please try again !";
	}
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top"><table width="775" height="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
            </tr>
            <tr>
              <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
            </tr>
        </table></td>
        <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
            <tr>
              <td height="152" valign="top"><?include("top.php");?></td>
            </tr>
            <tr>
              <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                    <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td align="center">&nbsp;</td>
                        </tr>
                        <?
			  	if(isset($mess)){
			  ?>
                        <tr>
                          <td align="center"><strong>
                            <?=$mess?>
                          </strong></td>
                        </tr>
                        <tr>
                          <td align="center">&nbsp;</td>
                        </tr>
                        <?
			  	}
			  ?>
                        <tr>
                          <td align="center" valign="top"><table width="90%" border="0" align="center">
                              <?
if(isset($_REQUEST["id"])){
$sql=mysql_query("select * from newsletter where email_id='".$_REQUEST["id"]."'") or die(mysql_error());
if(mysql_num_rows($sql)>0){
$rs=mysql_fetch_array($sql);
					  ?>
                              <script language="javascript">
			  function Validate(f)
			  {
			  	if(f.txtEmail.value=="")
				{
					alert("Please enter Name of club");
					f.txtEmail.focus();
					return false;
					
				}
				return true;
			  }
			  </script>
                              <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return Validate(form1);">
                                <input type="hidden" name="id" value="<?=$_REQUEST["id"]?>">
                                <tr align="center" bgcolor="<?=$Clr1?>">
                                  <td height="20" colspan="2" class="mhead"><strong>&nbsp;Update 
                                    Email</strong></td>
                                </tr>
                                <tr>
                                  <td width="30%" align="right" class="norm">Name&nbsp;</td>
                                  <td><label>
                                    <input name="txtEmail" value="<?=$rs["email"]?>" type="text" class="txtfld" id="txtEmail" size="45">
                                  </label></td>
                                </tr>
                                <tr>
                                  <td align="right"><label></label></td>
                                  <td><input name="image" type="image" src="img/add_news.jpg" width="77" height="24"></td>
                                </tr>
                              </form>
                            <?
						  }
						  }
						  ?>
                          </table></td>
                        </tr>
                        <tr>
                          <td align="center"><img src="imgs/spacer.GIF" width="1" height="30"></td>
                        </tr>
                        <tr>
                          <td align="center" valign="top">&nbsp;</td>
                        </tr>
                    </table></td>
                  </tr>
              </table></td>
            </tr>
            <tr>
              <td height="29"><?include("btm.php");?></td>
            </tr>
        </table></td>
        <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
            </tr>
            <tr>
              <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
            </tr>
        </table></td>
      </tr>
    </table> </td>
  </tr>
</table>
</body>
</html>