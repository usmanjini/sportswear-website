<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["MSecID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
$recid = $_REQUEST["recid"];
$Query = "UPDATE tbl_mainsection SET rank=	".$Newrank." WHERE recid=".$recid."";
//				echo $Query."<br/>";
$q1 = mysql_query($Query);
//echo $Query;
//exit;
if(isset($_REQUEST["MSecID"])){
	$query = "SELECT * FROM tbl_mainsection WHERE rank='".$Newrank."' AND parent = 0";
	$open = mysql_query($query);
	if ($open){
		$rows = mysql_num_rows($open);
		if ($rows>0){
			$frows = mysql_fetch_row($open);
			$GetMSecID = $frows[1];
				$Query = "UPDATE tbl_mainsection SET rank='".$Newrank."' WHERE recid='".$recid."'";
//				echo $Query."<br/>";
				$q1 = mysql_query($Query);
//				$sqlR = "SELECT * FROM tbl_mainsection WHERE rank >= ".$Newrank." AND MSecID <> ".$MSecID." AND parent = 0 ORDER BY rank";
//				$Start = $Newrank + 1;
//				$qryR = mysql_query($sqlR);	
//				while ($fld=mysql_fetch_array($qryR)){
//					$qry = "UPDATE tbl_mainsection SET rank='".$Start."' WHERE RecID=".$fld["RecID"]."";
////					echo $qry."<br/>";
//					mysql_query($qry);
//					$Start++;
//				}
//				mysql_free_result($qryR);
//				exit;
//				$Query = "UPDATE tbl_mainsection SET rank='".$Oldrank."' WHERE MSecID='".$GetMSecID."'";
//				echo $Query;
//				$q2 = mysql_query($Query);
		}
	}

}
header('location:main-sections.php');
?>