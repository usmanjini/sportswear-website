<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
	$id = $_REQUEST["gen_id"];
	$title_SEO = $_REQUEST["seo_title"];
	$desc_SEO = $_REQUEST["seo_desc"];
	$key_SEO = $_REQUEST["seo_keywords"];
	$sql = "UPDATE tbl_home SET seo_desc = '".$desc_SEO."',seo_keywords = '".$key_SEO."',seo_title = '".$title_SEO."' WHERE gen_id=".$id.";";
	mysql_query($sql);
	header("location:home.php?id=$id");
?>