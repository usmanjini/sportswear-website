function getKeyCode(event) {
	if (event.which) {
		return event.which;
	} else {
		return event.keyCode;
	}
}

function getKeyPressed(event) {
	if (!event) {
		event = window.event;
	}
	return String.fromCharCode(getKeyCode(event));
}

function typedANumber(event) {
	var testPattern = /[0-9]/;
	return testPattern.test(getKeyPressed(event));
}

function typedKeyAllowedForNumericTextBox(event) {
	// The keys it allows you to type are: numbers, backspace, tab, enter, delete (event.keyCode/event.which == 46, which is shared by "."), "."
	// We tried to have it also allow the left/right arrow keys (37, 39), but that also caused "'" and "%" to be allowed, which we didn't want.
	var allowKeys = /[\b\t\r\n]/;
	key = getKeyPressed(event)
	return (allowKeys.test(key) || typedANumber(event) || (key.charCodeAt(0) == 46));
}

function focusOnNextField (element) {
	form = element.form;
	field = element;
	for(i=0; i<form.elements.length; i++){
		if(element == form.elements[i]){
			field = form.elements[i+1];
			break;
		}
	}
	field.focus();
	return true;
}

function checkTriggerNextField(event) {
			  // mozilla					  // ie
	element = (event.target) ? event.target : event.srcElement;
	if (element.value.length == element.maxLength){
		focusOnNextField(element);
	}
//	return limitInputToNumbers(event);
}

function autoTabToNextField(event) {
	/* If they type a number and fill up the field, auto-tab to next field */
	if (typedANumber(event)) {
		checkTriggerNextField(event)
	}
}
