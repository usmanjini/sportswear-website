<div class="newproducts-area">
						<div class="row">
							<div class="col-lg-12 col-md-12">
								<div class="product-header">
									<div class="area-title">
										<h2>Featrued Products</h2>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="new-product-carosul">
							
		
                                
	
          <?php
$qryhomeitem = mysql_query("SELECT * FROM tbl_homeitems WHERE type = 'featured' order by ranking  ");
while($fldhomeitem = mysql_fetch_array($qryhomeitem)){ ?>
        <?php
$qrynproduct = mysql_query("SELECT * FROM tbl_items WHERE ItmID = ".$fldhomeitem['itemID']."");
while($fldnproduct = mysql_fetch_array($qrynproduct)){
	
		$ItmName = $fldnproduct["ItmName"];
	$ItmName1 = preg_replace("![^a-z0-9]+!i", "-", $ItmName);
	$fProLink= ROOT."large/".plus2min($ItmName1)."/page=".$fldnproduct["ItmID"]."";
	
?>    
	<!-- single-product-start -->
<div class="col-lg-3 col-md-3">
<div class="single-product">
<div class="image-area"><a href="<?=$fProLink?>">
<img src="<?=ROOT?>uploads/itmimgs/<?=$fldnproduct["ItmImg"].""?>" alt="<?=$fldnproduct["ItmName"]?>"></a></div>
<div class="product-info"><h2 class="product-name">
<a href="<?=$fProLink?>"><?=limit_text1($fldnproduct["ItmName"],30).""?></a></h2>
<div class="price-ratting"><div class="price-box-area">
<span class="new-price"><?=$fldnproduct["ArtNo"].""?></span>
<span class="old-price"></span></div></div>
<div class="action-button-area">
<a href="<?=ROOT?>add_to_basket.php?id=<?=$fldnproduct["ItmID"].""?>" class="add-to-cart"><span>+ Add to cart</span></a>
<div class="wislist-view"><!--<a href="#">+ Wishlist</a>-->
<a href="<?=$fProLink?>">+ Quick view</a></div></div></div></div></div>
	<!-- single-product-end -->
<?php }
					  mysql_free_result($qrynproduct);
							?>   
<?php  }  mysql_free_result($qryhomeitem);
							?>   
		
        	

							</div>
						</div>
					</div>