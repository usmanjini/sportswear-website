<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$MSecID=$_REQUEST['MSecID'];
$SecID=$_REQUEST['SecID'];
$MainID=$_REQUEST['MainID'];
$SubID=$_REQUEST['SubID'];
$ItmID=$_REQUEST['ItmID'];
if($MSecID<>''){
$qry=mysql_query("select * from tbl_mainsection where MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MSecName=$data[2];
	}
}else{
$MSecID=0;
}
mysql_free_result($qry);
}
if($SecID<>''){
$qry=mysql_query("select * from tbl_section where SecID='".$SecID."' and SecID='".$SecID."'") or die("Invalid SecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$SecName=$data[3];
	}
}else{
$SecID=0;
}
mysql_free_result($qry);
}

if($MainID<>''){
$qry=mysql_query("select * from tbl_main where MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MainID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MainName=$data[4];
	}
}else{
$MainID=0;
}
mysql_free_result($qry);
}

if($SubID<>'' || $SubID>0){
$qry=mysql_query("select * from tbl_sub where SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$SubName=$data[5];
	}
}else{
$SubID=0;
$SubName="";
}
mysql_free_result($qry);
}else{
$SubName="";
}
if($ItmID<>'' || $ItmID>0){
$qry=mysql_query("select * from tbl_items where ItmID='".$ItmID."' and SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$ItmName=$data[6];
	}
}else{
$ItmID=0;
$ItmName="";
}
mysql_free_result($qry);
}else{
$ItmName="";
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">
<table width="80%" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              Item</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellpadding="1" cellspacing="2">
                                <form action="addpsize.php" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checkItmsizForm();">
                                  <input type="hidden" name="MSecID" value="<?=$MSecID?>">
                                  <input type="hidden" name="SecID" value="<?=$SecID?>">
                                  <input type="hidden" name="MainID" value="<?=$MainID?>">
                                  <input type="hidden" name="SubID" value="<?=$SubID?>">
                                  <input type="hidden" name="ItmID" value="<?=$ItmID?>">
                                  <tr> 
                                    <td colspan="2" valign="top" bgcolor="<?=$Clr2 ?>"><p class="error"><strong>for 
                                        new line use &quot;#&quot; (comma)</strong></p></td>
                                  </tr>
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Sizes:</strong> 
                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>" class="error"><input name="pSize" type="text" class="txtdefault" id="pSize">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Art 
                                      No:</strong> </td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="ArtNo" type="text" class="txtdefault" id="ArtNo">
                                      &nbsp;<font color="#FF0000">* </font></td>
                                  </tr>
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Type:</strong> 
                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="pType" type="text" class="txtdefault" id="pType"></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/add_item.jpg" width="76" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" class="norm1"><strong><a href="mmainsections.php" class="managem">Top</a> 
                        &raquo; <a href="msections.php?MSecID=<?=$MSecID?>MSecID=<?=$MSecID?>" class="managem"> 
                        <?=$MSecName?>
                        </a> 
                        <?if($SecID<>0 && $SecID<>''){?>
                        &raquo; <a href="mcategories.php?MSecID=<?=$MSecID?>&SecID=<?=$SecID?>" class="managem"> 
                        <?=$SecName?>
                        </a> 
                        <?}?>
                        <?if($MainID<>0 && $MainID<>''){?>
                        &raquo; <a href="msubcats.php?MSecID=<?=$MSecID?>&SecID=<?=$SecID?>&MainID=<?=$MainID?>" class="managem"> 
                        <?=$MainName?>
                        </a> 
                        <?}?>
                        <?if($SubID<>0 && $SubID<>''){?>
                        &raquo; 
                        <?=$SubName?>
                        <?}?>
                        <br>
                        <br>
                        <a href="mitem.php?MSecID=<?=$MSecID?>&SecID=<?=$SecID?>&MainID=<?=$MainID?>&SubID=<?=$SubID?>" class="menu"> 
                        Back To Products</a></strong></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query("select * from tbl_psizes where ItmID='".$ItmID."' order by recid") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="21" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Sr#</strong></td>
                            <td width="137" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Sizes</strong></td>
                            <td width="125" bgcolor="<?=$Clr1 ?>"><strong class="shead">Type</strong></td>
                            <td width="125" bgcolor="<?=$Clr1 ?>"><strong class="shead">Art 
                              No</strong></td>
                            <td height="20" colspan="2" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
//	$rs=mysql_fetch_array($qry);
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="upditmsize.php">
                              <input type="hidden" name="MSecID" value="<? echo($MSecID);?>">
                              <input type="hidden" name="SecID" value="<? echo($SecID);?>">
                              <input type="hidden" name="MainID" value="<? echo($MainID);?>">
                              <input type="hidden" name="SubID" value="<? echo($SubID);?>">
                              <input type="hidden" name="ItmID" value="<? echo($ItmID);?>">
                              <input type="hidden" name="ID" value="<? echo($data[0]);?>">
                              <input type="hidden" name="op" value="upd">
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($i);?></td>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"> <input name="pSize" type="text" class="txtdefault" id="pSize" value="<?=$data[2]?>" size="20"></td>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="ArtNo" type="text" class="txtdefault" id="ArtNo" value="<?=$data[3]?>"></td>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="pType" type="text" class="txtdefault" id="pType" value="<?=$data[4]?>"></td>
                            <td width="47" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/update.jpg" width="59" height="24"></td>
                            </form>
                            <form name="form1" method="post" action="delitmsize.php" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($MSecID);?>">
                              <input type="hidden" name="SecID" value="<? echo($SecID);?>">
                              <input type="hidden" name="MainID" value="<? echo($MainID);?>">
                              <input type="hidden" name="SubID" value="<? echo($SubID);?>">
                              <input type="hidden" name="ItmID" value="<? echo($ItmID);?>">
                              <input type="hidden" name="ID" value="<? echo($data[0]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="59"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>