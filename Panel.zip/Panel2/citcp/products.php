<?php require_once("cn.php");
$team = $_REQUEST["team"]."";
$pagesize = 20;
$mm1 = $_REQUEST["m1"]."";
$mm2 = $_REQUEST["m2"]."";
$mm3 = $_REQUEST["m3"]."";
$m11 = m1id($mm1);
$m22 = m2id($mm2);
$m33 = m3id($mm3);
if ($m33==""){
	$m33 = 0;
}
if ($team=="1"){	
	$sqlP = "SELECT * FROM tbl_items WHERE team_id = ".getGenIdByName2($mm1)." ORDER BY parent,MSecID,SecID,Rank ";
	$bread = "<span class=\"bread1\">Team</span> <span class=\"bread2\">&raquo;</span> <span class=\"bread1\">".min2space($mm1)."</span> ";
	$meta = 0;
}else{
	$meta = 1;
	$sqlP = "SELECT * FROM tbl_items WHERE parent = ".$strId[0]." AND MSecID = ".$strId[1]." AND SecID = ".$strId[2]." ORDER BY Rank ";
	$bread = "<span class=\"bread1\">".min2space($mm1)."</span> <span class=\"bread2\">&raquo;</span> <span class=\"bread1\">".min2space($mm2)."</span> ";
	if ($mm3!="0"){ 
		$bread .= "<span class=\"bread2\">&raquo;</span> <span class=\"bread1\">". min2space($mm3)."</span>";
	}
	if (trim($m33)=="0"){
		$sql = "SELECT * FROM tbl_mainsection WHERE parent = ".$strId[0]." AND MSecID = ".$strId[1]."";		
	}else{
		$sql = "SELECT * FROM tbl_section WHERE parent = ".$strId[0]." AND MSecID = ".$strId[1]." AND SecID = ".$strId[2]."";
	}	
	$qryMeta = mysql_query($sql);
	while ($fldMeta = mysql_fetch_array($qryMeta)){
		if (trim($m33)=="0"){
			$seo_keyword = $fldMeta["seo_keywords"]."";
			$seo_desc = $fldMeta["seo_desc"]."";
		}else{
			$seo_keyword = $fldMeta["seo_keyword"]."";
			$seo_desc = $fldMeta["seo_desc"]."";
		}
	}
	mysql_free_result($qryMeta);
}

$qryP = mysql_query($sqlP);
$rcP = mysql_num_rows($qryP);
mysql_free_result($qryP);
$pg = ceil($rcP/$pagesize);
$st=$pagesize*$page-$pagesize;
if ($team=="1"){
  $link = ROOT."team/".$mm1."";
}else{
$link = ROOT.$mm1."/".$mm2;
  if ($mm3!="0"){
	$link.=  "/".$mm3;
}
$link.="/".$id;
}
$_SESSION["page"]=$link."/page=".$page;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?=$web_title?></title>
<?php if ($meta==1){?>
<meta name="description" content="<?=$seo_keyword?>">
<meta name="keywords" content="<?=$seo_desc?>">
<?php }?>
<?php include_once("scripts.php");?>
<link href="soccer_uniform_style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top"><table width="1003" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="24" align="right" valign="top" style="background-image:url(imgs_/soccer_uniform_c1.jpg);"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><img src="imgs_/soccer_uniform_c3.jpg" width="24" height="30" /></td>
          </tr>
        </table></td>
        <td width="955" align="left" valign="top" id="tdMain" ><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="147" align="left" valign="top"><?php include_once("top-header.php");?></td>
          </tr>
          <tr>
            <td height="38" align="center" valign="top"><?php include_once("top-menu.php")?></td>
          </tr>
          <tr>
            <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td width="210" align="left" valign="top"><?php include_once("side-menu.php");?></td>
                <td width="1" bgcolor="#d1d1d1"></td>
                <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="524" height="1" bgcolor="#d1d1d1"></td>
                  </tr>                
                  <tr>
                    <td height="26"  align="left" valign="middle" style="padding-left:4px;"><?=$bread?></td>
                    </tr>
                  <tr>
                    <td style="padding:6px 6px 6px 6px;"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
<?php
$qryF = mysql_query($sqlP." LIMIT $st,$pagesize");
$f = 1;
while ($fldF=mysql_fetch_array($qryF)){
	if ($f>4){
		echo "</tr><tr><td colspan='4'><img src='imgs_/soccer_uniform_c9.jpg'></td><td colspan='4' height='26'></td></tr><tr>";
		$f=1;
	}
	$file1 = $itmimgs.$fldF["ItmImg"]."";
	if (!file_exists($file1)){
		$file1 = ROOT."imgs_/no_image.jpg";
	}
?>  
                        <td align="left" valign="top"><table border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="170" align="center" valign="middle"><table border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td><table width="100%" border="0" cellspacing="0" cellpadding="0" style="border:solid 0px #999;padding:4px 4px 4px 4px;">
                                  <tr>
                                    <td width="150" valign="top" style="background-image:url(imgs_/loader.gif);background-position:center center;background-repeat:no-repeat;"><a href="<?=ROOT?>large/<?=plus2min($fldF["ItmName"])?>/page=<?=$fldF["ItmID"].""?>"><img src="<?=$file1?>" width="150" border="0" style="visibility:hidden;" onload="style.visibility='visible';" title="<?=$fldF["ItmName"]?>" /></a></td>
                                    </tr>
                                </table></td>
                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td height="20" class="pname" style="padding-left:8px;"><?=$fldF["ItmName"]?></td>
                          </tr>
                          <tr>
                            <td height="20" class="pname" style="padding-left:8px;"><strong><?=$fldF["ArtNo"]?></strong></td>
                          </tr>
 <tr>
                            <td class="general_text" style="padding-left:8px;"><?=cur?>&nbsp;<?=number_format(getProductsSizePrice($fldF["ItmID"],size),2,'.',',')?></td>
                          </tr>
<?php $qrySize = mysql_query("SELECT * FROM tbl_prod_sizes WHERE ItmId = ".$fldF["ItmID"]." ORDER BY ps_id");
if (mysql_num_rows($qrySize)>0){
?>
                          <tr>
                            <td class="general_text" style="padding-left:8px;">Sizes : <select>
<? while ($fldSize = mysql_fetch_array($qrySize)){
	$qryS = mysql_query("SELECT * FROM tbl_size WHERE size_id = ".$fldSize["size_id"]."");
	$size_name = "";
	while ($fldS=mysql_fetch_array($qryS)){
		$size_name = $fldS["size_name"]."";
	}
	mysql_free_result($qryS);
?>
                            <option><?=$size_name?></option>
<? } ?>
                            </select></td>
                          </tr>
<?php
}
mysql_free_result($qrySize);
?>
                          <tr>
                            <td class="general_text" style="padding-left:8px;"><br/><?=substr($fldF["ItmDescp"],0,100)." ..."?>&nbsp;<a href="<?=ROOT?>large/<?=plus2min($fldF["ItmName"])?>/page=<?=$fldF["ItmID"]?>" class="read_more">Read More</a></td>
                          </tr>
                          <tr>
                            <td height="20" align="right" class="general_text" style="padding-left:8px;"></td>
                          </tr> 
                          <tr>
                            <td height="20" align="left" class="general_text" style="padding-left:8px;"><span class="bread1"><a href="add_to_basket<?=$ext?>?id=<?=$fldF["ItmID"]?>" class="bread2"><strong>Add to basket</strong></a></span></td>
                          </tr>                    
                          <tr>
                            <td>&nbsp;</td>
                          </tr>
                        </table></td>
<?php
$f++;
}
mysql_free_result($qryF);
?>
                      </tr>
                    </table></td>
                  </tr>
                  <? if ($rcP==0){?>
                  <tr>
                    <td height="30" align="center" class="err">We are updating our website</td>
                  </tr>
                  <? }else{ ?>
                  <tr>
                    <td height="30" align="center" class="paging_labels"><? if ((int)$pg>1){?>
                              <span class="btm_links">Page: </span>&nbsp;<? for($p=1;$p<=$pg;$p++){?>
                                    <a href="<?=$link?>/page=<?=$p?>" class="<?=(trim($p)==trim($page)) ? "page_" : "page" ?>"><?=$p?></a> <? if ($p<$pg){?>
                                    <span class="quick_link_text">|</span> 
                                    <? }?> <? }?><? }?></td>
                  </tr>
                  <? } ?>
                </table></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td align="left" valign="top"><?php include("btm.php");?></td>
          </tr>
        </table></td>
        <td align="left" valign="top" style="background-image:url(imgs_/soccer_uniform_c2.jpg);"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><img src="imgs_/soccer_uniform_c4.jpg" width="24" height="54" /></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
