<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["MSecID"];
$SecID = $_REQUEST["SecID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
$recid = $_REQUEST["RecID"];
$Query = "UPDATE tbl_section SET rank=".$Newrank." WHERE RecID = ".$recid."";
//echo $Query;
$open = mysql_query($Query);
//exit;
//if($_REQUEST["SecID"]){
//
//	$query = "select * from tbl_section where rank='".$Newrank."' and MSecID='".$MSecID."'";
//	$open = mysql_query($query);
//	if ($open){
//		$rows = mysql_num_rows($open);
//		if ($rows>0){
//			$frows = mysql_fetch_row($open);
//			$GetSecId = $frows[2];
//				$Query = "Update tbl_section set rank='".$Newrank."' where SecID='".$SecID."' and MSecID='".$MSecID."'";
//				$open = mysql_query($Query);
//	
//				$Query = "Update tbl_section set rank='".$Oldrank."' where SecID='".$GetSecId."' and MSecID='".$MSecID."'";
//				$open = mysql_query($Query);
//		}
//	}
//
//}
header("location:msections.php?lvl=".$lvl."&MSecID=".$MSecID."");
?>