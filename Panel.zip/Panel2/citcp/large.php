<?php require_once("config.php");


$sqlP = "SELECT * FROM tbl_items WHERE ItmID = ".$strId[0]." ORDER BY Rank ";
//echo $sqlP;
$m1 = $_REQUEST['m1']."";

$bread = "<span class=\"bread1\">".min2space($m1)."</span> ";//"<span class=\"bread2\">&raquo;</span> <span class=\"bread1\">".min2space($mm2)."</span> ";
$bread2 = min2space($m1)." - ";
$bread3 = min2space($m1)."  ";
$qryP = mysql_query($sqlP);
$rcP = mysql_num_rows($qryP);
mysql_free_result($qryP);
$pg = ceil($rcP/$pagesize);
$st=$pagesize*$page-$pagesize;
$qryF = mysql_query($sqlP." LIMIT $st,$pagesize");
$_SESSION["page"]=ROOT."large/".$m1."/page=".$strId[0];
//echo $_SESSION["page"];
	$qryMeta = mysql_query($sqlP);
	while ($fldMeta = mysql_fetch_array($qryMeta)){
		$seo_keyword = $fldMeta["seo_keywords"]."";
		$seo_desc = $fldMeta["seo_desc"]."";
		$MainName = $fldMeta["MSecID"]."";
		$SubName = $fldMeta["SecID"]."";
		$ItmName = $fldMeta["ItmName"]."";
	}
	mysql_free_result($qryMeta);
$page_name= $ItmName." | ".$web_title;
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?=$page_name?></title>
    <?php if ($meta==1){?>
<meta name="keywords" content="<?=$seo_keyword?>">
<meta name="description" content="<?=$seo_desc?>">

<?php }?>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
		<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">

		
      <?php include("sytlesheets.php"); ?>
    </head>
    <body class="product-details home-8">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- Add your site or application content here -->
        <!-- header-area-start -->
		
		<?php include("comman-header.php"); ?>
        <!-- header-area-end -->
               <?php

$f = 1;
while ($fldF=mysql_fetch_array($qryF)){
	if ($f>4){
		
		$f=1;
	}
?> 	
		<!-- breadcrumb-area-start -->
		<div class="breadcrumb-area mb-70">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="breadcrumb-content text-center">
							<div class="breadcrumb-title">
								<h3><a href="<?=$dumylink?>"><?=$ItmName;?></a></h3>
							</div>
                       
							<ul>
								<li><a href="<?=ROOT?>home"><i class="fa fa-home"></i></a></li>
                                <li><a href="<?=$dumylink?>">  <i class="fa fa-angle-right"></i> <?=MainSection($MainName);?>  </a></li>
		<li class="active"><a href="<?=$dumylink?>"><i class="fa fa-angle-right"></i><?=$ItmName;?></a></li>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- breadcrumb-area-end -->
		<!-- product-details-area-start -->
		<div class="product-details-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
						<div class="flexslider">
                        
							<ul class="slides">
                            	<li data-thumb="<?=ROOT."uploads/itmimgs/".$fldF["ItmlImg"].""?>">
								  <img src="<?=ROOT."uploads/itmimgs/".$fldF["ItmlImg"].""?>" alt="<?=$fldF["ItmName"]?>" />
								</li>
                             <?php
							$qryG=mysql_query("SELECT * FROM tbl_prd_gallery WHERE ItmId = ".$fldF["ItmID"]." ORDER BY gallrank") or die("Invalid Query ".mysql_error());
							$cRow= mysql_num_rows($qryG);
							
							if($cRow > 2){
								
								$style= 'data-arrows="false"';
								
								}else{
								$style= 'data-arrows="true"';	
									}
							 ?>
                        
                        <?php


$a1=1;
while ($fldG=mysql_fetch_array($qryG)){
$a1++;
?>
       	<li data-thumb="<?=ROOT."uploads/itmimgs/".$fldG["file1"].""?>">
								  <img src="<?=ROOT."uploads/itmimgs/".$fldG["file2"].""?>" alt="<?=$fldF["ItmName"]?>" />
								</li>                     
							
                                                             <?php


$a1=1;
while ($fldG=mysql_fetch_array($qryG)){
$a1++;
?>
								<li data-thumb="img/thum-2/2.jpg">
								  <img src="img/flex/2.jpg" alt="woman" />
								</li>
								<li data-thumb="img/thum-2/3.jpg">
								  <img src="img/flex/3.jpg" alt="woman" />
								</li>
								<li data-thumb="img/thum-2/4.jpg">
								  <img src="img/flex/4.jpg" alt="woman" />
								</li>
							</ul>
						</div>
					</div>
					<div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
						<div class="product-info-main">
							<div class="page-title">
								<h1><?=$ItmName;?></h1>
							</div>
							
							<div class="product_reference">
								<p>Art No:<span><?=$fldF["ArtNo"]?></span></p>
							</div>
							
							
							<div class="short_description_block">
								<p>Printed chiffon knee length dress with tank straps. Deep v-neckline.</p>
							</div>
							<div class="product-add-form">
								<form action="#">
									<div class="quality-button">
										<label>Qty</label>
										<input class="qty" type="number" value="1">
									</div>
								</form>
							</div>
							<div class="box-cart-bottom">
								<div class="add_to_cart">
									<a href="#">Add to cart</a>
								</div>
								
							</div>
							
							
						</div>
					</div>
				</div>	
			</div>
		</div>
		<!-- product-details-area-end -->
	
		<!-- pos_new_product-area-start -->
		<div class="pos_new_product ptb-80">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="section-title mb-30">
							<h2><span></span>ther products in the same category: </h2>
						</div>
					</div>
				</div>	
				<div class="product-active-3">
                    <?php

$sqlF1 = "SELECT * FROM tbl_items WHERE MSecID = ".$fldF["MSecID"]." AND SecID = ".$fldF["SecID"]." AND parent = ".$fldF["parent"]."   AND Rank > ".$fldF["Rank"]." ORDER BY Rank LIMIT 8";

$qryF1 = mysql_query($sqlF1);

$rcF1 = mysql_num_rows($qryF1);





while ($fldF1=mysql_fetch_array($qryF1)){

	

	$ItmNamef = $fldF1["ItmName"];

	$ItmNamef1 = preg_replace("![^a-z0-9]+!i", "-", $ItmNamef);

	$ProLink1= ROOT."large/".plus2min($ItmNamef1)."/page=".$fldF1["ItmID"]."";

		





?> 
					<!-- single-product-start -->
					<div class="single-product">
						<div class="product-img">
							<a href="<?=$ProLink1?>">
								<img src"<?=ROOT?>uploads/itmimgs/<?=$fldF1["ItmImg"].""?>" alt="<?=$ItmName?>" class="first" />
								<img src"<?=ROOT?>uploads/itmimgs/<?=$fldF1["ItmImg"].""?>" alt="<?=$ItmName?>" class="second" />
							</a>
						</div>
						<div class="product-content">
							<h3><a href="<?=$ProLink1?>"><?=limit_text1(trim($ItmName),18);?></a></h3>
							
							<div class="product-price">
								<ul>
									<li class="new-price"><?=$fldF1["ArtNo"].""?></li>
								</ul>
							</div>
							<div class="add-to-links mt-15">
								<ul>
									<li><a href="<?=ROOT?>add_to_basket.php?id=<?=$fldF1["ItmID"].""?>" title="<?=$ItmName?>"><i class="fa fa-shopping-cart"></i></a></li>
					
									<li><a href="<?=$ProLink1?>" title="<?=$ItmName?>" ><i class="fa fa-eye"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<!-- single-product-end -->
                      <? 

} 

mysql_free_result($qryF1);

?>        
               
				
				</div>
			</div>
		</div>
		<!-- pos_new_product-area-end -->
	
			 <?php
$f++;
}
mysql_free_result($qryF);
?>		
			
		<?php include("comman-footer.php");?>
		
		
		<?php include("javascripts.php"); ?>
    </body>
</html>
