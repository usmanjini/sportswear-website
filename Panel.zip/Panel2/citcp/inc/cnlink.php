<?php
	$homepage=ROOT."home".$ext;
	$aboutpage=ROOT."about".$ext;
	$contactpage=ROOT."contact-us".$ext;
	$customerservicespage=ROOT."customer-services".$ext;
	$basketpage=ROOT."basket".$ext;
	$finalizepage=ROOT."finalize".$ext;
	$conditionspage=ROOT."conditions".$ext;
	$returnspage=ROOT."returns".$ext;
	$sitemappage=ROOT."sitemap".$ext;
	
?>