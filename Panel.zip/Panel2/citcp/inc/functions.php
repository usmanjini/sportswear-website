<?php
	define("cur","$");
	define("size",12);
	$bgcolor = "#006498";
	function dynamics($id){
		$sql = "SELECT detail  FROM tbl_gen WHERE gen_id = ".$id."";
		$qry = mysql_query($sql);
		$fld = mysql_fetch_array($qry);		
		mysql_free_result($qry);
		return image_adjust($fld[0]."");
	}
	function meta_tages($id){
		$sql = "SELECT seo_desc,seo_keywords FROM tbl_gen WHERE gen_id = ".$id."";
		$qry = mysql_query($sql);
		$fld = mysql_fetch_array($qry);		
		$return = "<meta name=\"description\" content=\"".$fld["seo_desc"]."\">
<meta name=\"keywords\" content=\"".$fld["seo_keywords"]."\">";
		mysql_free_result($qry);
		return $return;
	}	
	function image_adjust($str){
		return str_replace("popups/","admincp/popups/",$str);
	}
	function br($str){
		return str_replace(chr(13),"<br>",$str);
	}
	function movepage($url){
		echo "<script language=\"javascript\">document.location.href='".$url."'</script>";
		
	}
	function plus2min($strVal){
		return str_replace("+","-", urlencode($strVal));
	}
	function min2space($strVal){
		return str_replace("-"," ",$strVal);
	}
	function m1id($m1){
		$return = "";
		$qry = mysql_query("SELECT * FROM tbl_mainsection WHERE MSecName = '".min2space($m1)."' AND parent = 0");
		while ($fld = mysql_fetch_array($qry)){
			$return = $fld["RecID"]."";
		}
		mysql_free_result($qry);
		return $return;
	}
	function m2id($m2){
		$return = "";
		$qry = mysql_query("SELECT * FROM tbl_mainsection WHERE MSecName = '".min2space($m2)."' AND parent <> 0");
		while ($fld = mysql_fetch_array($qry)){
			$return = $fld["MSecID"]."";
		}
		mysql_free_result($qry);
		return $return;
	}
	function m3id($m3){
		$return = "";
		$qry = mysql_query("SELECT * FROM tbl_section WHERE SecName = '".min2space($m3)."'");
		while ($fld = mysql_fetch_array($qry)){
			$return = $fld["SecID"]."";
		}
		mysql_free_result($qry);
		return $return;
	}	
	function parent_name1($parent_id){
		$return = "";
		$qry = mysql_query("SELECT * FROM tbl_mainsection WHERE RecID = ".$parent_id."");
		while ($fld = mysql_fetch_array($qry)){
			$return = $fld["MSecName"]."";
		}
		mysql_free_result($qry);
		return $return;
	}	
	function getGenIdByName2($gen_name){
		$return = "";
		$qry = mysql_query("SELECT * FROM tbl_general WHERE title = '".min2space($gen_name)."'");
		while ($fld = mysql_fetch_array($qry)){
			$return = $fld["row_id"]."";
		}
		mysql_free_result($qry);
		return $return;
	}
	function getGenCount($parent_id){
		$qry = mysql_query("SELECT * FROM tbl_general WHERE parent_id = ".$parent_id."");
		$return = mysql_num_rows($qry);
		mysql_free_result($qry);
		return $return;
	}
	function getProductsSizePrice($pid,$size){
		$qry = mysql_query("select * from tbl_prod_sizes WHERE ItmId = ".$pid." AND size_id = ".$size."");
		$return = 0;
		while ($fld=mysql_fetch_array($qry)){
			$return = $fld["price"];
		}
		mysql_free_result($qry);
		return $return;
	}
	function getProductsSizeName($size){
		$qry = mysql_query("select * from tbl_size WHERE size_id = ".$size."");
		$return = 0;
		while ($fld=mysql_fetch_array($qry)){
			$return = $fld["size_name"];
		}
		mysql_free_result($qry);
		return $return;
	}
?>