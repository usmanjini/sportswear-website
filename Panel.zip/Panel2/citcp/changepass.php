<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$OkMsg=false;
$mess="";
if (isset($_REQUEST['NPass']) && isset($_REQUEST['CPass'])) {
	if($_REQUEST['NPass']==$_REQUEST['CPass']){
		$qry=mysql_query("select * from tbl_admin where usrname='".$_SESSION['usrname']."' and password='".$_REQUEST["OPass"]."'") or die("Invalid SQL ".mysql_error());
		if($qry){
			if(mysql_num_rows($qry)>0){
				$qryupd=mysql_query("update tbl_admin set password='".$_REQUEST["NPass"]."' where usrname='".$_SESSION['usrname']."' and password='".$_REQUEST["OPass"]."'") or die("Invalid Values: " . mysql_error());
				if($qryupd){
					$mess="Password changed successfully!";
					$OkMsg=true;
				}
			}else{
				$mess="Old password do not match!";
			}
		}
	}else{
		$mess="New & Confirm password do not match!";
	}
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center" valign="top"><table width="775" height="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
            </tr>
            <tr>
              <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
            </tr>
        </table></td>
        <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
            <tr>
              <td height="152" valign="top"><?include("top.php");?></td>
            </tr>
            <tr>
              <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                    <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                    <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <td align="center">&nbsp;</td>
                        </tr>
                        <tr>
                          <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                              <tr>
                                <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Change 
                                  Password </td>
                              </tr>
                              <tr>
                                <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                    <form name="frmnews" method="post" action="" onSubmit="return passcheck();">
                                      <?
					  	if($OkMsg==false){
						if($mess<>''){
					  ?>
                                      <tr align="center">
                                        <td height="20" colspan="2" valign="top" bgcolor="<?=$Clr2 ?>" class="error"><?=$mess?></td>
                                      </tr>
                                      <?
								  	}
								  ?>
                                      <tr>
                                        <td height="20" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;<strong>Username:</strong></td>
                                        <td bgcolor="<?=$Clr2 ?>">&nbsp;
                                            <? if(isset($_SESSION['usrname'])){echo($_SESSION['usrname']);};?>
                                        </td>
                                      </tr>
                                      <tr>
                                        <td width="27%" height="20" valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Old 
                                          Password :</strong></td>
                                        <td width="73%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="OPass" type="password" class="txtdefault" id="OPass" value="<? if(isset($_REQUEST['OPass'])) print $_REQUEST['OPass'];?>">
                                          &nbsp;<font color="#FF0000">*</font> </td>
                                      </tr>
                                      <tr>
                                        <td height="20" valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;New 
                                          Password :</strong></td>
                                        <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="NPass" type="password" class="txtdefault" id="NPass" value="<? if(isset($_REQUEST['NPass'])) print $_REQUEST['NPass'];?>">
                                          &nbsp;<font color="#FF0000">*</font></td>
                                      </tr>
                                      <tr>
                                        <td height="20" valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Confirm 
                                          Password: </strong></td>
                                        <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="CPass" type="password" class="txtdefault" id="CPass" value="<? if(isset($_REQUEST['CPass'])) print $_REQUEST['CPass'];?>">
                                          &nbsp;<font color="#FF0000">*</font></td>
                                      </tr>
                                      <tr>
                                        <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                        <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/changepass.jpg" width="121" height="24"></td>
                                      </tr>
                                      <?
									}else if($OkMsg==true){
								  ?>
                                      <tr align="center" bgcolor="<?=$Clr2 ?>">
                                        <td colspan="2"><?=$mess?></td>
                                      </tr>
                                      <?
									}
								  ?>
                                    </form>
                                </table></td>
                              </tr>
                          </table></td>
                        </tr>
                        <?
$qry=mysql_query("select * from tbl_news order by rank") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                        <tr>
                          <td align="center" valign="top">&nbsp;</td>
                        </tr>
                        <?
}
}
?>
                    </table></td>
                  </tr>
              </table></td>
            </tr>
            <tr>
              <td height="29"><?include("btm.php");?></td>
            </tr>
        </table></td>
        <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
            </tr>
            <tr>
              <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>