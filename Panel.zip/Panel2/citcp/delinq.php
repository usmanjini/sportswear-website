<?
require("connection.php");
require("chksession.php");
if(isset($_REQUEST["InqID"])){
$qry=mysql_query("delete from tbl_inqcust where Login='".$_REQUEST["InqID"]."'") or die("Invalid Values: " . mysql_error());
$qry=mysql_query("delete from tbl_inq where OrderID='".$_REQUEST["InqID"]."'") or die("Invalid Values: " . mysql_error());
header('Location:vinquiries.php?mess=Inquiry+deleted+successfully');
}
?>