<?
require("connection.php");
require("chksession.php");
if($_REQUEST["news"]){
$qry=mysql_query("update tbl_news set news='".$_REQUEST["news"]."',ntitle='".$_REQUEST["ntitle"]."',nDate='".$_REQUEST["nDate"]."' where recid='".$_REQUEST["RecID"]."'") or die("Invalid Values: " . mysql_error());
}
header('Location:mnews.php#n');
?>