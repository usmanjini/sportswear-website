<?
if(isset($_SESSION['logged'])){
	if(!$_SESSION['logged']==true){
		header('Location:login.php');
	}
}else{
	header('Location:login.php');
}
$lvl = $_REQUEST['lvl'];
include("levels.php");
function parent_name($id){	
	$return = "";
	$qry=mysql_query("SELECT * FROM tbl_mainsection WHERE RecID = ".$id."");
	while ($fld = mysql_fetch_array($qry)){
		$return = $fld['MSecName']."";
	}
	mysql_free_result($qry);
	return $return;
}
function getProductsSizeName2($size){
	$qry = mysql_query("select * from tbl_size WHERE size_id = ".$size."");
	$return = 0;
	while ($fld=mysql_fetch_array($qry)){
		$return = $fld["size_name"];
	}
	mysql_free_result($qry);
	return $return;
}
?>