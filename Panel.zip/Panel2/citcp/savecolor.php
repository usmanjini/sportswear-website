<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
$sshow=$_REQUEST["show"];
if($SecName<>""){

	$qry=mysql_query("insert into tbl_color(ColorName) values('".$SecName."')") or die("Invalid Values: " . mysql_error());
}
header('Location:viewcolors.php');
?>