<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$dis_id = $_REQUEST["dis_id"]."";
$sql = "UPDATE tbl_discount SET qty = ".$_REQUEST['qty'].", qty2 = ".$_REQUEST['qty2'].", discount = ".$_REQUEST['price']." WHERE discount_id  = ".$dis_id."";
//echo $sql;
//exit;
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>