<?
require("connection.php");
require("chksession.php");
$ItmId = $_REQUEST['ItmId']."";

$bFile = $_FILES["file1"]["name"];
$bFile2 = $_FILES["file2"]["name"];

$img="";
$img2="";

if($ItmId<>""){

$qryItmID=mysql_query("select image_id from tbl_prd_gallery order by image_id desc") or die("Invalid Values: " . mysql_error());
if($qryItmID){
	$rows=mysql_num_rows($qryItmID);
	if($rows>0){
		$data=mysql_fetch_row($qryItmID);
		$next_id=$data[0]+1;
	}else{
		$next_id=1;
	}
}

if (!($bFile=='')){
$img = "prod_gal_s_".$next_id.".jpg";
}
if (!($bFile2=='')){
$img2 = "prod_gal_l_".$next_id.".jpg";
}
$sql = "INSERT INTO tbl_prd_gallery (ItmId,file1,file2) VALUES ($ItmId,'".$img."','".$img2."')";

$qry=mysql_query($sql) or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['file1']['tmp_name'],$itmimgs.$img);
}
if (!($bFile2=='')){
move_uploaded_file($_FILES['file2']['tmp_name'],$itmimgs.$img2);
}
}
}
header('Location:productsgallery.php?id='.$ItmId.'&mess=Item+added+successfully');
?>