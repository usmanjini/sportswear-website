<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
$SQL = "SELECT * FROM tbl_general WHERE parent_id = ".$id." ORDER BY ranking";
$qry = mysql_query($SQL);
$x=1;
while ($fld=mysql_fetch_array($qry)){
	mysql_query("UPDATE tbl_general SET ranking = ".$x." WHERE row_id = ".$fld["row_id"]."");
	$x++;
}
mysql_free_result($qry);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('title').focus();
	}
	function chkFo(){
		var fld = document.getElementById('title');
		if (fld.value==""){
			alert('Please Enter The <?=$title?> Name');
			fld.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="550" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              <?=$title?></td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="550" border="0" cellpadding="1" cellspacing="2">
                                <form action="save-gener.php?id=<?=$_REQUEST['id']?>" method="post" name="frmgen" onSubmit="return chkFo();" enctype="multipart/form-data">
<input type="hidden" id="ids" name="ids" value="<?=$_REQUEST['id']?>">                                
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="title" type="text" class="txtdefault" id="title">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <? if ($link==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>link:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="link" type="text" class="txtdefault" id="link">
                                      &nbsp;<font color="#FF0000">For example: http://www.domainname.com</font></td>
                                  </tr>                                                    
                                  <? } ?>   
                                  <? if ($detail_s==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Detail:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea name="detail1" cols="35" rows="4" class="txtnews1" id="detail1"></textarea></td>
                                  </tr>                  
                                  <? } ?> 
                                  <? if ($detail_l==true){?>
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg.js"></script> 
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script language="JavaScript">WYSIWYG.attach('pdetail');</script>                                   
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Full Detail:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea  name="pdetail" cols="50" rows="15" class="txt_id_sub" id="textarea"></textarea></td>
                                  </tr>                  
                                  <? } ?>                                                                                 
                                  <? if ($file1==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
                                      <span class="error"><?=$wfile1?> x <?=$hfile1?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file2==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file2" type="file" class="txtdefault" id="file2" style="width:200px;"/>
                                      <span class="error"><?=$wfile2?> x <?=$hfile2?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file3==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file3" type="file" class="txtdefault" id="file3" style="width:200px;"/>
                                      <span class="error"><?=$wfile3?> x <?=$hfile3?></span></td>
                                  </tr>
                                  <? } ?>
                                  <? if ($file4==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file4" type="file" class="txtdefault" id="file4" style="width:200px;"/>
                                      <span class="error"><?=$wfile4?> x <?=$hfile4?></span></td>
                                  </tr>                                  <? } ?>                                                                    
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="submit" value="Save <?=$title?>" ></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">ID</strong></td>
                            <td width="300" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Name</strong></td>
                            <td height="20" colspan="3" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="updmsec.php" onSubmit="return checkmsecForm<? echo($i);?>();">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <td class="norm1" bgcolor="<?=$Clr3 ?>"><? echo($data[0]);?></td>
                              <td height="20" align="left" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<?=$data[3].""?></td>
                              <td width="60" bgcolor="<?=$Clr3 ?>"><strong><a href="edit-general.php?id=<?=$data[1]?>&row_id=<?=$data[0]?>" class="managem">Edit </a></strong></td>
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msecgallery.php?MSecID=<?=$data[1] ?>" class="menu">Gallery</a></strong></td-->
                            </form>
                            <form name="frmRank<? echo($i);?>" method="post" action="gen_rank.php" onSubmit="return checkmsecrForm<? echo($i);?>()">
                              <input type="hidden" name="MSecID" value="<? echo($data[0]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[2]);?>">
                              <input type="hidden" name="parent_id" value="<? echo($data[1]);?>">
                              <td width="26" bgcolor="<?=$Clr3 ?>"><select class="txtnorm1" style="width:36px;" id="txtrank" name="txtrank" onChange="javascript:document.frmRank<? echo($i);?>.submit();">
                              	<? for ($x=1;$x<=$rows;$x++){?>
                              	<option value="<?=$x?>" <? if ($x==$data[2]){ echo " Selected";}?>><?=$x?></option>
                                <? }?>
                              </select>
                              </td>
                            </form>
                            <form name="form1" method="post" action="del-gen.php?id=<? echo($data[1]);?>" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="row_id" value="<? echo($data[0]);?>">
                              <td width="45" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>