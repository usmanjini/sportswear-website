<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$SubName=$_REQUEST["SubName"];
$soption=$_REQUEST["soption"];
$bFile = $_FILES["bFile"]["name"];
$img="";
//if (!($bFile=='')){
$img = "sub_".$SubID.".jpg";
//}
if (file_exists($subimgs.$img) || $bFile<>''){
$img = $img;
}else{
$img = '';
}
if($SubID<>""){
$qry=mysql_query("update tbl_sub set SubName='".$SubName."',SubImg='".$img."',soption='".$soption."' where SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
$img = "sub_".$SubID.".jpg";
move_uploaded_file($_FILES['bFile']['tmp_name'],$subimgs.$img);
}
}
}
header('Location:msubcats.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID.'&mess=Sub+Category+updated+successfully');
?>