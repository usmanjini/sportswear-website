<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$sql = "DELETE FROM tbl_discount WHERE discount_id = ".$_REQUEST["dis_id"]."";

mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>