<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
$sshow=$_REQUEST["show"];
if($SecName<>""){

$qryMSecID=mysql_query("select MSecID from tbl_mainsection order by MSecID desc") or die("Invalid Values: " . mysql_error());
if($qryMSecID){
	$rows=mysql_num_rows($qryMSecID);
	if($rows>0){
		$data=mysql_fetch_row($qryMSecID);
		$MSecID=$data[0]+1;
	}else{
		$MSecID=1;
	}
}
$qryRank=mysql_query("select rank from tbl_mainsection where parent = 0 order by rank desc") or die("Invalid Values: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}

//-----------Save File 1---------------///
	$file1 = "level_".$MSecID.".jpg";
	if ($_FILES["file1"]["error"] > 0){
	  //echo "Error: " . $_FILES["file1"]["error"] . "<br />";
	}else{
		 move_uploaded_file($_FILES["file1"]["tmp_name"],$simgs.$file1);

	}

$qry=mysql_query("insert into tbl_mainsection(MSecID,MSecName,sshow,Rank,file1,parent) values('".$MSecID."','".$SecName."','".$sshow."','".$Rank."','".$file1."',0)") or die("Invalid Values: " . mysql_error());
}
header('Location:main-sections.php');
?>