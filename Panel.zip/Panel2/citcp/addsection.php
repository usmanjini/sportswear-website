<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecName=$_REQUEST["SecName"];
$bFile = $_FILES["bFile"]["name"];
$img="";
if($SecName<>""){

$qrySecID=mysql_query("select SecID from tbl_section order by SecID desc") or die("Invalid ID Query: " . mysql_error());
if($qrySecID){
	$rows=mysql_num_rows($qrySecID);
	if($rows>0){
		$data=mysql_fetch_row($qrySecID);
		$SecID=$data[0]+1;
	}else{
		$SecID=101;
	}
}
if (!($bFile=='')){
$img = "sec_".$MSecID."_".$SecID.".jpg";
}
$qryRank=mysql_query("select rank from tbl_section where MSecID='".$MSecID."' order by rank desc") or die("Invalid Rank Query: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}
$qry=mysql_query("insert into tbl_section(MSecID,SecID,SecName,SecImg,Rank,parent,seo_desc,seo_keyword) values('".$MSecID."','".$SecID."','".$SecName."','".$img."','".$Rank."',".$lvl.",'".$_REQUEST["seo_desc"]."','".$_REQUEST["seo_keywords"]."')") or die("Invalid Insert Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$secimgs.$img);
}
}
}
header("location:msections.php?lvl=".$lvl."&MSecID=".$MSecID."&mess=".$m3."+added+successfully");
?>