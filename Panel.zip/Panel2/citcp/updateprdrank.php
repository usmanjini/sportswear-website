<?
require("connection.php");
include("chksession.php");
 $prd_id = $_REQUEST['prd_id'];
 $image_id = $_REQUEST['image_id'];
$gallrank = $_REQUEST['gallrank'];

$sql = "UPDATE tbl_prd_gallery SET gallrank = ".$gallrank." WHERE image_id = ".$image_id."";
echo $sql;
mysql_query($sql);
header("location:productsgallery.php?id=".$prd_id."&mess=Item+added+successfully");

?>