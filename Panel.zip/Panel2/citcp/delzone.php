<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$zone_id = $_REQUEST["zone_id"]."";
$sql = "DELETE FROM tbl_zones WHERE zone_id = ".$zone_id."";
mysql_query($sql);
header("location:viewzones.php");
?>