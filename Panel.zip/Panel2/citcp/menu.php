<link rel="stylesheet" type="text/css" href="styles.css">
<table width="177" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Product 
      Handling</td>
  </tr>
  <tr> 
    <td height="1"><img src="img/spacer.gif" width="1" height="1"></td>
  </tr>
  <!--tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="msections.php?MSecID=7" class="menu">Manage Products</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr-->  
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="main-sections.php" class="menu">Manage Products</a></td>
    <!--td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mmainsections.php" class="menu">Manage Products</a></td-->    
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>      
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="viewcolors.php" class="menu">Manage Colors</a></td>
  </tr>

  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="viewsizes.php" class="menu">Manage Sizes</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>  
  <!--tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="viewzones.php" class="menu">Manage Zones</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>  
  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Dynamic 
      Gallery </td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mgallery.php" class="menu">Manage 
      Dynamic Images</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr-->
  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Inquries 
      Handling</td>
  </tr>  
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="vinquiries.php" class="menu">Manage 
      Inquires</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>  
  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;General Contents</td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <?
  $sqlGen = "SELECT * FROM tbl_gen WHERE active = 'y' ORDER BY gen_id";
  $qryGen = mysql_query($sqlGen);
  while ($fldGen=mysql_fetch_array($qryGen)){
  ?>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="general.php?id=<?=$fldGen["gen_id"].""?>" class="menu"><?=$fldGen["title"].""?></a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>               
  <?
  }
  ?>
  <!--tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Online 
      Inquiry Status</td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr-->
  <!--tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;News 
      &amp; Newsletters</td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr-->
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="mnews.php" class="menu">News 
      &amp; Updates</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
    <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=3" class="menu">Quick Links</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <!--tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=1" class="menu">Brands</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=2" class="menu">Quick Links</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr> 
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=3" class="menu">Teams</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr--->  
 <!-- <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=4" class="menu">Featured Collections</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr> -->
   <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Home Banners & Items </td>
  </tr>
  
    <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=6" class="menu">Dynamic Banner</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <!--  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=1" class="menu">Banner limit 2</a></td>
  </tr>-->
 <!-- <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>-->
     <!-- <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=1" class="menu">Single Banner 1</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>-->
      <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=2" class="menu">Side Banner </a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
     <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-homeitems.php?type=featured" class="menu">Featured Products</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr> 
    <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-homeitems.php?type=new" class="menu">New Items</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>  
  

  
  <!--tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="view-general.php?id=5" class="menu">Advertisement 2</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>          
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="newsletters.php" class="menu">Manage Newsletter Emails</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="sendnewsletters.php" class="menu">Send Email to Users</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr-->

  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Security 
      &amp; Settings</td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="changepass.php" class="menu">Change 
      Password</a></td>
  </tr>  
  
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php" class="menu">Logout</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php" class="menu">Home</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
</table>
