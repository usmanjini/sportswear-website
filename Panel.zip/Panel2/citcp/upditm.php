<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
$ItmName=$_REQUEST["ItmName"];
$ArtNo=$_REQUEST["ArtNo"];
$pSize=$_REQUEST["pSize"];
$pType=$_REQUEST["pType"];
$pAuth=$_REQUEST["pAuth"];
$ItmDescp=$_REQUEST["ItmDescp"];
$soption=$_REQUEST["soption"];
$team_id = $_REQUEST["team_id"];
$bFile = $_FILES["bFile"]["name"];
$bFile2 = $_FILES["bFile2"]["name"];
$bFile3 = $_FILES["bFile3"]["name"];
//$img="";
//$img2="";
//if (!($bFile=='')){

$img = "itm_s_".$ItmID.".jpg";

$img2 = "itm_l_".$ItmID.".jpg";


$img3 = "itm_xl_".$ItmID.".jpg";

//}
//if (file_exists($itmimgs.$img) || $bFile<>''){
//$img = $img;
//}else{
//$img = '';
//}
//if (file_exists($itmimgs.$img2) || $bFile2<>''){
//$img2 = $img2;
//}else{
//$img2 = '';
//}
if($ItmID<>""){
mysql_query("DELETE FROM tbl_prods_color WHERE ItmId = ".$ItmID."");

$sql_ = "SELECT * FROM tbl_color ORDER BY ColorId";
$qry_x = mysql_query($sql_);

while ($fld=mysql_fetch_array($qry_x)){
	$color = $_POST["color".trim($fld[0])];
	if (trim($color)=="y"){
		mysql_query("INSERT INTO tbl_prods_color (ColorId,ItmId) VALUES (".$fld[0].",".$ItmID.")");
	}
}
mysql_query("DELETE FROM tbl_prod_sizes WHERE ItmId = ".$ItmID."");
$sql_ = "SELECT * FROM tbl_size ORDER BY size_id";
$qry_x = mysql_query($sql_);

while ($fld=mysql_fetch_array($qry_x)){
	$size = $_POST["size".trim($fld[0])];
	$price = $_POST["price".trim($fld[0])];
	$weight = $_POST["weight".trim($fld[0])];		
	if (trim($size)=="y"){
		mysql_query("INSERT INTO tbl_prod_sizes (size_id,ItmId,price,weight) VALUES (".$fld[0].",".$ItmID.",".$price.",".$weight.")");
	}
}
mysql_free_result($qry_x);

$qry=mysql_query("update tbl_items set ItmName='".$ItmName."',pAuth='".$pAuth."',ArtNo='".$ArtNo."',pSize='".$pSize."',ItmImg='".$img."',ItmlImg='".$img2."',soption='".$soption."',ItmDescp='".$ItmDescp."',pType='".$pType."', team_id = ".$team_id.",ItmxlImg = '".$img3."',seo_desc = '".$_REQUEST["seo_desc"]."',seo_keywords = '".$_REQUEST["seo_keywords"]."' where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){

if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$itmimgs.$img);
}
if (!($bFile2=='')){
move_uploaded_file($_FILES['bFile2']['tmp_name'],$itmimgs.$img2);
}
if (!($bFile3=='')){
move_uploaded_file($_FILES['bFile3']['tmp_name'],$itmimgs.$img3);
}
}
}
header("location:mitem.php?lvl=".$lvl."&MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."&mess=Item+updated+successfully");
?>