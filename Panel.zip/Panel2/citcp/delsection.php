<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
if($_REQUEST["SecID"]){
$qrychk=mysql_query("select * from tbl_main where SecID='".$_REQUEST["SecID"]."'") or die(mysql_error());
$qrypchk=mysql_query("select * from tbl_items where SecID='".$_REQUEST["SecID"]."'") or die(mysql_error());
if(mysql_num_rows($qrychk)>0){
	header('Location:msections.php?MSecID='.$MSecID.'&mess=This+Section+cannot+be+deleted+as+it+contains+main+categories');
}else if(mysql_num_rows($qrypchk)>0){
	header('Location:msections.php?MSecID='.$MSecID.'&mess=This+Section+cannot+be+deleted+as+it+contains+Items');
}else{
	$qry=mysql_query("select SecImg from tbl_section where Secid='".$_REQUEST["SecID"]."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
	if($qry){
		$rows=mysql_num_rows($qry);
		if($rows>0){
			$data=mysql_fetch_row($qry);
			$imgdel=$secimgs.$data[0];
		}
	}
	$qry=mysql_query("delete from tbl_section where Secid='".$_REQUEST["SecID"]."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
	if($qry){
	
		if (file_exists($imgdel)){
			unlink($imgdel);
		}
	}
	$qryRank=mysql_query("select * from tbl_section where MSecID='".$MSecID."' order by rank") or die("Invalid Sql: " . mysql_error());
		if($qryRank){
			$rows=mysql_num_rows($qryRank);
				if($rows>0){
					for($i=1;$i<=$rows;$i++){
						$data=mysql_fetch_row($qryRank);
						$qry=mysql_query("update tbl_section set Rank='".$i."' where SecID='".$data[1]."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
					}
				}
		}
header("location:msections.php?lvl=".$lvl."&MSecID=".$MSecID."&mess=Section+deleted+successfully");
	}
}
?>