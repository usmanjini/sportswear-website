<?php
if (isset($_POST["isbooking"])){
	$journey_type = $_POST["journeyType"]."";
	$mm = $_POST["mm"]."";
	$dd = $_POST["dd"]."";
	$yy = $_POST["yy"]."";
	$hrs = $_POST["hrs"]."";
	$mints = $_POST["mints"]."";
	$pickup_type = $_POST["pickup"]."";
	$pickup_terminal = $_POST["picup1"]."";
	$pickup_address = $_POST["pic_address"]."";
	$pickup_city = $_POST["city1"]."";
	$pickup_postal = $_POST["pic_postal"]."";
	$dropof_type = $_POST["dropup"]."";
	$dropof_terminal = $_POST["drop_terminal"]."";
	$dropof_address = $_POST["drop_address"]."";
	$dropof_city = $_POST["city2"]."";
	$dropof_postal = $_POST["drop_postal"]."";
	$vehicle = $_POST["vtc"]."";
	$paymethod = $_POST["paymethod"]."";
	$babyseat = $_POST["babyseat"]."";
	if (trim($babyseat)==""){
		$babyseat = 0;
	}
	$boosterseat = $_POST["boosterseat"]."";
	if (trim($boosterseat)==""){
		$boosterseat = 0;
	}
	$tour_price= str_replace(".00","",str_replace(",","",$_POST["tour_price"].""));
//	echo $tour_price;exit;
	$first_name = $_POST["first_name"]."";
	$last_name = $_POST["last_name"]."";	
	$address = $_POST["address"]."";
	$postal_code = $_POST["postal_code"]."";	
	$contact_number = $_POST["contact_number"]."";
	$email = $_POST["email"]."";				
	$sqlBk = "INSERT INTO tbl_booking (journey_type,mm,dd,yy,hrs,mints,pickup_type,pickup_terminal,pickup_address,pickup_city,pickup_postal,dropof_type,dropof_terminal ,";
	$sqlBk.= "dropof_address,dropof_city,dropof_postal,vehicle,payment_method,baby_seat,booster_seat,total_price,first_name,last_name,address,postal_code,phone,";
	$sqlBk.= "email,date_,time_,status";
	$sqlBk.= ") VALUES (";
	$sqlBk.= "'".$journey_type."',".$mm.",".$dd.",".$yy.",".$hrs.",".$mints.",".$pickup_type.",".$pickup_terminal.",'".$pickup_address."','".$pickup_city."',".$pickup_postal.",".$dropof_type.",".$dropof_terminal.",'".$dropof_address."','".$dropof_city."',".$dropof_postal.",".$vehicle.",'".$paymethod."',".$babyseat.",".$boosterseat.",".$tour_price.",'".$first_name."','".$last_name."','".$address."','".$postal_code."','".$contact_number."','".$email."','".date("Y-m-d")."','".date("H:i:s")."','p'";
	$sqlBk.= " );";
	echo $sqlBk;exit;
	$qryBk = mysql_query($sqlBk) or die(mysql_error());
	$insert_id = mysql_insert_id($connect);
	header("location:booking-email.php?id=$insert_id");
	exit;
}
?>