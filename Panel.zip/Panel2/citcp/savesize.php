<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
$sshow=$_REQUEST["show"];
if($SecName<>""){

	$qry=mysql_query("insert into tbl_size(size_name) values('".$SecName."')") or die("Invalid Values: " . mysql_error());
}
header('Location:viewsizes.php');
?>