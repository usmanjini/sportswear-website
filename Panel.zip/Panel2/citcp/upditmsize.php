<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
$ID=$_REQUEST["ID"];
if($_REQUEST["ID"]){
$qry=mysql_query("update tbl_psizes set pSize='".$_REQUEST["pSize"]."',pType='".$_REQUEST["ArtNo"]."',pArt='".$_REQUEST["pType"]."' where recid='".$ID."'") or die("Invalid Values: " . mysql_error());
}
header('Location:misizes.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID.'&SubID='.$SubID.'&ItmID='.$ItmID.'&mess=Size+updated+successfully');
?>