<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
or hoho
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              Main Sections Gallery</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form action="addsecgimg.php" enctype="multipart/form-data" method="post" name="frmnews" onSubmit="return gcheck();">
                                  <input type="hidden" name="MSecID" value="<?=$_REQUEST["MSecID"]?>">
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="ImgName" type="text" class="txtdefault" id="SecName">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile" type="file" class="txtfilefield1" id="bFile">
                                      &nbsp;&nbsp;&nbsp;591 x 116 px</td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/section_img.jpg" width="151" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query("select * from tbl_secgallery where MSecID='".$_REQUEST["MSecID"]."' order by recid") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr> 
                            <td width="43" height="20" align="center" bgcolor="<?=$Clr1 ?>"><strong class="shead">MSecID</strong></td>
                            <td width="200" height="20" align="center" bgcolor="<?=$Clr1 ?>"><strong class="shead">Image 
                              Name</strong><strong class="shead">Show</strong></td>
                            <td height="20" colspan="2" align="center" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
?>
                          <tr> 
                            <form name="frmupd<? echo($i);?>" method="post" action="editsecimg.php" onSubmit="">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="ImgID" value="<? echo($data[2]);?>">
                              <td align="center" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($i);?></td>
                              <td height="20" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[3]);?></td>
                              <td width="33" align="center" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/edit.jpg" width="43" height="24"></td>
                            </form>
                            <form name="form1" method="post" action="delsecimg.php" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="ImgID" value="<? echo($data[2]);?>">
                              <td width="45" align="center" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>