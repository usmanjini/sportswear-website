<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
$msg = $_REQUEST["msg"]."";
$id = $_REQUEST["id"]."";
if (isset($_GET["mode"])){
	$mode = " - Edit";
	$edit = true;
}else{
	$mode = "";
	$edit = false;
}
if (isset($_REQUEST["posted"])){
	include("inc-tour-edit.php");
}else{
	include("inc-tour-save.php");
}
$title = "Tour Routes";
$SQL = "SELECT * FROM tbl_tour_routes ORDER BY row_id";
$qry = mysql_query($SQL);
$x=1;
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>

<script language="javascript">
	function onload(){
		document.getElementById('title').focus();
	}
	function chkFo(){
		var fld = document.getElementById('picup');
		if (fld.value==""){
			alert('Please Enter The <?=$title?> Name');
			fld.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="550" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage <?=$title?><?=$mode?></td>
                          </tr>

                          <tr> 
                            <td valign="top"><?php if ($edit==false){?><table width="550" border="0" cellpadding="1" cellspacing="2">
<tr> 
                                    <td height="22" colspan="2" align="center" valign="middle" bgcolor="<?=$Clr2 ?>" class="error"><?=$msg?></td>
                                </tr>							
                                <form action="" method="post" name="frmTour" id="frmTour" onSubmit="return chkTour();">
<input type="hidden" id="act" name="act" value="add">                                
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Pick Up Point :</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"><select name="picup"  id="picup" style="width:150px;">
                              <option value="">Select Pickup Point</option>
<?php
$qryPic1 = mysql_query("SELECT * FROM vw_tour_route ORDER BY parent_id,title;");
while ($fldPic1 = mysql_fetch_array($qryPic1)){
?>
							   <option value="<?=$fldPic1["row_id"].""?>" <?=(trim($pictup)== trim($fldPic1["row_id"]) ? " Selected" : "")?>><?=$fldPic1["title"].""?></option>    
<?php 
}
mysql_free_result($qryPic1);
?>
                            </select>
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr> 
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Drop Off Point :</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"><select name="dropoff" id="dropoff" style="width:150px;">
                              <option value="">Select Pickup Point</option>
<?php
$qryPic1 = mysql_query("SELECT * FROM vw_tour_route ORDER BY parent_id,title;");
while ($fldPic1 = mysql_fetch_array($qryPic1)){
?>
							   <option value="<?=$fldPic1["row_id"].""?>" <?=(trim($dropoff)== trim($fldPic1["row_id"]) ? " Selected" : "")?>><?=$fldPic1["title"].""?></option>    
<?php 
}
mysql_free_result($qryPic1);
?>
                            </select>
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Distance In Km:</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"> <input name="distance" type="text" class="txtdefault" id="distance" value="<?=$distance?>" style="width:150px;"  onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" >                                      
                                    &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>								  
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="submit" value="Save <?=$title?>" ></td>
                                  </tr>
                                </form>
                              </table><?php }else{
$qryEdit = mysql_query("SELECT * FROM tbl_tour_routes WHERE row_id = ".$id."");
while ($fldEdit = mysql_fetch_array($qryEdit)){
	$pictup = $fldEdit["picup_point"]."";
	$dropoff = $fldEdit["drop_point"]."";
	$distance = $fldEdit["distance"]."";
}
mysql_free_result($qryEdit);
							  ?><table width="550" border="0" cellpadding="1" cellspacing="2">
<tr> 
                                    <td height="22" colspan="2" align="center" valign="middle" bgcolor="<?=$Clr2 ?>" class="error"><?=$msg?></td>
                                </tr>							
                                <form action="tour-routes.php?id=<?=$id?>&mode=edit&posted=1" method="post" name="frmTour" id="frmTour" onSubmit="return chkTour();">                                
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Pick Up Point :</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"><select name="picup"  id="picup" style="width:150px;" disabled="disabled">
                              <option value="">Select Pickup Point</option>
<?php
$qryPic1 = mysql_query("SELECT * FROM vw_tour_route ORDER BY parent_id,title;");
while ($fldPic1 = mysql_fetch_array($qryPic1)){
?>
							   <option value="<?=$fldPic1["row_id"].""?>" <?=(trim($pictup)== trim($fldPic1["row_id"]) ? " Selected" : "")?>><?=$fldPic1["title"].""?></option>    
<?php 
}
mysql_free_result($qryPic1);
?>
                            </select>
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr> 
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Drop Off Point :</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"><select name="dropoff" id="dropoff" style="width:150px;" disabled="disabled">
                              <option value="">Select Pickup Point</option>
<?php
$qryPic1 = mysql_query("SELECT * FROM vw_tour_route ORDER BY parent_id,title;");
while ($fldPic1 = mysql_fetch_array($qryPic1)){
?>
							   <option value="<?=$fldPic1["row_id"].""?>" <?=(trim($dropoff)== trim($fldPic1["row_id"]) ? " Selected" : "")?>><?=$fldPic1["title"].""?></option>    
<?php 
}
mysql_free_result($qryPic1);
?>
                            </select>
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="20%" height="30" align="left" valign="middle" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Distance In Km:</strong></td>
                                    <td width="80%" align="left" valign="middle" bgcolor="<?=$Clr2 ?>"> <input name="distance" type="text" class="txtdefault" id="distance" value="<?=$distance?>" style="width:150px;"  onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" >                                      
                                    &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>								  
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="submit" value="Save <?=$title?>" ></td>
                                  </tr>
                                </form>
                              </table><?php 

							  } ?></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="35" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">ID</strong></td>
                            <td width="150" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Pick Up Point</strong></td>
							<td width="150" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Drop Off Point</strong></td>
                            <td height="20" colspan="2" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
						  $x = 1;
	while ($fldTour = mysql_fetch_array($qry)){
?>
                          <tr align="center"> 
                                                          <td class="norm1" bgcolor="<?=$Clr3 ?>"><? echo($x);?></td>
<td height="20" align="left" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo(dynamics_title($fldTour["picup_point"]));?></td>
                              <td height="20" align="left" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo(dynamics_title($fldTour["drop_point"]));?></td>
                              <td width="80" bgcolor="<?=$Clr3 ?>"><strong><a href="tour-routes.php?id=<?=$fldTour["row_id"].""?>&mode=edit" class="managem">Edit </a></strong></td>
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msecgallery.php?MSecID=<?=$data[1] ?>" class="menu">Gallery</a></strong></td-->                            
                            <form name="form1" method="post" action="del-tour.php?id=<? echo($fldTour["row_id"]);?>" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">                              
                              <td width="62" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
						  $x++;
	}
?>
                        </table></td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>