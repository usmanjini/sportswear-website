<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
$SQL = "SELECT * FROM tbl_general WHERE parent_id = ".$id." ORDER BY ranking";
$qry = mysql_query($SQL);
$x=1;
while ($fld=mysql_fetch_array($qry)){
	mysql_query("UPDATE tbl_general SET ranking = ".$x." WHERE row_id = ".$fld["row_id"]."");
	$x++;
}
mysql_free_result($qry);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<? if ($detail_l==true){?>
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg.js"></script> 
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script language="JavaScript">WYSIWYG.attach('pdetail');</script>
<script src="ckeditor.js"></script>
	<link rel="stylesheet" href="sample.css">
    	<script>

		var editor;

		// The instanceReady event is fired, when an instance of CKEditor has finished
		// its initialization.
		CKEDITOR.on( 'instanceReady', function( ev ) {
			editor = ev.editor;

			// Show this "on" button.
			document.getElementById( 'readOnlyOn' ).style.display = '';

			// Event fired when the readOnly property changes.
			editor.on( 'readOnly', function() {
				document.getElementById( 'readOnlyOn' ).style.display = this.readOnly ? 'none' : '';
				document.getElementById( 'readOnlyOff' ).style.display = this.readOnly ? '' : 'none';
			});
		});

		function toggleReadOnly( isReadOnly ) {
			// Change the read-only state of the editor.
			// http://docs.ckeditor.com/#!/api/CKEDITOR.editor-method-setReadOnly
			editor.setReadOnly( isReadOnly );
		}

	</script>
<? } ?>
<script language="javascript">
	function onload(){
		document.getElementById('title').focus();
	}
	function chkFo(){
		var fld = document.getElementById('title');
		if (fld.value==""){
			alert('Please Enter The <?=$title?> Name');
			fld.focus();
			return false;
		}
		return true;
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="550" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              <?=$title?></td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="550" border="0" cellpadding="1" cellspacing="2">
                                <form action="save-gener.php?id=<?=$_REQUEST['id']?>" method="post" name="frmgen" onSubmit="return chkFo();" enctype="multipart/form-data">
<input type="hidden" id="ids" name="ids" value="<?=$_REQUEST['id']?>">                                
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="title" type="text" class="txtdefault" id="title">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <? if ($link==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>link:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="link" type="text" class="txtdefault" id="link">
                                      &nbsp;<font color="#FF0000">For example: http://www.domainname.com</font></td>
                                  </tr>                                                    
                                  <? } ?>   
                                  <? if ($extra1==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$extra_name1?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="extra1" type="text" class="txtdefault" id="extra1" <?php if ($is_num1==true){?>onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;"<?php }?>>
                                      &nbsp;<font color="#FF0000"><?=$extra_tip1?></font></td>
                                  </tr>                                                    
                                  <? } ?> 
                                  <? if ($extra2==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$extra_name2?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="extra2" type="text" class="txtdefault" id="extra2" <?php if ($is_num2==true){?>onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;"<?php }?>>
                                      &nbsp;<font color="#FF0000"><?=$extra_tip2?></font></td>
                                  </tr>                                                    
                                  <? } ?> 
                                  <? if ($extra3==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$extra_name3?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="extra3" type="text" class="txtdefault" id="extra3" <?php if ($is_num3==true){?>onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;"<?php }?>>
                                      &nbsp;<font color="#FF0000"><?=$extra_tip3?></font></td>
                                  </tr>                                                    
                                  <? } ?> 
                                  <? if ($extra4==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$extra_name4?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="extra4" type="text" class="txtdefault" id="extra4" <?php if ($is_num4==true){?>onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;"<?php }?>>
                                      &nbsp;<font color="#FF0000"><?=$extra_tip4?></font></td>
                                  </tr>                                                    
                                  <? } ?> 				  								  
                                  <? if ($detail_s==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$detail_s_str?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea name="detail1" cols="35" rows="4" class="txtnews1" id="detail1"></textarea></td>
                                  </tr>                  
                                  <? } ?> 
                                  <? if ($detail_l==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong><?=$detail_l_str?>:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><textarea  name="pdetail" cols="50" rows="15" class="ckeditor" id="editer1"></textarea></td>
                                  </tr>                  
                                  <? } ?>                                                                                 
                                  <? if ($file1==true){?>
                                  <tr> 
                                    <td width="15%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="85%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
                                      <span class="error"><?=$wfile1?> x <?=$hfile1?></span></td>
                                  </tr>
                                  <? } ?>
                  