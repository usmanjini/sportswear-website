<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
$isNew=$_REQUEST["isNew"];
if($ItmID<>""){
if($isNew=="y"){
$qry=mysql_query("update tbl_items set isNew='y' where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
}elseif($isNew=="n"){
$qry=mysql_query("update tbl_items set isNew='n' where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
}
}
header("location:mitem.php?lvl=".$lvl."&MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."&mess=Item+updated+successfully");
?>