<?
require("connection.php");
include("chksession.php");
include("fclr.inc");

if (isset($_POST['txtEmail'])) {
	$sql_txt = "INSERT IGNORE INTO newsletter SET email='{$_POST['txtEmail']}'";
	if(mysql_query($sql_txt)) {
		$mess = "Email successfully added !";
	} else {
		$mess = "ERROR / Please try again !";
	}
}
if (isset($_GET['op']) && $_GET['op']=='del') {
	$sql_txt = "DELETE FROM newsletter WHERE email_id = '".$_GET['id']."'";
	if(mysql_query($sql_txt)) {
		$mess = "Email successfully deleted !";
	} else {
		$mess = "ERROR / Please try again !";
	}
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center">&nbsp;</td>
                    </tr>
					<?
			  	if(isset($mess)){
			  ?>
                    <tr> 
                      <td align="center"><strong><?=$mess?></strong></td>
                    </tr>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
			  <?
			  	}
			  ?>
                    <tr> 
                      <td align="center" valign="top"><table width="90%" border="0" align="center" bgcolor="<?=$Clr2 ?>">
                          <script language="javascript">
			  function Validate(f)
			  {
			  	if(f.txtEmail.value=="")
				{
					alert("Error!  id@domainname.com");
					f.txtEmail.focus();
					return false;
					
				}
				return true;
			  }
			  </script>
                          <form action="" method="post" enctype="multipart/form-data" name="form1" onSubmit="return Validate(form1);">
                            <tr align="center"> 
                              <td height="20" colspan="2" bgcolor="<?=$Clr1?>" class="mhead"><strong>&nbsp;Add 
                                New Email</strong></td>
                            </tr>
                            <tr> 
                              <td width="30%" align="right" class="norm"><strong>Email:</strong></td>
                              <td class="error"><label> 
                                <input name="txtEmail" type="text" class="txtfilefield1" id="txtEmail2" size="45">
                                &nbsp;* </label></td>
                            </tr>
                            <tr> 
                              <td align="right"> 
                                <label></label></td>
                              <td>
<input name="image" type="image" src="img/btn_email.jpg" width="124" height="24"></td>
                            </tr>
                          </form>
                        </table>
                        
                      </td>
                    </tr>
                    <tr> 
                      <td align="center"><img src="imgs/spacer.GIF" width="1" height="30"></td>
                    </tr>
                    <?
						$sql_txt="SELECT * FROM newsletter ORDER by email_id DESC";
						$sql_query=mysql_query($sql_txt);
						if(mysql_num_rows($sql_query)>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table width="90%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF"style="BORDER-COLLAPSE: collapse">
                          <tr valign="middle"> 
                            <td width="89%" height="22" bgcolor="<?=$Clr1 ?>" class="shead"><strong>&nbsp;Manage 
                              Newsletter Emails</strong></td>
                            <td width="11%" height="22" align="center" bgcolor="<?=$Clr1?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
			  $rClr="E6E6E6";
				while($rs=mysql_fetch_array($sql_query))
				{
				if($rClr=="E6E6E6"){
					$rClr="F7F7F7";
				}else{
					$rClr="E6E6E6";
				}		
			?>
                          <tr valign="middle" bgcolor="<?=$rClr?>"> 
                            <td height="19" class="norm"> &nbsp; 
                              <?=$rs["email"]?>
                            </td>
                            <td height="19" bgcolor="<?=$rClr?>"> <table width="70" border="0" align="center" cellpadding="2" cellspacing="0">
                                <tr align="center" valign="middle"> 
                                  <td width="35"><a href="editemail.php?id=<?=$rs["email_id"]?>"><img src="img/edit.jpg" width="43" height="24" border="0"></a></td>
                                  <td width="35"><a href="newsletters.php?op=del&id=<?=$rs['email_id']?>" onClick="return confirm('Are you sure to delete this Email Address');"><img src="img/delete.jpg" width="59" height="24" border="0"></a></td>
                                </tr>
                              </table></td>
                          </tr>
                          <?
			
			}//end while
			?>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>