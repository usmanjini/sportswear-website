<?
require("connection.php");
require("chksession.php");
$news=$_REQUEST["news"];
if($news<>""){
$qryRank=mysql_query("select rank from tbl_news order by rank desc") or die("Invalid Values: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}
$qry=mysql_query("insert into tbl_news(news,ntitle,nDate,Rank) values('".$_REQUEST["news"]."','".$_REQUEST["ntitle"]."','".$_REQUEST["nDate"]."','".$Rank."')") or die("Invalid Values: " . mysql_error());
if($qry){
header('Location:mnews.php');
}
}
?>