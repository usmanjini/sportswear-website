<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$MainName=$_REQUEST["MainName"];
$soption=$_REQUEST["soption"];
$bFile = $_FILES["bFile"]["name"];
$img="";
//if (!($bFile=='')){
$img = "main_".$MainID.".jpg";
//}
if (file_exists($mainimgs.$img) || $bFile<>''){
$img = $img;
}else{
$img = '';
}
if($MainID<>""){
$qry=mysql_query("update tbl_main set MainName='".$MainName."',MainImg='".$img."',soption='".$soption."' where MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
$img = "main_".$MainID.".jpg";
move_uploaded_file($_FILES['bFile']['tmp_name'],$mainimgs.$img);
}
}
}
header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID.'&mess=Main+Category+updated+successfully');
?>