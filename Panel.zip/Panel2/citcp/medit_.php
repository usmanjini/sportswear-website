<?
require("connection.php");
require("chksession.php");
$id = $_REQUEST["id"];
$ispost = $_REQUEST["ispost"]."";
if (trim($ispost)=="y"){
//-----------Save File 1---------------///
	$file1 = "level_".$id.".jpg";
	if ($_FILES["file1"]["error"] > 0){
	  //echo "Error: " . $_FILES["file1"]["error"] . "<br />";
	}else{
		 move_uploaded_file($_FILES["file1"]["tmp_name"],$simgs.$file1);

	}
	mysql_query("UPDATE tbl_mainsection SET file1 = '".$file1."' WHERE MSecID = $id");
	echo "<script language=javascript>opener.window.location.href='main-sections.php';</script>";
	echo "<script language=javascript>window.close();</script>";
	exit;
}else{
	$qry = mysql_query("SELECT * FROM tbl_mainsection WHERE MSecID = $id");
	$fld = mysql_fetch_array($qry);
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="styles.css">
<title>Edit Level 1 Image</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td align="center" valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
      <form action="" method="post" enctype="multipart/form-data" name="frmnews" id="frmnews" onsubmit="return checkmsecForm();">
      <input type="hidden" id="ispost" name="ispost" value="y">
        <tr>
          <td height="30" colspan="2" align="center" valign="middle" bgcolor="<?=$Clr2 ?>" class="CPname">Edit Level 1 Image</td>
          </tr>
        <tr>
          <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
          <td align="left" bgcolor="<?=$Clr2 ?>"><img src="<?=$simgs.$fld["file1"].""?>" width="82" height="82" /></td>
        </tr>        
        <tr>
          <td width="16%" height="21" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
          <td width="84%" align="left" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
              <span class="error">870 x 150</span></td>
        </tr>

        <tr>
          <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
          <td align="left" bgcolor="<?=$Clr2 ?>"><input type="image" src="img/update.jpg" /></td>
        </tr>
      </form>
    </table></td>
  </tr>
</table>
</body>
</html>
