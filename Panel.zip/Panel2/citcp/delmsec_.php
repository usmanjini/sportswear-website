<?
require("connection.php");
require("chksession.php");
$recid = $_REQUEST['RecID']."";
$msecid = $_REQUEST['MSecID']."";
if(trim($msecid)!=""){
	$qrychk=mysql_query("SELECT * FROM tbl_mainsection WHERE parent=".$recid."") or die(mysql_error());
	if(mysql_num_rows($qrychk)>0){
		header('location:main-sections.php?mess=This+Main+Section+has+section,+Please+delete+them+first');
		exit;
	}else{
		$qry=mysql_query("DELETE FROM tbl_mainsection WHERE RecID=".$recid." AND parent=0") or die("Invalid Values: " . mysql_error());
	//	$qryRank=mysql_query("select * from tbl_mainsection order by rank") or die("Invalid Sql: " . mysql_error());
	//		if($qryRank){
	//			$rows=mysql_num_rows($qryRank);
	//				if($rows>0){
	//					for($i=1;$i<=$rows;$i++){
	//						$data=mysql_fetch_row($qryRank);
	//						$qry=mysql_query("update tbl_mainsection set Rank='".$i."' where MSecID='".$data[1]."'") or die("Invalid Values: " . mysql_error());
	//					}
	//				}
	//		}
	}
header("location:main-sections.php");
}
?>