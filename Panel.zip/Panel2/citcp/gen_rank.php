<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["MSecID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
$parent_id = $_REQUEST["parent_id"]."";
if(isset($_REQUEST["MSecID"])){	
	$query = "SELECT * FROM tbl_general WHERE ranking ='".$Newrank."'";
	$open = mysql_query($query);
	if ($open){
		$rows = mysql_num_rows($open);
		if ($rows>0){
			$frows = mysql_fetch_row($open);
			$GetMSecID = $frows[1];
				$Query = "UPDATE tbl_general SET ranking = ".$Newrank." WHERE row_id = ".$MSecID."";
//				echo $Query."<br/>";
				$q1 = mysql_query($Query);
	
				$Query = "UPDATE tbl_general SET ranking = ".$Oldrank." WHERE row_id = ".$GetMSecID."";
//				echo $Query;
				$q2 = mysql_query($Query);
		}
	}

}
header("location:view-general.php?id=$parent_id");
?>