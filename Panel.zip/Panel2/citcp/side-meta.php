<?php 
if ($seo==true){
?>
  <tr> 
    <td height="20" valign="middle" bgcolor="1e76c0" class="Navigation">&nbsp;&nbsp;&nbsp;&nbsp;Meta Tags</td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="meta-tags-products.php" class="menu">Products</a></td>
  </tr>
  <tr> 
    <td height="2"><img src="img/msep.jpg" width="177" height="2"></td>
  </tr>
  <tr> 
    <td height="20">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="meta-tags-contents.php" class="menu">General Contents</a></td>
  </tr> 
<?php } ?>  