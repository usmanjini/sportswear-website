<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$MSecID=$_REQUEST['MSecID'];
$SecID=$_REQUEST['SecID'];
$MainID=$_REQUEST['MainID'];
$qry=mysql_query("select * from tbl_mainsection where MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MSecName=$data[2];
	}
}
mysql_free_result($qry);
$qry=mysql_query("select * from tbl_section where SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$SecName=$data[3];
	}
}
mysql_free_result($qry);
$qry=mysql_query("select * from tbl_main where MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MainName=$data[4];
	}
}
mysql_free_result($qry);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              Sub Categories</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form action="addscat.php" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checksCatForm();">
                                  <input type="hidden" name="MSecID" value="<?=$MSecID?>">
                                  <input type="hidden" name="SecID" value="<?=$SecID?>">
                                  <input type="hidden" name="MainID" value="<?=$MainID?>">
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="SubName" type="text" class="txtdefault" id="SubName"></td>
                                  </tr>
                                  <tr> 
                                    <td height="20" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Option:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="6%"><input name="soption" type="radio" value="y" checked></td>
                                          <td width="13%" class="norm1">Enable</td>
                                          <td width="5%"><input type="radio" name="soption" value="n"></td>
                                          <td width="76%" class="norm1">Disable</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                  <!--tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;<strong>&nbsp;Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile" type="file" class="txtfilefield1" id="bFile"></td>
                                  </tr-->
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/add_sub_cat.jpg" width="130" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" class="norm1"><strong><a href="mmainsections.php" class="managem">Top</a> 
                        &raquo; <a href="msections.php?MSecID=<?=$MSecID?>" class="managem"> 
                        <?=$MSecName?>
                        </a> &raquo; <a href="mcategories.php?MSecID=<?=$MSecID?>&SecID=<?=$SecID?>" class="managem"> 
                        <?=$SecName?>
                        </a> &raquo; 
                        <?=$MainName?>
                        </strong></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query("select * from tbl_sub where MSecID='".$MSecID."' and SecID='".$SecID."' and MainID='".$MainID."' order by rank") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="40" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">SubID</strong></td>
                            <td width="125" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Name</strong></td>
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Option</strong></td>
                            <td height="20" colspan="4" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
	if(!($data[6]=='')){
		$Lnk=$data[6];
	}else{
		$Lnk='&nbsp;';
	}
	if($data[9]=='y'){
		$sOption="Enabled";
	}elseif($data[9]=='n'){
		$sOption="Disabled";
	}
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="editsubcat.php">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[4]);?></td>
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[5]);?></td>
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"> 
                                <?=$sOption?>
                              </td>
                              <td bgcolor="<?=$Clr3 ?>" width="12"><input type="image" src="img/edit.jpg" width="43" height="24"></td>
                            </form>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><strong></strong><a href="mcategories.php?MSecID=<?=$MSecID?>&SecID=<?=$data[2]?>" class="managem"></a><a href="mitem.php?MSecID=<?=$MSecID?>&SecID=<?=$SecID?>&MainID=<?=$data[3]?>&SubID=<?=$data[4]?>" class="managem"><strong>Items</strong></a></td>
                            <form name="frmRank<? echo($i);?>" method="post" action="scatrank.php" onSubmit="return checklrForm<? echo($i);?>()">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[10]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="10"><input name="txtrank" type="text" class="txtnorm1" id="txtrank5" value="<? echo($data[10]);?>" size="3"></td>
                            </form>
                            <form name="form1" method="post" action="delscat.php" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="10"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>