<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$id = $_GET['id']."";
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><? include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">
<table width="80%" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Product Gallery</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellpadding="1" cellspacing="2">
                                <form action="addgallery.php" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checkprd_gallery();">
                                <input type="hidden" id="ItmId" name="ItmId" value="<?=$id?>">
                                  <tr> 
                                    <td width="29%" bgcolor="<?=$Clr2 ?>">&nbsp;<strong>Small 
                                      &nbsp;Image:</strong></td>
                                    <td width="71%" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtfilefield1" id="file1">                                      
                                      &nbsp;<font color="#FF0000">*&nbsp;300 px 
                                      300 px</font></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>"><strong>&nbsp;Large 
                                      Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="file2" type="file" class="txtfilefield1" id="file2">
                                      &nbsp;<font color="#FF0000">*&nbsp;600 x 
                                      600 px</font></td>
                                  </tr>
                                  <!--tr> 
                                    <td bgcolor="<?=$Clr2 ?>"><strong>&nbsp;Xtra 
                                      Large Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile3" type="file" class="txtfilefield1" id="bFile3">
                                      &nbsp;<font color="#FF0000">&nbsp;&nbsp;Unlimited 
                                      Size</font></td>
                                  </tr-->
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="submit" value="Save Image"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query("SELECT * FROM tbl_prd_gallery WHERE ItmId = ".$id." ORDER BY image_id") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table width="400" border="1" cellpadding="0" cellspacing="0" bordercolor="#E8EEF3" style="border-collapse:collapse;">
                        <tr>
                          <td align="left" valign="top"><table width="400" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td width="53" height="20" align="center" bgcolor="#E8EEF3"><strong>Rank</strong></td>
                              <td width="190" align="center" bgcolor="#E8EEF3"><strong>Image</strong></td>
                              <td width="157" align="center" bgcolor="#E8EEF3"><strong>Action</strong></td>
                            </tr>
                            <? 
							$a = 1;
							while ($fld = mysql_fetch_array($qry)){ ?>
                            <form method="post" action="updateprdrank.php">
                            <tr>
                              <td height="20" align="center">
          <input type="hidden" style="width:50px;" name="image_id" id="image_id" value="<?=$fld['image_id']?>"/> 
             <input type="hidden" style="width:50px;" name="prd_id" id="prd_id" value="<?=$id?>"/> 
                              
                              <input type="text" style="width:50px;" name="gallrank" id="gallrank" value="<?=$fld['gallrank']?>"/></td>
                              <td height="80" align="center"><table border="1" cellpadding="0" cellspacing="0" bordercolor="#E8EEF3" style="border-collapse:collapse;">
                                <tr>
                                  <td align="center"><img src="<?=$itmimgs.$fld['file1']?>" width="70" height="70"></td>
                                </tr>
                              </table>                                </td>
                              <td align="center"><button type="submit" >Update Rank</button></a> | <a href="del_image.php?id=<?=$id?>&rid=<?=$fld["image_id"]?>" class="CPname" onClick="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">Delete</a></td>
                            </tr>
                            <tr>
                              <td height="1" colspan="3" bgcolor="#E8EEF3"></td>
                              </tr>  
                              </form>                          
                            <? 
								$a++;
							}?>
                            
                          </table></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>