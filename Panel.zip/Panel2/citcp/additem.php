<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
if($SecID==''){
$SecID=0;
}
$MainID=$_REQUEST["MainID"];
if($MainID==''){
$MainID=0;
}
$SubID=$_REQUEST["SubID"];
if($SubID==''){
$SubID=0;
}
$ArtNo=$_REQUEST["ArtNo"];
$ItmName=$_REQUEST["ItmName"];
$pType=$_REQUEST["pType"];
$pSize=$_REQUEST["pSize"];
$pAuth=$_REQUEST["pAuth"];
$team_id = $_REQUEST["team_id"];
$ItmDescp=$_REQUEST["ItmDescp"];
$bFile = $_FILES["bFile"]["name"];
$bFile2 = $_FILES["bFile2"]["name"];
$bFile3 = $_FILES["bFile3"]["name"];
$img="";
$img2="";
$img3="";
if($ItmName<>""){

$qryItmID=mysql_query("select ItmID from tbl_items order by ItmID desc") or die("Invalid Values: " . mysql_error());
if($qryItmID){
	$rows=mysql_num_rows($qryItmID);
	if($rows>0){
		$data=mysql_fetch_row($qryItmID);
		$ItmID=$data[0]+1;
	}else{
		$ItmID=1;
	}
}
if (!($bFile=='')){
$img = "itm_s_".$ItmID.".jpg";
}
if (!($bFile2=='')){
$img2 = "itm_l_".$ItmID.".jpg";
}
if (!($bFile3=='')){
$img3 = "itm_xl_".$ItmID.".jpg";
}
$qryRank=mysql_query("select rank from tbl_items where MSecID='".$MSecID."' and SecID='".$SecID."' and MainID='".$MainID."' and SubID='".$SubID."' order by rank desc") or die("Invalid Values: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}
$sql_ = "SELECT * FROM tbl_color ORDER BY ColorId";
$qry_x = mysql_query($sql_);

while ($fld=mysql_fetch_array($qry_x)){
	$color = $_POST["color".trim($fld[0])];
	if (trim($color)=="y"){
		mysql_query("INSERT INTO tbl_prods_color (ColorId,ItmId) VALUES (".$fld[0].",".$ItmID.")");
	}
}
mysql_free_result($qry_x);

$sql_ = "SELECT * FROM tbl_size ORDER BY size_id";
$qry_x = mysql_query($sql_);

while ($fld=mysql_fetch_array($qry_x)){
	$size = $_POST["size".trim($fld[0])];
	$price = $_POST["price".trim($fld[0])];
	$weight = $_POST["weight".trim($fld[0])];		
	if (trim($size)=="y"){
		mysql_query("INSERT INTO tbl_prod_sizes (size_id,ItmId,price,weight) VALUES (".$fld[0].",".$ItmID.",".$price.",".$weight.")");
	}
}
mysql_free_result($qry_x);

$qry=mysql_query("insert into tbl_items(MSecID,SecID,MainID,SubID,ItmID,ItmName,ItmDescp,ItmImg,ItmlImg,Rank,ArtNo,pSize,pType,pAuth,ItmxlImg,team_id,parent,seo_desc,seo_keywords) values('".$MSecID."','".$SecID."','".$MainID."','".$SubID."','".$ItmID."','".$ItmName."','".$ItmDescp."','".$img."','".$img2."','".$Rank."','".$ArtNo."','".$pSize."','".$pType."','".$pAuth."','".$img3."',".$team_id.",".$lvl.",'".$_REQUEST["seo_desc"]."','".$_REQUEST["seo_keywords"]."')") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$itmimgs.$img);
}
if (!($bFile2=='')){
move_uploaded_file($_FILES['bFile2']['tmp_name'],$itmimgs.$img2);
}
if (!($bFile3=='')){
move_uploaded_file($_FILES['bFile3']['tmp_name'],$itmimgs.$img3);
}
}
}
header("location:mitem.php?lvl=".$lvl."&MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."&mess=Item+added+successfully");
?>