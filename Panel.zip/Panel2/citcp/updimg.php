<?
require("connection.php");
require("chksession.php");
$imgLoc=$_REQUEST["imgLoc"];
$ItmID=$_REQUEST["imgID"];
$ItmName=$_REQUEST["ImgName"];
$bFile = $_FILES["bFile"]["name"];
//	if (!($bFile=='')){
	$img = "img_".$ItmID.".jpg";
//	}
	if($ItmID<>""){
		$qry=mysql_query("update tbl_gallery set imgname='".$ItmName."',img='".$img."',imgLoc='".$imgLoc."' where imgID='".$ItmID."'") or die("Invalid Values: " . mysql_error());
		if($qry){
			if (!($bFile=='')){
			$img = "img_".$ItmID.".jpg";
			move_uploaded_file($_FILES['bFile']['tmp_name'],$bimgs.$img);
			}
		}
	}
header('Location:mgallery.php?mess=Item+updated+successfully');
?>