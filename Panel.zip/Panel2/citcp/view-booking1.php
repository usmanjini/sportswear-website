<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
$mm = $_REQUEST["mm"]."";
$dd = $_REQUEST["dd"]."";
$yy = $_REQUEST["yy"]."";
$booking_no = $_REQUEST["booking_no"]."";
if (trim($booking_no)==""){	
	$SQL = "SELECT * FROM tbl_booking WHERE (mm = '".$mm."' AND dd = '".$dd."' AND yy = '".$yy."') ORDER BY row_id ";
	$bread = "Month ".month_name($mm,false).", Day $dd, Year $yy";
}else{
	$bread = "Booking No = ".$booking_no."";
	$SQL = "SELECT * FROM tbl_booking WHERE row_id = ".$booking_no." ORDER BY row_id DESC";
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td height="20" align="center" valign="bottom"><h3><?=$bread?></h3></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);

if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="71" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Order No</strong></td>
                            <td width="318" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Customer Name</strong></td>
                            <td width="112" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
?>
                          <tr align="center">
                              <td class="norm1" bgcolor="<?=$Clr3 ?>"><? echo($data[0]);?></td>
                              <td height="20" align="left" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<?=$data[22]." ".$data[23]?></td>
                              <td bgcolor="<?=$Clr3 ?>"><a href="vw-book.php?id=<?=$data[0]?>" class="managem" target="_blank">View Details </a></td>
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msecgallery.php?MSecID=<?=$data[1] ?>" class="menu">Gallery</a></strong></td-->                           
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <?
}
if (mysql_num_rows($qry)==0){
?>
                    <tr> 
                      <td height="20" align="center" valign="middle"><h3 style="color:#FF0000;">No record found.</h3></td>
                    </tr>
<?php
	}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>