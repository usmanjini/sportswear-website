<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
$colorno=$_REQUEST["colorno"];
if($SecName<>""){

	$qry=mysql_query("UPDATE tbl_color SET ColorName = '".$SecName."' WHERE ColorId = ".$colorno."") or die("Invalid Values: " . mysql_error());
}
header('Location:viewcolors.php');
?>