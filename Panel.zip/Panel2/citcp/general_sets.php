<?php
	$id = $_REQUEST['id']."";
	if (trim($id)=="1"){
		$title = "Banners limit 2";
		$link = true;
		
		$detail_s = true;
		$detail_l = false;
		
		$file1 = true;
		$file2 = false;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "brand";
		$filname2 = "file2";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 570;
		$hfile1 = 250;
		$wfile2 = 250;
		$hfile2 = 350;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;		
	}else if (trim($id)=="2"){
		$title = "Side Banners";
		$link = true;
		
		$detail_s = true;
		$detail_l = false;
		
		$file1 = true;
		$file2 = false;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "footer-banners";
		$filname2 = "file2";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 370;
		$hfile1 = 508;
		$wfile2 = 250;
		$hfile2 = 350;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;	
	}else if (trim($id)=="3"){
		$title = "Quick Links";
		$link = true;
		
		$detail_s = false;
		$detail_l = false;
		
		$file1 = false;
		$file2 = false;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "team";
		$filname2 = "file2";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 120;
		$hfile1 = 120;
		$wfile2 = 250;
		$hfile2 = 350;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;	
	}else if (trim($id)=="4"){
		$title = "Banner single";
		$link = true;
		
		$detail_s = false;
		$detail_l = false;
		
		$file1 = true;
		$file2 = false;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "banner_single";
		$filname2 = "file2";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 770;
		$hfile1 = 240;
		$wfile2 = 250;
		$hfile2 = 350;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;	
	}else if (trim($id)=="5"){
		$title = "Advertisement 2";
		$link = true;
		
		$detail_s = false;
		$detail_l = false;
		
		$file1 = true;
		$file2 = false;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "advertisement";
		$filname2 = "file2";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 120;
		$hfile1 = 120;
		$wfile2 = 250;
		$hfile2 = 350;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;			
	}
	else if (trim($id)=="6"){
		$title = "Dynamics Banner";
		$link = true;
		
		$detail_s = true;
		$detail_l = false;
		
		$file1 = true;
		$file2 = true;
		$file3 = false;
		$file4 = false;
		
		$filname1 = "banner";
		$filname2 = "thumb";
		$filname3 = "file3";
		$filname4 = "file4";		
		
		$filext1 = ".jpg";
		$filext2 = ".jpg";
		$filext3 = ".jpg";
		$filext4 = ".jpg";
		
		$wfile1 = 1305;
		$hfile1 = 600;
		$wfile2 = 120;
		$hfile2 = 50;
		$wfile3 = 450;
		$hfile3 = 550;
		$wfile4 = 650;
		$hfile4 = 750;			
	}
?>