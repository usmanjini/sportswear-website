<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["MSecID"];
$SecID = $_REQUEST["SecID"];
$MainID = $_REQUEST["MainID"];
$SubID = $_REQUEST["SubID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
if($_REQUEST["SubID"]){

	$query = "select * from tbl_sub where rank='".$Newrank."' and MSecID='".$MSecID."' and SecID='".$SecID."' and MainID='".$MainID."'";
	$open = mysql_query($query);
	if ($open){
		$rows = mysql_num_rows($open);
		if ($rows>0){
			$frows = mysql_fetch_row($open);
			$GetSubId = $frows[4];
				$Query = "Update tbl_sub set rank='".$Newrank."' where SubID='".$SubID."'";
				$open = mysql_query($Query);
	
				$Query = "Update tbl_sub set rank='".$Oldrank."' where SubID='".$GetSubId."'";
				$open = mysql_query($Query);
		}
	}

}
header('Location:msubcats.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID);
?>