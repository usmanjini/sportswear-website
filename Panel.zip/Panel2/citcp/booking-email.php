<?php include("cn.php");
$qry = mysql_query("SELECT * FROM tbl_booking WHERE (row_id = ".$id.")");
while ($fld = mysql_fetch_array($qry)){
	$str = "";
	$str.= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$str.=  "<tr>";
	$str.= "<td height='24' colspan='2' align='center' bgcolor='#E9E9E9'><font size='2' face='Verdana'><strong>".$Company." - Online booking</strong></font></td>";
	$str.=  "</tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Booking Id: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><strong>".$fld['row_id']."</strong></font></td></tr>";					
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Booking Type: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['journey_type']."</font></td></tr>";				
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Journey Date: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['dd']."-".month_name($fld['mm'],false)."-".$fld['yy']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Time Of Collection: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['hrs'].":".$fld['mints']."</font></td></tr>";
	$str.=  "<tr>";
if (trim($fld["pickup_type"])=="1"){
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up Point : </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><b>Airport</b></font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up Terminal: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".terminal_name($fld['pickup_terminal'])."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Flight No: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['flight_no']."</font></td></tr>";	
	$str.=  "<tr>";
}else{
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up Point: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><b>Address<b/></font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up Address: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['pickup_address']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up City: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['pickup_city']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Pick Up Postal: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".trim($fld['pickup_postal'])."</font></td></tr>";
	$str.=  "<tr>";
}
if (trim($fld["dropof_type"])=="1"){
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of Point : </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><b>Airport</b></font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of Terminal: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".terminal_name($fld['dropof_terminal'])."</font></td></tr>";
	$str.=  "<tr>";
}else{
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of Point: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><b>Address<b/></font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of Address: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['dropof_address']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of City: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['dropof_city']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Drop Of Postal: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".trim($fld['dropof_postal'])."</font></td></tr>";
	$str.=  "<tr>";
}

	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Preferred Vehicle: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".dynamics_title($fld['vehicle'])."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Payment Method: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['payment_method']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Baby Seat: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".dynamics_title($fld['baby_seat'])."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Booster Seat: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".dynamics_title($fld['booster_seat'])."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Journey Cost: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'><strong>$cur ".number_format($fld['total_price'],2,'.',',')."</strong></font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'></font></td>";
	$str.=  "<td align='left'>&nbsp;</td></tr>";	
	$str.=  "<tr>";
	$str.= "<td height='24' colspan='2' align='center' bgcolor='#E9E9E9'><font size='2' face='Verdana'><strong>Personal Information</strong></font></td>";
	$str.=  "</tr>";	
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>First Name: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['first_name']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Last Name: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['last_name']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Home Address: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['address']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Post Code: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['postal_code']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Contact Number: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['phone']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Email Address: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['email']."</font></td></tr>";
	$str.=  "<tr>";
	$str.=  "<td width='50%' align='left'><font size='2' face='Verdana'>Dated: </font></td>";
	$str.=  "<td align='left'><font size='2' face='Verdana'>".$fld['date_']."</font></td></tr>";
	$str.=  "</table>";	
//	echo $str;exit;
$em="hassan@citsite.com";
	$from  = $EmlTo;
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'From: GB Airport Transfer"<'.$from.'>' . "\r\n";
	$headers .= 'Cc: <'.$fld['email'].'>' . 'to: <'.$em.'>' . "\r\n";
	$headers .= 'Cc: <'.$em.'>' . "\r\n";	
	$subject = "Online Booking";
	@mail($from, $subject, $str, $headers);	
	if (trim($fld['payment_method'])=="cash"){
		$link = "booking-successful.php?booking_id=".$id."";
	}else{
		$link = "go-payment.php?booking_id=".$id."";
	}
	header("location:$link");exit;
}
mysql_free_result($qry);
?>