<?
require("connection.php");
$isError=false;
$usrname="";
$password="";
if(isset($_REQUEST["usrname"])){
$qry=mysql_query("select * from tbl_admin where usrname='".$_REQUEST["usrname"]."' and password='".$_REQUEST["password"]."'") or die("Error " .mysql_error());
	if($qry){
		$rows = mysql_num_rows($qry);
		if($rows>0){
		$data=mysql_fetch_row($qry);
			$_SESSION['usrname']=$_REQUEST["usrname"];
			$_SESSION['fname']=$data[4];
			$_SESSION['logged']=true;
			header('Location:index.php');
		}else{
			$isError=true;
		}
	}
$usrname=$_REQUEST["usrname"];
$password=$_REQUEST["password"];
}

/*if(isset($_REQUEST["err"])){
$isError=true;
}*/
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="javascript:document.frm.usrname.focus();">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td align="center"><table width="520" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td><table width="520" height="370" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td height="10"><img src="img/l1.jpg" width="520" height="10"></td>
              </tr>
              <tr> 
                <td height="350" valign="top"><table width="520" height="350" border="0" cellpadding="0" cellspacing="0">
                    <tr valign="top"> 
                      <td width="10"><img src="img/lshade1.jpg" width="10" height="350"></td>
                      <td width="500"><table width="500" height="350" border="0" cellpadding="0" cellspacing="0">
                          <tr> 
                            <td height="19"><table width="500" height="19" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="20" height="19"><img src="img/t1.jpg" width="20" height="19"></td>
                                  <td height="19" background="img/t2.jpg"><img src="img/spacer.gif" width="1" height="19"></td>
                                  <td width="107" height="19"><img src="img/t3.jpg" width="107" height="19"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="25"><table width="500" height="25" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td background="img/t4.jpg">&nbsp;</td>
                                  <td width="107"><img src="img/t5.jpg" width="107" height="25"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="27"><table width="500" height="27" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="20" height="27" background="img/t6.jpg">&nbsp;</td>
                                  <td width="373"><img src="img/t7.jpg" width="373" height="27"></td>
                                  <td width="107"><img src="img/t8.jpg" width="107" height="27"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="20"><table width="500" height="20" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="30" background="img/t9.jpg">&nbsp;</td>
                                  <td width="273" valign="middle" background="img/t9.jpg" class="CName"> 
                                    <?=$Company?>
                                  </td>
                                  <td width="206"><img src="img/t10.jpg" width="205" height="20"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td align="center" valign="top"><table width="500" height="38" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="27"><img src="img/t11.jpg" width="27" height="38"></td>
                                  <td width="268"><img src="img/t12.jpg" width="268" height="38"></td>
                                  <td width="205"><img src="img/t13.jpg" width="205" height="38"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="202" align="center" valign="top" background="img/lbg.jpg"><table width="500" height="202" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td align="center" valign="top"><table width="500" border="0" cellspacing="0" cellpadding="0">
                                      <tr valign="top"> 
                                        <td width="27"><img src="img/spacer.gif" width="27" height="1"></td>
                                        <td width="257" align="center"><table width="257" border="0" cellspacing="0" cellpadding="3">
                                            <form name="frm" method="post" action="login.php">
                                              <?
												if($isError==true){
											?>
                                              <tr align="center"> 
                                                <td height="30" colspan="2" class="lbtm2">Invalid 
                                                  Username / password</td>
                                              </tr>
                                              <?
												}
											?>
                                              <tr> 
                                                <td width="74" align="right" class="lbtm"><strong>Login:&nbsp;</strong></td>
                                                <td width="171"><input name="usrname" type="text" class="txtdefault" id="usrname" value="<?=$usrname?>"></td>
                                              </tr>
                                              <tr> 
                                                <td align="right" class="lbtm"><strong>Password:&nbsp;</strong></td>
                                                <td><input name="password" type="password" class="txtdefault" id="password" value="<?=$password?>"></td>
                                              </tr>
                                              <tr> 
                                                <td>&nbsp;</td>
                                                <td><input name="image" type="image" src="img/connect.jpg" width="78" height="26"></td>
                                              </tr>
                                            </form>
                                          </table></td>
                                        <td width="216" align="right"><img src="img/t14.jpg" width="216" height="29"></td>
                                      </tr>
                                    </table></td>
                                </tr>
                                <tr> 
                                  <td align="center" valign="bottom" class="lbtm">&copy; 
                                    Copyrights 2010-2011 All rights reserved by: 
                                    <span class="lbtm2"> 
                                    <?=$Company?>
                                    </span></td>
                                </tr>
                                <tr> 
                                  <td align="center" valign="top" class="lbtm">Designed 
                                    &amp; Developed By: <a href="<?=$owner_email?>" target="_blank" class="lbtm2"><?=$owner?></a></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="19"><table width="500" height="19" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="20" height="19"><img src="img/b1.jpg" width="20" height="19"></td>
                                  <td height="19" background="img/b2.jpg"><img src="img/spacer.gif" width="1" height="19"></td>
                                  <td width="23" height="19"><img src="img/b3.jpg" width="23" height="19"></td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                      <td width="10"><img src="img/rshade.jpg" width="10" height="350"></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="10"><img src="img/l3.jpg" width="520" height="10"></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>