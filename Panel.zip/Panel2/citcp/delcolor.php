<?
require("connection.php");
require("chksession.php");
$color_id = $_REQUEST["color_id"];

if($color_id<>""){
	$qry=mysql_query("DELETE FROM tbl_color WHERE ColorId = ".$color_id."") or die("Invalid Values: " . mysql_error());
}
header('Location:viewcolors.php');
?>