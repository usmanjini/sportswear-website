	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="ckeditor.js"></script>
	<script src="adapters/jquery.js"></script>
    
    <script>
    	$( document ).ready( function() {
	$( 'textarea#editor1' ).ckeditor();
	$( 'textarea#ItmDescp' ).ckeditor();
} );
</script>

	<SCRIPT language=JavaScript1.1>
function test(obj,msg) {
	  var regex = /^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z0-9.-]{2,4}$/;
	  if (regex.test(obj.value))
	  {
		return true;
	  }
	  else{
		alert(msg);
		obj.focus();
		return false;
	  }
	}

function checkempty(obj,msg)
{
 if(obj.value=="")
 {
  alert(msg);
  obj.focus();
  return false;
 }
}
function checkzero(obj,msg)
{
 if(obj.value<=0)
 {
  alert(msg);
  obj.focus();
  return false;
 }
}
//////////////////////////////////////////////
///Script for News
//////////////////////////////////////////////
	function checknForm()
	{
		if (checkempty(document.frmnews.ntitle,"Information - Enter News Title")==false) return false;
		if (checkempty(document.frmnews.nDate,"Information - Enter News Date")==false) return false;
		if (checkempty(document.frmnews.news,"Information - Enter News Detail")==false) return false;
		return true;
	}
<?
$qry=mysql_query("select * from tbl_news order by rank") or die("Invalid Query ".mysql_error());
if($qry){
	$rows = mysql_num_rows($qry);
	if($rows>0){
		for($i=1;$i<=$rows;$i++){
		$data=mysql_fetch_row($qry);
?>
	function checknForm<? echo($i);?>()
	{
		if (checkempty(document.frmupd<? echo($i);?>.news,"Information - Enter News Detail")==false) return false;
		if (checkempty(document.frmupd<? echo($i);?>.ntitle,"Information - Enter News Title")==false) return false;
		if (checkempty(document.frmupd<? echo($i);?>.nDate,"Information - Enter News Date")==false) return false;
		return true;
	}
	function checknrForm<? echo($i);?>()
	{
		if (checkempty(document.frmRank<? echo($i);?>.txtrank,"Information - Enter News Rank")==false) return false;
		return true;
	}
<?
		}
	}
}
?>
//////////////////////////////////////////////
///Script for Change Pass
//////////////////////////////////////////////
	function passcheck()
	{
		if (checkempty(document.frmnews.OPass,"Information - Enter Old Password")==false) return false;
		if (checkempty(document.frmnews.NPass,"Information - Enter Old Password")==false) return false;
		if (checkempty(document.frmnews.CPass,"Information - Enter Confirm Password")==false) return false;
		if (document.frmnews.NPass.value!=document.frmnews.CPass.value){
			alert("New and Confirm password must be same");
			return false;
		}
		return true;
	}
//////////////////////////////////////////////
///Script for Main Sections
//////////////////////////////////////////////
	function checkmsecForm()
	{
		if (checkempty(document.frmnews.SecName,"Information - Enter Main Section Name")==false) return false;
		return true;
	}
	function checkzoneForm(){
		if (checkempty(document.frmnews.SecName,"Information - Enter Zone Name")==false) return false;
		return true;
	}	
	function checkcolorForm()
	{
		if (checkempty(document.frmnews.SecName,"Information - Enter Color Name")==false) return false;
		return true;
	}	
	function checksizeForm()
	{
		if (checkempty(document.frmnews.SecName,"Information - Enter Color Size")==false) return false;
		return true;
	}	
	function checkprd_gallery()
	{
		if (checkempty(document.frmnews.file1,"Information - Please select the Small Image")==false) return false;
		if (checkempty(document.frmnews.file2,"Information - Please select the Large Image")==false) return false;
		return true;
	}			
<?
$qry=mysql_query("select * from tbl_mainsection order by rank") or die("Invalid Query ".mysql_error());
if($qry){
	$rows = mysql_num_rows($qry);
	if($rows>0){
		for($i=1;$i<=$rows;$i++){
		$data=mysql_fetch_row($qry);
?>
	function checkmsecForm<? echo($i);?>()
	{
		if (checkempty(document.frmupd<? echo($i);?>.SecName,"Information - Enter Main Section Name")==false) return false;
		return true;
	}
	function checkmsecrForm<? echo($i);?>()
	{
		if (checkempty(document.frmRank<? echo($i);?>.txtrank,"Information - Enter Main Section Rank")==false) return false;
		return true;
	}
<?
		}
	}
}
?>
//////////////////////////////////////////////
///Script for Sections
//////////////////////////////////////////////
	function checksecForm()
	{
		if (checkempty(document.frmnews.SecName,"Information - Enter Section Name")==false) return false;
		return true;
	}
	function checkSeceForm()
	{
		if (checkempty(document.frmnews.SecName,"Information - Enter Section Name")==false) return false;
		return true;
	}
	
	
<?
if(isset($MSecID)){
$qry=mysql_query("select * from tbl_section where MSecID='".$MSecID."' order by rank") or die("Invalid Query ".mysql_error());
if($qry){
	$rows = mysql_num_rows($qry);
	if($rows>0){
		for($i=1;$i<=$rows;$i++){
		$data=mysql_fetch_row($qry);
?>
	function checklrForm<? echo($i);?>()
	{
		if (checkempty(document.frmRank<? echo($i);?>.txtrank,"Information - Enter Section Rank")==false) return false;
		return true;
	}
<?
		}
	}
}
}
?>
//////////////////////////////////////////////
///Script for Categories
//////////////////////////////////////////////
	function checkCatForm()
	{
		if (checkempty(document.frmnews.MainName,"Information - Enter Category Name")==false) return false;
		return true;
	}
	function checkCateForm()
	{
		if (checkempty(document.frmnews.MainName,"Information - Enter Category Name")==false) return false;
		return true;
	}
	
//////////////////////////////////////////////
///Script for Sub Categories
//////////////////////////////////////////////
	function checksCatForm()
	{
		if (checkempty(document.frmnews.SubName,"Information - Enter Sub Category Name")==false) return false;
		return true;
	}
	function checksCateForm()
	{
		if (checkempty(document.frmnews.SubName,"Information - Enter Sub Category Name")==false) return false;
		return true;
	}
	
//////////////////////////////////////////////
///Script for Items
//////////////////////////////////////////////
	function checkItmForm()
	{
//		if (checkempty(document.frmnews.ArtNo,"Information - Enter Item Article Number")==false) return false;
		if (checkempty(document.frmnews.ItmName,"Information - Enter Item Name")==false) return false;
		if (checkempty(document.frmnews.bFile,"Information - Item Small Image Here")==false) return false;
		if (checkempty(document.frmnews.bFile2,"Information - Item Large Image Here")==false) return false;
		return true;
	}
	function checkItmeForm()
	{
//		if (checkempty(document.frmnews.ArtNo,"Information - Enter Item Article Number")==false) return false;
		if (checkempty(document.frmnews.ItmName,"Information - Enter Item Name")==false) return false;
		return true;
	}
	function checkItmsizForm()
	{
		if (checkempty(document.frmnews.pSize,"Information - Enter Item Size")==false) return false;
		if (checkempty(document.frmnews.ArtNo,"Information - Enter Item Article Number")==false) return false;
		return true;
	}
	
//////////////////////////////////////////////
////
//////////////////////////////////////////////
	function gcheck()
	{
		if (checkempty(document.frmnews.ImgName,"Information - Enter Image Name")==false) return false;
		return true;
	}
///////////////////////////////////////////////

	function AdditemEmpty()
	{
		if (checkempty(document.frmnews.ArtNo,"Error! Enter Article No")==false) return false;
		if (checkempty(document.frmnews.ItmName,"Error! Enter Product Name")==false) return false;
//		if (checkempty(document.frmnews.bFile,"Error! Enter Small Image")==false) return false;
		if (checkempty(document.frmnews.bFile2,"Error! Enter Product Image")==false) return false;
		return true;
	}
///////////////////////////////////////////////

</SCRIPT>
<script language="JavaScript">
function openWin(pagename){
		microsite_window=window.open(pagename,'microsite_window','toolbar=no,location=no,borders=no,directories=no,status=no,menubar=no,scrollbars=yes,top=0,left=0,resizable=no,width=595,height=520')
	}
</script>
<SCRIPT src="input_functions.js" type=text/javascript></SCRIPT>