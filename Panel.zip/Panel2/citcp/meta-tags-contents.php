<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('SecName').focus();
	}	
	var h = 180;
	var w = 400;
	lef = (screen.width-w)/2;
	to = (screen.height-h)/2;	
    function add_main(mdi){
            url = 'medit.php?id='+mdi;			
            microsite_window=window.open(url,'microsite_window','toolbar=no,location=no,borders=no,directories=no,status=yes,menubar=no,scrollbars=no,top='+to+',left='+lef+',resizable=no,width='+w+',height='+h);
            microsite_window.focus();
    }
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<?
						}
					?>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query("select * from tbl_gen where active = 'y' order by gen_id") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table width="400" border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">S.No</strong></td>
                            <td height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Content Name</strong></td>
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Action</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_array($qry);
?>
                          <tr align="center"> 

                              <td height="24" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($i);?></td>
                              <td align="left" bgcolor="<?=$Clr3 ?>" class="norm1"><strong><?=$data["title"]?></strong></td>
                              <td height="20" bgcolor="<?=$Clr3 ?>">&nbsp;</td>
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msecgallery.php?MSecID=<?=$data[1] ?>" class="menu">Gallery</a></strong></td-->


                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>