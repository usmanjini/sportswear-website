<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$SQL = "SELECT * from tbl_mainsection WHERE parent = 0 order by rank";
$qry = mysql_query($SQL);
$x=1;
while ($fld=mysql_fetch_array($qry)){
	$sql = "UPDATE tbl_mainsection SET rank = ".$x." WHERE RecID = ".$fld["RecID"]."";
//	echo $sql."<br/>";
//	mysql_query($sql);
	$x++;
}
mysql_free_result($qry);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('SecName').focus();
	}	
	var h = 180;
	var w = 400;
	lef = (screen.width-w)/2;
	to = (screen.height-h)/2;	
    function add_main(mdi){
            url = 'medit_.php?id='+mdi;			
            microsite_window=window.open(url,'microsite_window','toolbar=no,location=no,borders=no,directories=no,status=yes,menubar=no,scrollbars=no,top='+to+',left='+lef+',resizable=no,width='+w+',height='+h);
            microsite_window.focus();
    }
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
					<tr>
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong><?=$_REQUEST["mess"]?></strong></td>
                    </tr>
					<?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              <?=$m1?></td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form action="addmainsection_.php" method="post" name="frmnews" onSubmit="return checkmsecForm();" enctype="multipart/form-data">
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="SecName" type="text" class="txtdefault" id="SecName">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Image:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="file1" type="file" class="txtdefault" id="file1" style="width:200px;"/>
                                      <span class="error">870 x 150</span></td>
                                  </tr>                                  
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Show:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr> 
                                          <td width="6%"><input name="show" type="radio" value="y" checked></td>
                                          <td width="13%">Yes</td>
                                          <td width="5%"><input type="radio" name="show" value="n"></td>
                                          <td width="76%">No</td>
                                        </tr>
                                      </table></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/addmain_section.jpg" width="121" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" class="norm1"><strong>Top</strong></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">ID</strong></td>
                            <td height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead"><?=$m1?> Name</strong></td>
                            <td width="50" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Show</strong></td>
                            <td height="20" colspan="5" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
	$qryM1 = mysql_query("SELECT * FROM tbl_mainsection WHERE parent = ".$data[0]."");
	$rcM1 = mysql_num_rows($qryM1);
	mysql_free_result($qryM1);
	
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="updmsec_.php" onSubmit="return checkmsecForm<? echo($i);?>();">
                            <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <td class="norm1" bgcolor="<?=$Clr3 ?>"><? echo($i);?></td>
                              <td class="norm1" bgcolor="<?=$Clr3 ?>"><input name="SecName" type="text" class="txtnorm2" id="SecName" value="<? echo($data[2]);?>" size="30"></td>
                              <td height="20" bgcolor="<?=$Clr3 ?>"><select name="show" class="txtdromp_menu" id="show">
                                  <option value="y"<? if($data[3]=='y'){?> selected<? }?>>Yes</option>
                                  <option value="n"<? if($data[3]=='n'){?> selected<? }?>>No</option>
                                </select></td>
                              <td width="15" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/update.jpg" width="59" height="24"></td>
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="mmainsections.php?lvl=<?=$data[0] ?>" class="managem"><?=$m2?></a></strong></td>                              
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msections.php?MSecID=<?=$data[1] ?>" class="managem">Manage Sections</a></strong></td-->
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="javascript:add_main(<?=$data[1]?>);" class="managem">Edit Image</a></strong></td>
                              <!--td bgcolor="<?=$Clr3 ?>" class="norm1"><strong><a href="msecgallery.php?MSecID=<?=$data[1] ?>" class="menu">Gallery</a></strong></td-->
                            </form>
                            <form name="frmRank<? echo($i);?>" method="post" action="msecrank_.php" onSubmit="return checkmsecrForm<? echo($i);?>()">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[4]);?>">
                              <input type="hidden" name="recid" value="<? echo($data[0]);?>">
                              <td width="26" bgcolor="<?=$Clr3 ?>"><!--select class="txtnorm1" style="width:50px;" id="txtrank" name="txtrank" onChange="javascript:document.frmRank<? echo($i);?>.submit();">
                              	<? for ($x=1;$x<=$rows;$x++){?>
                              	<option value="<?=$x?>" <? if ($x==$i){ echo " Selected";}?>><?=$x?></option>
                                <? }?>
                              </select-->
                              <input name="txtrank" type="text" class="txtnorm1" id="txtrank" value="<?=$data[4]?>" size="6" style="width:40px;text-align:center;">
                              </td>
                            </form>
                            <form name="form1" method="post" action="delmsec_.php" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <td width="45" bgcolor="<?=$Clr3 ?>"><? if ($rcM1==0){?><input type="image" src="img/delete.jpg" width="59" height="24"><? } ?></td>
                            </form>
                          </tr>
                          <?
	}
?>
                          <!--tr align="center">
                            <td height="20" colspan="7" align="right" bgcolor="<?=$Clr3 ?>" class="norm1"><input type="submit" value="Update Rank"></td>
                            <td bgcolor="<?=$Clr3 ?>">&nbsp;</td>
                          </tr-->
                        </table></td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>