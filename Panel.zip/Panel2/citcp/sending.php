<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="96%" border="0" align="center">
                            <tr align="center" bgcolor="<?=$Clr1?>"> 
                              <td class="mhead">Send Email to Users</td>
                            </tr>
			  <?
$mess="";
///Send Email - Newsletter
if(isset($_REQUEST['hdnEmail'])) {
	
	$frmName=$_REQUEST["frmName"];
	$frmEmail=$_REQUEST["frmEmail"];	
	$mess="";
	$subject = $_REQUEST['EmlSubject'];
	$MessageHTML=$_REQUEST['txtMessage'];
	$MessageHTML=str_replace("\n","<BR>",$MessageHTML);
			
	$headers = "MIME-Version: 1.0\r\n";
	$headers.= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers.= "From: ".$frmName." <".$frmEmail.">\r\n";
	$headers.= "Reply-To: ".$frmName." <".$frmEmail.">\r\n";
	
	$sql_txt="SELECT * FROM newsletter";
	$sql_query=mysql_query($sql_txt);
	$counter=1;
	while($sc=mysql_fetch_assoc($sql_query)) {		
		$to = $sc['email'];
		$counter++;	
		$tmp=explode('@',$to);
		$friend=$tmp[0];
		$message=$MessageHTML;
		mail($to, $subject, $message, $headers);
	}
	$mess="Email successfully send !";
	
}
?>
                            <tr> 
                              <td align="center" bgcolor="<?=$Clr2 ?>"><label><?=$mess?></label></td>
                            </tr>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>