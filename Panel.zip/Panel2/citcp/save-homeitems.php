<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");


$type = htmlspecialchars($_REQUEST['type'])."";
 $item = htmlspecialchars($_REQUEST['item'])."";	
$ranking = htmlspecialchars($_REQUEST['ranking'])."";	
	
?>

<?php
$SQL = "SELECT * FROM tbl_homeitems WHERE itemID = '".$item."' and type ='".$type."' ";
$qry = mysql_query($SQL);
$qryrows= mysql_num_rows($qry);

if($qryrows==0){
$qry1 = "INSERT INTO tbl_homeitems (type,itemID,ranking) VALUES ('".$type."','".$item."','".$ranking."')";
mysql_query($qry1)or "Error";
header("location:view-homeitems.php?type=".$type."&mess=Your+add+item+Sucessfully");
		
}else{	
header("location:view-homeitems.php?type=".$type."&mess=This+item+Already+added");
	
}
exit;
?>