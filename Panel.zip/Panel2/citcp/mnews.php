<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1?>" class="mhead">Manage 
                              News &amp; Updates</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form name="frmnews" method="post" action="addnews.php" onSubmit="return checknForm();">
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Title: 
                                      </strong><span class="error">*</span> </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"> <input name="ntitle" type="text" class="txtdefault" id="ntitle">
                                    </td>
                                  </tr>
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Date:&nbsp;</strong><span class="error">*</span></td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"> <input name="nDate" type="text" class="txtdefault" id="nDate">
                                      &nbsp;(YYYY-MM-DD)</td>
                                  </tr>
                                  <tr> 
                                    <td width="25%" valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;News:<span class="error">&nbsp;</span></strong><span class="error">*</span></td>
                                    <td width="75%" valign="top" bgcolor="<?=$Clr2 ?>"> 
                                      <textarea name="news" cols="30" rows="5" class="txtnews1" id="textarea"></textarea></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/add_news.jpg" width="77" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center"><img src="imgs/spacer.GIF" width="1" height="30"></td>
                    </tr>
                    <?
$qry=mysql_query("select * from tbl_news order by rank") or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td height="20" bgcolor="<?=$Clr1 ?>"><a href="#" name="n"></a><strong class="shead">Sr#</strong></td>
                            <td height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">News</strong></td>
                            <td height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Title</strong></td>
                            <td height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Date</strong></td>
                            <td height="20" colspan="3" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="updnews.php" onSubmit="return checknForm<? echo($i);?>();">
                              <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <td class="norm1"><? echo($i);?></td>
                              <td class="norm1"><textarea name="news" cols="30" rows="4" class="txtnews1" id="news"><? echo($data[1]);?></textarea></td>
                              <td class="norm1"><input name="ntitle" type="text" class="txtnorm" id="ntitle" value="<? echo($data[2]);?>" size="10"></td>
                              <td class="norm1"><input name="nDate" type="text" class="txtnorm" id="nDate" value="<? echo($data[3]);?>" size="10"></td>
                              <td><input type="image" src="img/update.jpg" width="59" height="24"></td>
                            </form>
                            <form name="frmRank<? echo($i);?>" method="post" action="newsrank.php" onSubmit="return checknrForm<? echo($i);?>()">
                              <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[4]);?>">
                              <td width="26"><input name="txtrank" type="text" class="txtnorm1" id="txtrank" value="<? echo($data[4]);?>" size="1"> 
                              </td>
                            </form>
                            <form name="form1" method="post" action="delnews.php" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <td><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>