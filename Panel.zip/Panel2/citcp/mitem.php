<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$MSecID=$_REQUEST['MSecID'];
$SecID=$_REQUEST['SecID'];
$MainID=$_REQUEST['MainID'];
$SubID=$_REQUEST['SubID'];

$SQL = "select * from tbl_items where MSecID=".$MSecID." and SecID=".$SecID." and MainID=".$MainID."  order by rank";
$qry = mysql_query($SQL);
$x=1;
while ($fld=mysql_fetch_array($qry)){
	//mysql_query("UPDATE tbl_items SET rank = ".$x." WHERE RecID = ".$fld["RecID"]."");
	$x++;
}
mysql_free_result($qry);

if($MSecID<>''){
$qry=mysql_query("select * from tbl_mainsection where MSecID='".$MSecID."' ") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MSecName=$data[2];
	}
}else{
$MSecID=0;
}
mysql_free_result($qry);
}
if($SecID<>''){
$qry=mysql_query("select * from tbl_section where SecID='".$SecID."' and SecID='".$SecID."'") or die("Invalid SecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$SecName=$data[3];
	}
}else{
$SecID=0;
}
mysql_free_result($qry);
}

if($MainID<>''){
$qry=mysql_query("select * from tbl_main where MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MainID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MainName=$data[4];
	}
}else{
$MainID=0;
}
mysql_free_result($qry);
}

if($SubID<>'' || $SubID>0){
$qry=mysql_query("select * from tbl_sub where SubID='".$SubID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$SubName=$data[5];
	}
}else{
$SubID=0;
$SubName="";
}
mysql_free_result($qry);
}else{
$SubName="";
}
$_SESSION["itempage"] = "mitem.php?MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."";
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">

<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('ArtNo').focus();
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onLoad="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><? include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">
<table width="80%" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage 
                              Item</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellpadding="1" cellspacing="2">
                                <form action="additem.php?lvl=<?=$lvl?>" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return AdditemEmpty();">
                                  <input type="hidden" name="MSecID" value="<?=$MSecID?>">
                                  <input type="hidden" name="SecID" value="<?=$SecID?>">
                                  <input type="hidden" name="MainID" value="<?=$MainID?>">
                                  <input type="hidden" name="SubID" value="<?=$SubID?>">
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Style#:</strong>                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="ArtNo" type="text" class="txtdefault" id="ArtNo"> 
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="ItmName" type="text" class="txtdefault" id="ItmName"> 
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Team:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>">
                                    <select name="team_id" class="txtdromp_menu" id="team_id" style="width:130px;">
                                    	<option value="0">None</option>
<?php $qry3 = mysql_query("SELECT * FROM tbl_general WHERE parent_id = 3 ORDER BY ranking");
while ($fld=mysql_fetch_array($qry3)){
?>
                                    	<option value="<?=$fld["row_id"]?>"><?=$fld["title"]?></option>               
<?php
}
mysql_free_result($qry3);
?>                         
                                    </select>
                                    </td>
                                  </tr>  
                                                               
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Color:</strong>                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>" class="error"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <? 
									$qry_ = mysql_query("SELECT * FROM tbl_color ORDER BY ColorId");
									while ($fld = mysql_fetch_array($qry_)){									
									?>
                                      <tr>
                                        <td width="24" height="18" align="left"><input type="checkbox" checked value="y" id="color<?php echo $fld[0];?>" name="color<?php echo $fld[0];?>"></td>
                                        <td align="left"><label for="color<?php echo $fld[0];?>"><strong><?php echo $fld[1];?></strong></label></td>
                                      </tr>
                                   <? }?>   
                                    </table></td>
                                  </tr>
                                 
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Sizes:</strong>                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>" class="error"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                      <tr>
                                        <td width="22" height="18" align="left" bgcolor="<?=$Clr1 ?>"></td>
                                        <td width="64" align="left" bgcolor="<?=$Clr1 ?>" class="shead">Size</td>
                                        <td width="77" align="left" bgcolor="<?=$Clr1 ?>"><strong class="shead">Price</strong></td>
                                        <td width="62" align="left" bgcolor="<?=$Clr1 ?>"><strong class="shead">Weigth</strong></td>
                                        </tr>                                    
                                      <? 
									  
									$qry_ = mysql_query("SELECT * FROM tbl_size ORDER BY size_id");
									while ($fld = mysql_fetch_array($qry_)){									
									?>
                                      <tr>
                                        <td width="22" height="18" align="left"><input type="checkbox" checked value="y" id="size<?php echo $fld[0];?>" name="size<?php echo $fld[0];?>"  onclick="javascript:if (size<?php echo $fld[0];?>.checked){getElementById('price<?php echo $fld[0];?>').disabled=false;getElementById('weight<?php echo $fld[0];?>').disabled=false;}else{getElementById('price<?php echo $fld[0];?>').disabled=true;getElementById('weight<?php echo $fld[0];?>').disabled=true;}"></td>
                                        <td width="64" align="left"><label for="size<?php echo $fld[0];?>"><strong><?php echo $fld[1];?></strong></label></td>
                                        <td width="77" align="left"><input type="text" class="txtdefault" name="price<?php echo $fld[0];?>" id="price<?php echo $fld[0];?>" value="0" size="6" maxlength="6" onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" disabled="disabled" style="width:40px;"></td>
                                        <td width="62" align="left"><input type="text" class="txtdefault" name="weight<?php echo $fld[0];?>" id="weight<?php echo $fld[0];?>" value="0" size="6" maxlength="6" onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" disabled="disabled" style="width:40px;"></td>
                                        </tr>
                                      <? }?>
                                    </table></td>
                                  </tr>
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Short Detail:</strong> 
                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="pAuth" type="text" class="txtdefault" id="pAuth" style="width:270px;"></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Item 
                                      Description</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><textarea name="ItmDescp" cols="35" rows="4" class="ckeditor"  id="ItmDescp"></textarea></td>
                                  </tr>
                           <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;<strong>Small 
                                      &nbsp;Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile" type="file" class="txtfilefield1" id="bFile">                                      
                                      &nbsp;<font color="#FF0000">*&nbsp;300 x 300 px</font></td>
                                  </tr>
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>"><strong>&nbsp;                                      Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile2" type="file" class="txtfilefield1" id="bFile2">
                                      &nbsp;<font color="#FF0000">* 600 x 600 px</font></td>
                                  </tr>
                                 <!-- <tr> 
                                    <td bgcolor="<?=$Clr2 ?>"><strong>&nbsp;Xtra 
                                      Large Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile3" type="file" class="txtfilefield1" id="bFile3">
                                      &nbsp;<font color="#FF0000">&nbsp;&nbsp;Unlimited 
                                      Size</font></td>
                                  </tr>-->
                          <?php if ($seo==true){?>
                                  <tr> 
                                    <td height="23" align="center" colspan="2" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                                  </tr> 
                                  <tr> 
                                    <td height="23" align="center" colspan="2" ><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr bgcolor="<?=$Clr2 ?>">
                                <td width="32%" align="left" valign="top" style="padding-top:4px;"><strong>&nbsp;Description:</strong></td>
                                <td width="68%" align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_desc" cols="40" rows="6" id="seo_desc"></textarea>
                                </span></td>
                              </tr>
                              <tr bgcolor="<?=$Clr2 ?>">
                                <td align="left" valign="top" style="padding-top:4px;"><span class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></span></td>
                                <td align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"></textarea>
                                </span></td>
                              </tr>
                            </table></td>
                                  </tr>           
                          <?php } ?>   
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/add_item.jpg" width="76" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" class="norm1"><strong><a href="main-sections.php" class="managem">Top</a> 
                       &raquo; <a href="mmainsections.php?lvl=<?=$lvl?>" class="managem"><?=parent_name($lvl)?></a>
                       <? if ($SecID==0){?>
&raquo; <a href="javascript:;" class="managem">                        
					   <? }else{
					   ?>
                        &raquo; <a href="msections.php?lvl=<?=$lvl?>&MSecID=<?=$MSecID?>" class="managem"> 
                        <? } ?>
                        <?=$MSecName?>
                        </a> </strong>
                        <?if($SecID<>0 && $SecID<>''){?>
                        &raquo; <a href="javascript:;" class="managem"> 
                        <?=$SecName?>
                        </a> 
                        <?}?>
                        <?if($MainID<>0 && $MainID<>''){?>
                        &raquo; <a href="javascript:;" class="managem"> 
                        <?=$MainName?>
                        </a> 
                        <?}?>
                        <?if($SubID<>0 && $SubID<>''){?>
                        &raquo; 
                        <?=$SubName?>
                        <?}?>
                        </td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><a href="" name="rank"></a><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table width="539" border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="41" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">ItemID</strong></td>
                            <td width="200" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Name</strong></td>
          <td width="59" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Gallery</strong></td>
                            <!--td width="59" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Discount</strong></td-->
                            <td width="39" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Featured</strong></td>
                            <td width="39" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">New</strong></td>
                            <td height="20" colspan="3" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
//	$rs=mysql_fetch_array($qry);
	if(!($data[7]=='')){
		$Lnk=$data[7];
	}else{
		$Lnk='&nbsp;';
	}
	if($data[9]=='y'){
		$sOption="Enabled";
	}elseif($data[9]=='n'){
		$sOption="Disabled";
	}
?>
                          <tr align="center"> 
  <td bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[5]);?></td>
                              <td align="left" valign="middle" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[6]);?></td>

                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><a href="productsgallery.php?id=<? echo($data[5]);?>" class="CPname">Edit</a></td>
                            <!--td width="59" height="20" bgcolor="<?=$Clr3 ?>"><a href="view_discount.php?id=<? echo($data[5]);?>&pname=<?=urlencode($data[6])?>" class="CPname">View</a></td-->                            
                            <form name="frmupdf<? echo($i);?>" method="post" action="updisfeatured.php?lvl=<?=$lvl?>">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="ItmID" value="<? echo($data[5]);?>">
       <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="isFea" type="text" class="txtnorm1" value="<?=$data[18]?>" size="1"></td>
						    </form>                              
                            
                            <form name="frmupd<? echo($i);?>" method="post" action="updisnew.php?lvl=<?=$lvl?>">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="ItmID" value="<? echo($data[5]);?>">
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="isNew" type="text" class="txtnorm1" value="<?=$data[15]?>" size="1"></td>
						    </form
                            ><form name="frmupd<? echo($i);?>" method="post" action="edititem.php?lvl=<?=$lvl?>">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="ItmID" value="<? echo($data[5]);?>">
                              <td width="63" bgcolor="<?=$Clr3 ?>"><input type="image" src="img/edit.jpg" width="43" height="24"></td>
                            </form>
                            <form id="frmRank<? echo($i);?>" name="frmRank<? echo($i);?>" method="post" action="itmrank.php?lvl=<?=$lvl?>" onSubmit="return checklrForm<? echo($i);?>()">
                            <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="ItmID" value="<? echo($data[5]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[12]);?>">
                              <input type="hidden" id = "M1" name="M1" value="<? echo($data[1]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="20"><!--select class="txtnorm1" style="width:36px;" id="txtrank6" name="txtrank6" onChange="javascript:document.frmRank<? echo($i);?>.submit();">
                              	<? for ($x=1;$x<=$rows;$x++){?>
                              	<option value="<?=$x?>" <? if ($x==$i){ echo " Selected";}?>><?=$x?></option>
                                <? }?>  
                                </select-->                              
<input name="txtrank" type="text" class="txtnorm1" id="txtrank" value="<?=$data[12]?>" size="6" style="width:40px;text-align:center;"></td>
                            </form>
                            <form name="form1" method="post" action="delitm.php?lvl=<?=$lvl?>" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MainID" value="<? echo($data[3]);?>">
                              <input type="hidden" name="SubID" value="<? echo($data[4]);?>">
                              <input type="hidden" name="ItmID" value="<? echo($data[5]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="59"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>