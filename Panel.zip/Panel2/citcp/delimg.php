<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$ItmID=$_REQUEST["ImgID"];
$imgdel="";
if($_REQUEST["ImgID"]){
	$qry=mysql_query("select img from tbl_gallery where ImgID='".$ItmID."'") or die("Invalid Values: " . mysql_error());
		if($qry){
			$rows=mysql_num_rows($qry);
			if($rows>0){
				$data=mysql_fetch_row($qry);
				$imgdel=$bimgs.$data[0];
			}
		}
	$qry=mysql_query("delete from tbl_gallery where ImgID='".$ItmID."'") or die("Invalid Values: " . mysql_error());
		if($qry){
		
			if (file_exists($imgdel)){
				unlink($imgdel);
			}
		}
}
header('Location:mgallery.php?MSecID='.$MSecID.'&mess=Image+deleted+successfully');
?>