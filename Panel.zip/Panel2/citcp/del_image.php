<?
require("connection.php");
include("chksession.php");
$id = $_REQUEST['id'];
$rid = $_REQUEST['rid'];
$sql = "SELECT * FROM tbl_prd_gallery WHERE image_id = ".$rid."";
$qry = mysql_query($sql);
$fld = mysql_fetch_array($qry);
if (file_exists($itmimgs.$fld['file1'])){
	unlink($itmimgs.$fld['file1']);
}
if (file_exists($itmimgs.$fld['file2'])){
	unlink($itmimgs.$fld['file2']);
}
$sql = "DELETE FROM tbl_prd_gallery WHERE image_id = ".$rid."";
mysql_query($sql);
mysql_free_result($qry);
header("location:productsgallery.php?id=$id");
exit;
?>