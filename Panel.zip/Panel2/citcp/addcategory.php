<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainName=$_REQUEST["MainName"];
$bFile = $_FILES["bFile"]["name"];
$img="";
if($MainName<>""){

$qryMainID=mysql_query("select MainID from tbl_main order by MainID desc") or die("Invalid Values: " . mysql_error());
if($qryMainID){
	$rows=mysql_num_rows($qryMainID);
	if($rows>0){
		$data=mysql_fetch_row($qryMainID);
		$MainID=$data[0]+1;
	}else{
		$MainID=1001;
	}
}
if (!($bFile=='')){
$img = "main_".$MainID.".jpg";
}
$qryRank=mysql_query("select rank from tbl_main where MSecID='".$MSecID."' and SecID='".$SecID."' order by rank desc") or die("Invalid Values: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}
$qry=mysql_query("insert into tbl_main(MSecID,SecID,MainID,MainName,MainImg,Rank) values('".$MSecID."','".$SecID."','".$MainID."','".$MainName."','".$img."','".$Rank."')") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$mainimgs.$img);
}
}
}
header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID.'&mess=Main+Category+added+successfully');
?>