<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$ImgName=$_REQUEST["ImgName"];
$bFile = $_FILES["bFile"]["name"];
$img="";
if($ImgName<>""){
$qryItmID=mysql_query("select imgID from tbl_secgallery order by imgID desc") or die("Invalid Values: " . mysql_error());
if($qryItmID){
	$rows=mysql_num_rows($qryItmID);
	if($rows>0){
		$data=mysql_fetch_row($qryItmID);
		$ItmID=$data[0]+1;
	}else{
		$ItmID=1;
	}
}
if (!($bFile=='')){
$img = "img_".$MSecID."_".$ItmID.".jpg";
}
$qry=mysql_query("insert into tbl_secgallery(MSecID,imgID,imgname,img) values('".$MSecID."','".$ItmID."','".$ImgName."','".$img."')") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$bsecimgs.$img);
}
}
}
header('Location:msecgallery.php?MSecID='.$MSecID.'&mess=Item+added+successfully');
?>