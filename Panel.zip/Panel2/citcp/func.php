<?php
function month_name($mm,$full_name){	
	if ($full_name==true){
		$retrun = array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
	}else{
		$retrun = array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
	}
	return $retrun[$mm];
}
function dynamics_title($id){
	$sql = "SELECT title FROM tbl_general WHERE row_id= ".$id."";
	$qry = mysql_query($sql);
	$fld = mysql_fetch_array($qry);		
	mysql_free_result($qry);
	return $fld[0]."";
}
function terminal_name($termial_zip){
	$sql = "SELECT title FROM tbl_general WHERE extra1= '".trim($termial_zip)."'";
	$qry = mysql_query($sql);
	$fld = mysql_fetch_array($qry);		
	mysql_free_result($qry);
	return $fld[0]."";
}
?>