<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubID=$_REQUEST["SubID"];
$ItmID=$_REQUEST["ItmID"];
$ID=$_REQUEST["ID"];
if($_REQUEST["ID"]){
$qry=mysql_query("delete from tbl_psizes where recid='".$ID."'") or die("Invalid Values: " . mysql_error());
}
header('Location:misizes.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID.'&SubID='.$SubID.'&ItmID='.$ItmID.'&mess=Size+deleted+successfully');
?>