<?
require("connection.php");
require("chksession.php");
$recid = $_REQUEST['RecID'];
if($_REQUEST["MSecID"]){
$qrychk=mysql_query("SELECT * FROM tbl_section WHERE MSecID=".$_REQUEST["MSecID"]." and parent = ".$lvl." ") or die(mysql_error());
if(mysql_num_rows($qrychk)>0){
	header('location:mmainsections.php?lvl=$lvl&mess=This+Main+Section+has+section+delete+them+first');
}else{
	$qry=mysql_query("DELETE FROM tbl_mainsection WHERE MSecID=".$_REQUEST["MSecID"]." AND RecID = ".$recid."") or exit("Invalid Values: " . mysql_error());
//	$qryRank=mysql_query("select * from tbl_mainsection where parent = ".$lvl." order by rank") or die("Invalid Sql: " . mysql_error());
//		if($qryRank){
//			$rows=mysql_num_rows($qryRank);
//				if($rows>0){
//					for($i=1;$i<=$rows;$i++){
//						$data=mysql_fetch_row($qryRank);
//						$qry=mysql_query("update tbl_mainsection set Rank='".$i."' where MSecID='".$data[1]."'") or die("Invalid Values: " . mysql_error());
//					}
//				}
//		}
	}
header("location:mmainsections.php?lvl=".$lvl."");
}
?>