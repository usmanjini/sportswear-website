<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$SecName=$_REQUEST["SecName"];
$soption=$_REQUEST["soption"];
$bFile = $_FILES["bFile"]["name"];
$img="";
//if (!($bFile=='')){
$img = "sec_".$MSecID."_".$SecID.".jpg";
//}
if (file_exists($secimgs.$img) || $bFile<>''){
$img = $img;
}else{
$img = '';
}
if($SecID<>""){
$qry=mysql_query("update tbl_section set SecName='".$SecName."',SecImg='".$img."',soption='".$soption."',seo_desc = '".$_REQUEST['seo_desc']."',seo_keyword = '".$_REQUEST['seo_keywords']."' where SecID='".$SecID."'") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
$img = "sec_".$MSecID."_".$SecID.".jpg";
move_uploaded_file($_FILES['bFile']['tmp_name'],$secimgs.$img);
}
}
}
header("location:msections.php?lvl=".$lvl."&MSecID=".$MSecID."&mess=".$m3."+updated+successfully");
?>