<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
$colorno=$_REQUEST["colorno"];
if($SecName<>""){

	$qry=mysql_query("UPDATE tbl_size SET size_name = '".$SecName."' WHERE size_id = ".$colorno."") or die("Invalid Values: " . mysql_error());
}
header('Location:viewsizes.php');
?>