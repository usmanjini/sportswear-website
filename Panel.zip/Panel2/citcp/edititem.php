<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$MSecID=$_REQUEST['MSecID'];
$SecID=$_REQUEST['SecID'];
$MainID=$_REQUEST['MainID'];
$SubID=$_REQUEST['SubID'];
$ItmID=$_REQUEST['ItmID'];
if(!$ItmID==''){
	$qry=mysql_query("select ItmName,ItmImg,soption,ItmDescp,ArtNo,pType,pSize,ItmlImg,pAuth,ItmxlImg,team_id,seo_desc,seo_keywords from tbl_items where ItmID='".$ItmID."' and MainID='".$MainID."' and SecID='".$SecID."' and MSecID='".$MSecID."'") or die("Invalid SQL ".mysql_error());
	if($qry){
		$rows=mysql_num_rows($qry);
		if($rows>0){
			$data=mysql_fetch_row($qry);
			$ItmName=$data[0];
			$ItmDescp=$data[3];
			$fbImg=$data[1];
			$bImg=$itmimgs.$data[1];
			$fbImg2=$data[7];
			$bImg2=$itmimgs.$data[7];
			$soption=$data[2];
			$ArtNo=$data[4];
			$pType=$data[5];
			$pSize=$data[6];
			$pAuth=$data[8];
			$fbImg3=$data[9];
			$bImg3=$itmimgs.$data[9];	
			$team_id = $data[10];
			$seo_desc = $data[11];
			$seo_keyword = $data[12];
		}
	}
}
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">

<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><? include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="85%" border="1" cellpadding="0" cellspacing="0" bgcolor="<?=$Clr2 ?>" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Edit 
                              Item</td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="100%" border="0" cellpadding="1" cellspacing="2"><form action="upditm.php?lvl=<?=$lvl?>" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checkItmeForm();">
                                <input type="hidden" name="SecID" value="<?=$SecID ?>">
                                <input type="hidden" name="MSecID" value="<?=$MSecID ?>">
                                <input type="hidden" name="MainID" value="<?=$MainID ?>">
                                <input type="hidden" name="SubID" value="<?=$SubID ?>">
                                <input type="hidden" name="ItmID" value="<?=$ItmID ?>">
                                <tr> 
                                  <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Style#:</strong>                                  </td>
                                  <td valign="top" bgcolor="<?=$Clr2 ?>"><input name="ArtNo" type="text" class="txtdefault" id="ArtNo" value="<?=$ArtNo ?>"> 
                                    &nbsp;<font color="#FF0000">*</font></td>
                                </tr>
                                <tr> 
                                  <td width="31%" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;&nbsp;<strong>Name:</strong></td>
                                  <td width="69%" valign="top" bgcolor="<?=$Clr3 ?>" class="norm1"><input value="<?=$ItmName ?>" name="ItmName" type="text" class="txtdefault" id="ItmName3"> 
                                    &nbsp;<font color="#FF0000">*</font></td>
                                </tr>
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Team:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>">
                                    <select name="team_id" class="txtdromp_menu" id="team_id" style="width:130px;">
                                    	<option value="0">None</option>
<?php $qry3 = mysql_query("SELECT * FROM tbl_general WHERE parent_id = 3 ORDER BY ranking");
while ($fld=mysql_fetch_array($qry3)){
?>
                                    	<option value="<?=$fld["row_id"]?>" <?=($team_id==$fld["row_id"] ? " selected" : "")?>><?=$fld["title"]?></option>               
<?php
}
mysql_free_result($qry3);
?>                         
                                    </select>
                                    </td>
                                  </tr>                                      
                                <tr> 
                                  <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Color:</strong>                                  </td>
                                  <td valign="top" bgcolor="<?=$Clr2 ?>" class="error"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <? 
									$qry_ = mysql_query("SELECT * FROM tbl_color ORDER BY ColorId");
									while ($fld = mysql_fetch_array($qry_)){
										$qry_c = mysql_query("SELECT * FROM tbl_prods_color WHERE ColorId = ".$fld[0]." AND ItmId = ".$ItmID."");
										if (mysql_num_rows($qry_c)>0){
											$checked = " Checked";
										}else{	
											$checked = "";
										}
mysql_free_result($qry_c);
									?>
                                      <tr>
                                        <td width="8%" height="18" align="left"><input type="checkbox" value="y" id="color<?php echo $fld[0];?>" name="color<?php echo $fld[0];?>" <?=$checked?>></td>
                                        <td width="92%" align="left"><label for="color<?php echo $fld[0];?>"><strong><?php echo $fld[1];?></strong></label></td>
                                      </tr>
                                   <? }?>   
                                    </table></td>
                                </tr>
                                <tr> 
                                  <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Sizes:</strong></td>
                                  <td valign="top" bgcolor="<?=$Clr2 ?>" class="error"><table width="100%" border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td width="22" height="18" align="left" bgcolor="<?=$Clr1 ?>"></td>
                                      <td width="64" align="left" bgcolor="<?=$Clr1 ?>" class="shead">Size</td>
                                      <td width="77" align="left" bgcolor="<?=$Clr1 ?>"><strong class="shead">Price</strong></td>
                                      <td width="62" align="left" bgcolor="<?=$Clr1 ?>"><strong class="shead">Weigth</strong></td>
                                    </tr>
                                    <? 
									  
									$qry_ = mysql_query("SELECT * FROM tbl_size ORDER BY size_id");
									while ($fld = mysql_fetch_array($qry_)){								
$qry_c = mysql_query("SELECT * FROM tbl_prod_sizes WHERE size_id = ".$fld[0]." AND ItmId = ".$ItmID."");
										if (mysql_num_rows($qry_c)==0){
											$disable = " disabled=\"disabled\"";
											$price = 0;
											$weight = 0;
											$chk = "";
										}else{	
											$fld_s = mysql_fetch_array($qry_c);
											$price = $fld_s['price'];
											$weight = $fld_s['weight'];								
											$disable = "";
											$chk = " checked";
										}
mysql_free_result($qry_c);							

									?>
                                    <tr>
                                      <td width="22" height="18" align="left"><input type="checkbox" value="y" id="size<?php echo $fld[0];?>" name="size<?php echo $fld[0];?>"  onclick="javascript:if (size<?php echo $fld[0];?>.checked){getElementById('price<?php echo $fld[0];?>').disabled=false;getElementById('weight<?php echo $fld[0];?>').disabled=false;}else{getElementById('price<?php echo $fld[0];?>').disabled=true;getElementById('weight<?php echo $fld[0];?>').disabled=true;}" <?=$chk?>></td>
                                      <td width="64" align="left"><label for="size<?php echo $fld[0];?>"><strong><?php echo $fld[1];?></strong></label></td>
                                      <td width="77" align="left"><input type="text" class="txtdefault" name="price<?php echo $fld[0];?>" id="price<?php echo $fld[0];?>" value="<?=$price?>" size="6" maxlength="6" onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" style="width:40px;" <?=$disable?>></td>
                                      <td width="62" align="left"><input type="text" class="txtdefault" name="weight<?php echo $fld[0];?>" id="weight<?php echo $fld[0];?>" value="<?=$weight?>" size="6" maxlength="6" onKeyPress="&#10;&#9;&#9;&#9;return typedKeyAllowedForNumericTextBox(event);&#10;&#9;&#9;" <?=$disable?> style="width:40px;"></td>
                                    </tr>
                                    <? }?>
                                  </table></td>
                                </tr>
                                  <tr> 
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><strong>&nbsp;&nbsp;Short Detail:</strong> 
                                    </td>
                                    <td valign="top" bgcolor="<?=$Clr2 ?>"><input value="<?=$pAuth?>" name="pAuth" type="text" class="txtdefault" id="pAuth" style="width:270px;"></td>
                                  </tr>
                                <tr>
                                <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;&nbsp;<strong>Item 
                                  Description</strong></td>
                                <td bgcolor="<?=$Clr3 ?>"><textarea  style="width: 100%;" name="ItmDescp" cols="35" rows="4" class="ckeditor"  id="ItmDescp"><?=$ItmDescp?></textarea></td>
                                </tr>
                                <tr> 
                                  <td height="20" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Small 
                                    Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"> 
                                    <? if (file_exists($bImg) && $fbImg<>''){?>
                                    <img src="<?=$bImg ?>" width="100"> 
                                    <? }else{echo('&nbsp;No Image');}?>
                                    &nbsp;</td>
                                </tr>
                                <tr> 
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Re 
                                    Upload Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="bFile" type="file" class="txtfilefield1" id="bFile2">
                                    &nbsp;<font color="#FF0000">*&nbsp;300 x 
                                  300 px</font></td>
                                </tr>
                                <tr> 
                                  <td height="20" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Product 
                                    Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"> 
                                    <? if (file_exists($bImg2) && $fbImg2<>''){?>
                                    <img src="<?=$bImg2 ?>" width="150"> 
                                    <? }else{echo('&nbsp;No Image');}?>
                                    &nbsp;</td>
                                </tr>
                                <tr> 
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Re 
                                    Upload Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="bFile2" type="file" class="txtfilefield1" id="bFile2">
                                    &nbsp;<font color="#FF0000">*&nbsp;600 x 
                                  600 px</font></td>
                                </tr>
                                <tr>
                                	<td>&nbsp;</td>
                                    <td></td>
                                </tr>              
					<!--			<tr> 
                                  <td height="20" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Xtra Large 
                                    Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"> 
                                    <?// if (file_exists($bImg3) && $fbImg3<>''){?>
                                    <img src="<?=$bImg3 ?>" width="200"> 
                                    <?// }else{echo('&nbsp;No Image');}?>
                                    &nbsp;</td>
                                </tr>
                                <tr> 
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Re 
                                    Upload Image:</strong></td>
                                  <td bgcolor="<?=$Clr3 ?>" class="norm1"><input name="bFile3" type="file" class="txtfilefield1" id="bFile3"></td>
                                </tr>-->
                          <?php if ($seo==true){?>
                                  <tr> 
                                    <td height="23" align="center" colspan="2" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                                  </tr> 
                                  <tr> 
                                    <td height="23" align="center" colspan="2" ><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr bgcolor="<?=$Clr2 ?>">
                                <td width="32%" align="left" valign="top" style="padding-top:4px;"><strong>&nbsp;Description:</strong></td>
                                <td width="68%" align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_desc" cols="40" rows="6" id="seo_desc"><?=$seo_desc.""?></textarea>
                                </span></td>
                              </tr>
                              <tr bgcolor="<?=$Clr2 ?>">
                                <td align="left" valign="top" style="padding-top:4px;"><span class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></span></td>
                                <td align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"><?=$seo_keyword.""?></textarea>
                                </span></td>
                              </tr>
                            </table></td>
                                  </tr>           
                          <?php } ?>  
                                <tr> 
                                  <td bgcolor="<?=$Clr3 ?>">&nbsp;</td>
                                  <td bgcolor="<?=$Clr3 ?>"><input type="image" src="img/update_item.jpg" width="90" height="24"></td>
                                </tr></form>
                            </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>