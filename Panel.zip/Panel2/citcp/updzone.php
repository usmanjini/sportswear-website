<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
if($SecName<>""){
	$sql = "UPDATE tbl_zones SET zone_name = '".$SecName."' WHERE zone_id = ".$_REQUEST['zone_id']."";
	$qry=mysql_query($sql) or die("Invalid Values: " . mysql_error());
}
header('Location:viewzones.php');
?>