<?
require("connection.php");
require("chksession.php");
$SecName=$_REQUEST["SecName"];
if($SecName<>""){
	$qry=mysql_query("INSERT INTO tbl_zones(zone_name) VALUES ('".$SecName."')") or die("Invalid Values: " . mysql_error());
}
header('Location:viewzones.php');
?>