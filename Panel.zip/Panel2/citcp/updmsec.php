<?
require("connection.php");
require("chksession.php");
if($_REQUEST["SecName"]){
$qry=mysql_query("UPDATE tbl_mainsection SET MSecName='".$_REQUEST["SecName"]."',sshow='".$_REQUEST["show"]."' WHERE RecID='".$_REQUEST["RecID"]."' AND parent <> 0") or die("Invalid Values: " . mysql_error());
}
header("location:mmainsections.php?lvl=".$lvl."");
?>