<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$opra = $_REQUEST["opra"]."";
$price = $_REQUEST["price"]."";
$qty = $_REQUEST["qty"]."";
$zone_id = $_REQUEST["zone_id"]."";
$sql = "INSERT tbl_rates (zone_id,weight_size,operator,price) VALUES (".$zone_id.",".$qty.",'".$opra."',".$price.")";
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>