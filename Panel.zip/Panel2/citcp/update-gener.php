<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
?>
<?php
if (isset($_POST['ids'])){
	
	$title = htmlspecialchars($_REQUEST['title'])."";
	$link = htmlspecialchars($_REQUEST['link'])."";	
	$detail1 = htmlspecialchars($_REQUEST['detail1'])."";	
	$detail2 = htmlspecialchars($_REQUEST['pdetail'])."";
	
	$gen_id = $_REQUEST['row_id']."";
	
	$file1 = $_FILES['file1']["name"];
	$file2 = $_FILES['file2']["name"];
	$file3 = $_FILES['file3']["name"];
	$file4 = $_FILES['file4']["name"];
	
	
	$file11 = $filname1."_a".$gen_id."".$filext1;
	$file22 = $filname2."_b".$gen_id."".$filext2;
	$file33 = $filname3."_c".$gen_id."".$filext3;
	$file44 = $filname4."_d".$gen_id."".$filext4;

	if (trim($file1)!=""){
		@move_uploaded_file($_FILES['file1']['tmp_name'],$simgs."".$file11);
	}
	if (trim($file2)!=""){
		@move_uploaded_file($_FILES['file2']['tmp_name'],$simgs."".$file22);
	}
	if (trim($file3)!=""){
		@move_uploaded_file($_FILES['file3']['tmp_name'],$simgs."".$file33);
	}
	if (trim($file4)!=""){
		@move_uploaded_file($_FILES['file4']['tmp_name'],$simgs."".$file44);
	}	
	$qry = "UPDATE tbl_general SET title = '".$title."',detail_s='".$detail1."',detail_l='".$detail2."',link='".$link."' WHERE row_id = ".$gen_id."";
//	echo $qry;
//	exit;
	mysql_query($qry);
	header("location:view-general.php?id=$id");
	exit;
}
?>