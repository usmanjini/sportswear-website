<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$ItmID=$_REQUEST["imgID"];
$ItmName=$_REQUEST["ImgName"];
$bFile = $_FILES["bFile"]["name"];
//	if (!($bFile=='')){
	$img = "img_".$MSecID."_".$ItmID.".jpg";
//	}
	if($ItmID<>""){
		$qry=mysql_query("update tbl_secgallery set imgname='".$ItmName."',img='".$img."' where imgID='".$ItmID."' and MSecID='".$MSecID."'") or die("Invalid Values: " . mysql_error());
		if($qry){
			if (!($bFile=='')){
			$img = "img_".$MSecID."_".$ItmID.".jpg";
			move_uploaded_file($_FILES['bFile']['tmp_name'],$bsecimgs.$img);
			}
		}
	}
header('Location:msecgallery.php?MSecID='.$MSecID.'&mess=Item+updated+successfully');
?>