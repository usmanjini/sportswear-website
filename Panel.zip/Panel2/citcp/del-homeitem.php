<?
require("connection.php");
require("chksession.php");
$RecID = $_REQUEST['RecID'];
$type = htmlspecialchars($_REQUEST['type'])."";
	$query = "DELETE FROM tbl_homeitems WHERE RecID = ".$RecID."";
	mysql_query($query);

header("location:view-homeitems.php?type=".$type."&mess=Your+item+deleted+Sucessfully");
exit;
?>