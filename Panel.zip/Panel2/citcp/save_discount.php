<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$opra = $_REQUEST["opra"]."";
$price = $_REQUEST["price"]."";
$qty = $_REQUEST["qty1"]."";
$qty2 = $_REQUEST["qty2"]."";
$pid = $_REQUEST["pid"]."";
$sql = "INSERT tbl_discount(pid,qty,qty2,discount) VALUES (".$pid.",".$qty.",".$qty2.",".$price.")";
//echo $sql;
//exit;
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>