<link rel="stylesheet" type="text/css" href="styles.css">
<table width="755" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td height="25"><table width="755" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="18" height="25"><img src="img/m1.jpg" width="18" height="25"></td>
          <td height="25" background="img/m2.jpg">&nbsp;</td>
          <td width="90" height="25"><img src="img/m3.jpg" width="90" height="25"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="755" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="26" background="img/m4.jpg">&nbsp;</td>
          <td width="90" height="26"><img src="img/m5.jpg" width="90" height="26"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="755" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td background="img/m7.jpg"><img src="img/m6.jpg" width="346" height="25"></td>
          <td width="134"><img src="img/m8.jpg" width="134" height="25"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="755" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="27" height="21" background="img/m9.jpg">&nbsp;</td>
          <td height="21" background="img/m9.jpg" class="CName">
            <?=$Company?>
          </td>
          <td width="197" height="21"><img src="img/m10.jpg" width="197" height="21"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="755" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="27" height="29" background="img/m11.jpg">&nbsp;</td>
          <td height="29" valign="top" background="img/m11.jpg"><img src="img/m12.jpg" width="286" height="2"></td>
          <td width="197" height="29"><img src="img/m13.jpg" width="197" height="29"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="25"><table width="755" height="25" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="25" align="right" background="img/m14.jpg" class="lbtm"><table width="100%" height="25" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td height="8"><img src="../uploadsimg/spacer.gif" width="1" height="8"></td>
              </tr>
              <tr>
                <td height="17" align="right" valign="top" class="lbtm"><strong>
                  <?=date ("l dS F Y h:i:s A");?>
                  </strong></td>
              </tr>
            </table></td>
          <td width="39" height="25"><img src="img/m15.jpg" width="39" height="25"></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td height="1"><img src="img/spacer.gif" width="1" height="1"></td>
  </tr>
</table>
