<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
	$id = $_REQUEST["gen_id"];
	$detail = $_REQUEST["pdetail"];
	$sql = "UPDATE tbl_gen SET detail = '".$detail."',seo_desc='".$_REQUEST['seo_desc']."',seo_keywords ='".$_REQUEST['seo_keywords']."' WHERE gen_id=".$id.";";
	mysql_query($sql);
	header("location:general.php?id=$id");
?>