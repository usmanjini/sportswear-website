<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="96%" border="0" align="center">
                          <form action="sending.php" method="post" enctype="multipart/form-data" name="form1" onSubmit="">
                            <input type="hidden" name="hdnEmail" value="0">
                            <tr align="center" bgcolor="<?=$Clr1?>"> 
                              <td colspan="2" class="mhead">Send 
                                Email to Users</td>
                            </tr>
                            <tr> 
                              <td width="17%" align="right" bgcolor="<?=$Clr2 ?>" class="norm">From 
                                Name:&nbsp;&nbsp;</td>
                              <td width="83%" bgcolor="<?=$Clr2 ?>"><label> 
                                <input name="frmName" type="text" class="txtfilefield1" id="frmName" value="<?=$Company?>" size="45">
                                </label></td>
                            </tr>
                            <tr> 
                              <td align="right" bgcolor="<?=$Clr2 ?>" class="norm">From Email:&nbsp;</td>
                              <td bgcolor="<?=$Clr2 ?>"><input name="frmEmail" type="text" class="txtfilefield1" id="frmEmail" value="<?=$EmlTo?>" size="45"></td>
                            </tr>
                            <tr> 
                              <td align="right" valign="top" bgcolor="<?=$Clr2 ?>" class="norm">Subject:&nbsp;</td>
                              <td bgcolor="<?=$Clr2 ?>"><input name="EmlSubject" type="text" class="txtdefault" id="EmlSubject" size="45"></td>
                            </tr>
                            <tr> 
                              <td align="right" valign="top" bgcolor="<?=$Clr2 ?>" class="norm">Email 
                                Message:&nbsp;</td>
                              <td bgcolor="<?=$Clr2 ?>"><textarea name="txtMessage" cols="80" rows="15" class="txtnews2" id="txtMessage"></textarea></td>
                            </tr>
                            <tr> 
                              <td align="right" bgcolor="<?=$Clr2 ?>"><label></label></td>
                              <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/btn_smail.jpg" width="79" height="24"></td>
                            </tr>
                          </form>
                        </table>
                        
                      </td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>