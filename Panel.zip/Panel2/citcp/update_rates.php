<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$rate_id = $_REQUEST["rate_id"]."";
$sql = "UPDATE tbl_rates SET weight_size = ".$_REQUEST['qty'].", operator = '".$_REQUEST['opra']."', price = ".$_REQUEST['price']." WHERE rates_id = ".$rate_id."";
//echo $sql;
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>