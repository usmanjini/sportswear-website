<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<!--<script src="ckeditor.js"></script>
	<link rel="stylesheet" href="sample.css">
    	<script>

		var editor;

		// The instanceReady event is fired, when an instance of CKEditor has finished
		// its initialization.
		CKEDITOR.on( 'instanceReady', function( ev ) {
			editor = ev.editor;

			// Show this "on" button.
			document.getElementById( 'readOnlyOn' ).style.display = '';

			// Event fired when the readOnly property changes.
			editor.on( 'readOnly', function() {
				document.getElementById( 'readOnlyOn' ).style.display = this.readOnly ? 'none' : '';
				document.getElementById( 'readOnlyOff' ).style.display = this.readOnly ? '' : 'none';
			});
		});

		function toggleReadOnly( isReadOnly ) {
			// Change the read-only state of the editor.
			// http://docs.ckeditor.com/#!/api/CKEDITOR.editor-method-setReadOnly
			editor.setReadOnly( isReadOnly );
		}

	</script>-->
</head>
<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="90%" border="1" cellpadding="0" cellspacing="0" bordercolor="<?=$Clr1 ?>">
<form name="form1" id="form1" method="post" action="save_gen.php">
<input type="hidden" value="<?=$_REQUEST["id"]?>" id="gen_id" name="gen_id">
                      <?
					  	$sql = "SELECT * FROM tbl_gen WHERE gen_id = ".$_REQUEST["id"].";";
						$qry = mysql_query($sql);
						while ($fld = mysql_fetch_array($qry)){
							$enrish = $fld["enrish"];
                      ?>
                      
                          <tr> 
                            <td height="23" align="center" bgcolor="<?=$Clr1 ?>" class="mhead"><?=$fld["title"].""?></td>
                          </tr>
                          <? if ($enrish==1){?>
<!--<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg.js"></script> 
<script language="JavaScript" type="text/javascript" src="scripts/wysiwyg-settings.js"></script>
<script language="JavaScript">WYSIWYG.attach('pdetail');</script>   -->                  
                          <tr> 
<td height="20" align="left" valign="top" bgcolor="<?=$Clr3?>" class="menu"><textarea class="ckeditor" cols="80" id="editor1" name="pdetail" rows="10"><?=$fld["detail"].""?></textarea></td>
                          </tr>              
                          <? }else{?>            
                          <tr> 
                            <td height="20" align="left" valign="top" bgcolor="<?=$Clr3?>" class="menu"><input name="pdetail" type="text" class="txt_id_sub" value="<?=$fld["detail"].""?>" size="80" maxlength="150"/></td>
                          </tr>
                          <? } ?>
                          <?php if ($seo==true){?>
                          <tr> 
                            <td height="23" align="center" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                          </tr> 
                          <tr> 
                            <td height="23" align="center" ><table width="100%" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td width="32%" align="left" valign="top" style="padding-top:4px;"><strong>&nbsp;Description:</strong></td>
                                <td width="68%" align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_desc" cols="40" rows="6" id="seo_desc"><?=$fld["seo_desc"].""?></textarea>
                                </span></td>
                              </tr>
                              <tr>
                                <td align="left" valign="top" style="padding-top:4px;"><span class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></span></td>
                                <td align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"><?=$fld["seo_keywords"].""?></textarea>
                                </span></td>
                              </tr>
                            </table></td>
                          </tr>           
                          <?php } ?>                                           
                          <tr> 
                            <td height="30" align="left" valign="middle"><input type="submit" value="Save <?=$fld["title"].""?>"></td>
                          </tr>
                      <?
					  }
                      ?>
                      </form>    
                        </table></td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>