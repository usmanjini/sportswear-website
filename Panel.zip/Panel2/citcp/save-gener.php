<?php
require("connection.php");
include("chksession.php");
include("fclr.inc");
include("general_sets.php");
?>
<?php
if (isset($_POST['ids'])){
	
	$title = htmlspecialchars($_REQUEST['title'])."";
	$link = htmlspecialchars($_REQUEST['link'])."";	
	$detail1 = htmlspecialchars($_REQUEST['detail1'])."";	
	$detail2 = htmlspecialchars($_REQUEST['pdetail'])."";
	
	$qry = mysql_query("SELECT * FROM tbl_general ORDER BY row_id DESC");
	if (mysql_num_rows($qry)==0){
		$gen_id = 1;
	}else{
		$fld = mysql_fetch_array($qry);
		$gen_id = $fld['row_id']+1;
	}
	mysql_free_result($qry);
	
	$file1 = $_FILES['file1']["name"];
	$file2 = $_FILES['file2']["name"];
	$file3 = $_FILES['file3']["name"];
	$file4 = $_FILES['file4']["name"];
	
	
	$file11 = $filname1."_a".$gen_id."".$filext1;
	$file22 = $filname2."_b".$gen_id."".$filext2;
	$file33 = $filname3."_c".$gen_id."".$filext3;
	$file44 = $filname4."_d".$gen_id."".$filext4;

	if (trim($file1)!=""){
		@move_uploaded_file($_FILES['file1']['tmp_name'],$simgs."".$file11);
	}
	if (trim($file2)!=""){
		@move_uploaded_file($_FILES['file2']['tmp_name'],$simgs."".$file22);
	}
	if (trim($file3)!=""){
		@move_uploaded_file($_FILES['file3']['tmp_name'],$simgs."".$file33);
	}
	if (trim($file4)!=""){
		@move_uploaded_file($_FILES['file4']['tmp_name'],$simgs."".$file44);
	}	
	$qry = "INSERT INTO tbl_general (parent_id,ranking,title,detail_s,detail_l,link,file1,file2,file3,file4) VALUES (".$id.",1000,'".$title."','".$detail1."','".$detail2."','".$link."','".$file11."','".$file22."','".$file33."','".$file44."')";
	mysql_query($qry);
	header("location:view-general.php?id=$id");
	exit;
}
?>