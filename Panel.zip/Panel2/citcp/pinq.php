<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body onLoad="javascript:window.print();" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="575" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="<?=$Clr1 ?>">
  <tr> 
    <td height="23" align="center" class="menu"><h2><?=$Company?></h2></td>
  </tr>
  <tr> 
    <td height="20" class="menu">&nbsp;</td>
  </tr>
  <tr> 
    <td align="center" valign="top"><table width="98%" border="0" cellspacing="0" cellpadding="0">
        <?
			$qrycust=mysql_query("select * from tbl_inqcust where Login='".$_REQUEST["InqID"]."'") or die(mysql_error());
			if(mysql_num_rows($qrycust)>0){
			$rs=mysql_fetch_array($qrycust);
		?>
        <tr> 
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td width="14%" class="heds_links"><strong>Inquiry ID</strong></td>
                <td width="27%" class="norm"> 
                  <?=$_REQUEST["InqID"]?>
                </td>
                <td width="15%" class="heds_links"><strong>Inquiry Date</strong></td>
                <td width="44%" class="norm"> 
                  <?=$rs["date"]?>
                </td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td height="6"><img src="imgs/spacer.gif" width="1" height="6"></td>
        </tr>
        <tr> 
          <td height="1" bgcolor="606060"><img src="imgs/spacer.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td height="6"><img src="imgs/spacer.gif" width="1" height="6"></td>
        </tr>
        <tr> 
          <td class="heds_links"><strong>Customer Information</strong></td>
        </tr>
        <tr> 
          <td> <table width="100%" border="0" cellpadding="0" cellspacing="0" class="norm">
              <tr> 
                <td width="16%">Full Name</td>
                <td width="84%"> 
                  <?=$rs['fname']?>
                </td>
              </tr>
              <tr> 
                <td>Company </td>
                <td> 
                  <?=$rs["company"]?>
                </td>
              </tr>
              <tr> 
                <td>Phone </td>
                <td> 
                  <?=$rs["ph"]?>
                </td>
              </tr>
              <!--tr> 
                <td>Fax</td>
                <td> 
                  <?=$rs["fax"]?>
                </td>
              </tr-->
              <tr> 
                <td>Email </td>
                <td> 
                  <?=$rs["email"]?>
                </td>
              </tr>
              <!--tr> 
                <td>URL</td>
                <td> 
                  <?=$rs["url"]?>
                </td>
              </tr-->
              <tr> 
                <td>Address </td>
                <td> 
                  <?=$rs["address"]?>
                </td>
              </tr>
              <!--tr> 
                <td>City</td>
                <td> 
                  <?=$rs["city"]?>
                </td>
              </tr>
              <tr> 
                <td>Zip</td>
                <td> 
                  <?=$rs["zip"]?>
                </td>
              </tr>
              <tr> 
                <td>State</td>
                <td> 
                  <?=$rs["cstate"]?>
                </td>
              </tr-->
              <tr> 
                <td>Country</td>
                <td> 
                  <?=$rs["Country"]?>
                </td>
              </tr>
              <!--tr> 
                <td>Inquiry Type</td>
                <td> 
                  <?=$rs["interestedin"]?>
                </td>
              </tr>
              <tr> 
                <td>Business Type</td>
                <td> 
                  <?=$rs["bussiness"]?>
                </td>
              </tr-->
              <tr> 
                <td>Comments </td>
                <td> 
                  <?=$rs["comments"]?>
                </td>
              </tr>
            </table></td>
        </tr>
        <?
								}
		?>
        <tr> 
          <td><img src="imgs/spacer.gif" width="1" height="15"></td>
        </tr>
        <tr> 
          <td height="1" bgcolor="606060" class="shead"><img src="imgs/spacer.gif" width="1" height="1"></td>
        </tr>
        <tr> 
          <td height="6" class="shead"><img src="imgs/spacer.gif" width="1" height="6"></td>
        </tr>
        <tr> 
          <td class="heds_links"><strong>Inquiry Detail</strong></td>
        </tr>
        <tr> 
          <td height="6"><img src="imgs/spacer.gif" width="1" height="6"></td>
        </tr>
        <?
			$qryprd=mysql_query("select * from tbl_basket where inquiry_no='".$_REQUEST["InqID"]."'") or die(mysql_error());
			if(mysql_num_rows($qryprd)>0){
		?>
        <tr> 
          <td align="center"><table width="100%" border="1" cellpadding="1" cellspacing="2" bordercolor="#666666">
              <tr class="heds_links"> 
                <td width="297" height="20">Product Description</td>
                <td width="94" height="20" align="center">Image</td>
                <td width="55" height="20" align="center">Qty</td>
              </tr>
              <?
			  $tqty=0;
				while($rs=mysql_fetch_array($qryprd)){
									$tqty=$tqty+$rs["qty"];
									$qryprd1=mysql_query("select * from tbl_items where ItmID='".$rs["product_id"]."'") or die(mysql_error());
									$rs1=mysql_fetch_array($qryprd1);
								?>
              <tr> 
                <td align="center" valign="top"> 
                  <table width="98%" border="0" cellpadding="0" cellspacing="0" class="norm">
                    <tr> 
                      <td height="18"><strong> 
                                                <?=$rs1["ArtNo"]?><br><?=$rs1["ItmName"]?>
                                                </strong><br/>Size: <?=$rs["size_name"]?><br/>Color: <?=$rs["color_name"]?></td>
                    </tr>
                    <?
														if($rs["pType"]<>''){
													?>
                    <?
														}
													?>
                    <tr> 
                      <td height="18"> 
                        <?=nl2br(substr(str_replace("#","",$rs1["ItmDescp"]),0,100))?>
                        ... </td>
                    </tr>
                </table></td>
                <td width="94" align="center">
<table width="70" border="1" cellpadding="0" cellspacing="0" bordercolor="#999999" style="border-collapse:collapse;">
                    <tr> 
                      <td><img src="<?=$itmimgs.$rs1["ItmlImg"]?>" width="70"></td>
                    </tr>
                  </table>
                  
                </td>
                <td align="center" class="norm"> 
                  <?=$rs["qty"]?>
                </td>
              </tr>
              <?
									  }
								?>
              <tr valign="middle"> 
                <td height="20" colspan="2" align="right" class="norm1"><strong>Total 
                  Quantity&nbsp; </strong></td>
                <td height="20" align="center" class="norm1"><strong> 
                  <?=$tqty?>
                  </strong></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td align="center">&nbsp;</td>
        </tr>
        <?
								}
		?>
      </table></td>
  </tr>
</table>
</body>
</html>
