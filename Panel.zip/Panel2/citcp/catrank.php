<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["MSecID"];
$SecID = $_REQUEST["SecID"];
$MainID = $_REQUEST["MainID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
if($_REQUEST["MainID"]){

	$query = "select * from tbl_main where rank='".$Newrank."' and MSecID='".$MSecID."' and SecID='".$SecID."'";
	$open = mysql_query($query);
	if ($open){
		$rows = mysql_num_rows($open);
		if ($rows>0){
			$frows = mysql_fetch_row($open);
			$GetMainId = $frows[3];
				$Query = "Update tbl_main set rank='".$Newrank."' where MainID='".$MainID."' and MSecID='".$MSecID."' and SecID='".$SecID."'";
				$open = mysql_query($Query);
	
				$Query = "Update tbl_main set rank='".$Oldrank."' where MainID='".$GetMainId."' and MSecID='".$MSecID."' and SecID='".$SecID."'";
				$open = mysql_query($Query);
		}
	}

}
header('Location:mcategories.php?MSecID='.$MSecID.'&SecID='.$SecID);
?>