<?
require("connection.php");
require("chksession.php");
$imgLoc=$_REQUEST["imgLoc"];
$ImgName=$_REQUEST["ImgName"];
$bFile = $_FILES["bFile"]["name"];
$img="";
if($ImgName<>""){
$qryItmID=mysql_query("select recid from tbl_gallery order by recid desc") or die("Invalid Values: " . mysql_error());
if($qryItmID){
	$rows=mysql_num_rows($qryItmID);
	if($rows>0){
		$data=mysql_fetch_row($qryItmID);
		$ItmID=$data[0]+1;
	}else{
		$ItmID=1;
	}
	echo($ItmID);
}
if (!($bFile=='')){
$img = "img_".$ItmID.".jpg";
}
$qry=mysql_query("insert into tbl_gallery(imgLoc,imgID,imgname,img) values('".$imgLoc."','".$ItmID."','".$ImgName."','".$img."')") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$bimgs.$img);
}
}
}
header('Location:mgallery.php?mess=Item+added+successfully');
?>