<?
require("connection.php");
require("chksession.php");
$row_id = $_REQUEST['row_id'];
$id = $_REQUEST['id'];
$qry  = mysql_query("SELECT * FROM tbl_general WHERE row_id = ".$row_id."");
while ($fld=mysql_fetch_array($qry)){
	$file1 = $simgs."../uploads/".$fld["file1"]."";
	$file2 = $simgs."../uploads/".$fld["file2"]."";
	$file3 = $simgs."../uploads/".$fld["file3"]."";
	$file4 = $simgs."../uploads/".$fld["file4"]."";
	if (file_exists($file1)){
		unlink($file1);
	}
	if (file_exists($file2)){
		unlink($file2);
	}
	if (file_exists($file3)){
		unlink($file3);
	}
	if (file_exists($file4)){
		unlink($file4);
	}
	$query = "DELETE FROM tbl_general WHERE row_id = ".$row_id."";
	mysql_query($query);
}
mysql_free_result($qry);
header("location:view-general.php?id=$id");
exit;
?>