<?
require("connection.php");
require("chksession.php");
echo $type = htmlspecialchars($_REQUEST['type'])."";
echo  $RecID = htmlspecialchars($_REQUEST['RecID'])."";	
echo $ranking = htmlspecialchars($_REQUEST['ranking'])."";	

	
				$Query = "UPDATE tbl_homeitems SET ranking = ".$ranking." WHERE RecID = ".$RecID."";
//				echo $Query;
				$q2 = mysql_query($Query);
	
header("location:view-homeitems.php?type=".$type."&mess=Rank+updated+Sucessfully");
?>