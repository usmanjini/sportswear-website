<? if ($seo==true){?>
<tr> 
<td height="25" colspan="2" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">SEO Handling</td>
</tr>                                
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Title:</strong></td>
    <td><input name="seo_title" type="text" class="txtdefault" id="seo_title" value="<?=$s1?>"></td>
</tr>
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Description:</strong></td>
    <td><textarea name="seo_desc" cols="35" rows="4" class="txtnews1" id="seo_desc"><?=$s2?>
    </textarea></td>
</tr>
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Subject:</strong></td>
    <td><input name="seo_subject" type="text" class="txtdefault" id="seo_subject" value="<?=$s3?>"></td>
</tr>
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Author:</strong></td>
    <td><input name="seo_author" type="text" class="txtdefault" id="seo_author" value="<?=$s4?>"></td>
</tr>
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Design:</strong></td>
    <td><input name="seo_design" type="text" class="txtdefault" id="seo_design" value="<?=$s5?>"></td>
</tr>
<tr>
  <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;<strong>&nbsp;Developed:</strong></td>
    <td><input name="seo_developed" type="text" class="txtdefault" id="seo_developed" value="<?=$s6?>"></td>
</tr>
<? } ?>