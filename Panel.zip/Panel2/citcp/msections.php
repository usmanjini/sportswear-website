<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$MSecID=$_REQUEST['MSecID'];

$SQL = "select * from tbl_section where MSecID = ".$MSecID." order by rank";

$qry = mysql_query($SQL);
$x=1;
while ($fld=mysql_fetch_array($qry)){
	//mysql_query("UPDATE tbl_section SET rank = ".$x." WHERE RecID = ".$fld["RecID"]." and parent = ".$lvl." ");
	$x++;
}
mysql_free_result($qry);

$qry=mysql_query("select * from tbl_mainsection where MSecID = ".$MSecID."") or die("Invalid MSecID ".mysql_error());
if($qry){
$rows=mysql_num_rows($qry);
	if($rows>0){
		$data=mysql_fetch_row($qry);
		$MSecName=$data[2];
	}
}
mysql_free_result($qry);

$qry = mysql_query($SQL);
if (mysql_num_rows($qry)>0){
	$sect = true;
}else{
	$sect = false;
}
mysql_free_result($qry);
?>
<html>
<head>
<title><?=$CpTitle?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="styles.css">
<? require("scripts.php");?>
<script language="javascript">
	function onload(){
		document.getElementById('SecName').focus();
	}
</script>
</head>

<body bgcolor="EBEBEB" leftmargin="0" topmargin="0"  bgproperties="fixed" marginwidth="0" marginheight="0" onFocus="onload()">
<table width="775" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="7" height="100%" align="center" valign="top"><table width="7" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="7" height="25"><img src="img/mlshade1.jpg" width="7" height="25"></td>
        </tr>
        <tr>
          <td width="7" height="100%" background="img/mlshade.jpg"><img src="img/spacer.gif" width="1" height="1"></td>
        </tr>
      </table></td>
    <td width="755" height="100%" align="center" valign="top"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td height="152" valign="top"><?include("top.php");?></td>
        </tr>
        <tr>
          <td height="100%"><table width="755" height="100%" border="0" cellpadding="0" cellspacing="0">
              <tr> 
                <td width="177" align="center" valign="top" bgcolor="E8EEF3" class="menuclr"><?include("menu.php");?></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1" bgcolor="BFD0DF"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="1"><img src="img/spacer.gif" width="1" height="1"></td>
                <td width="575" align="center" valign="top"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <?
						if(isset($_REQUEST["mess"])){
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center"><strong>
                        <?=$_REQUEST["mess"]?>
                        </strong></td>
                    </tr>
                    <?
						}
					?>
                    <tr> 
                      <td align="center">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td align="center" valign="top"><table width="450" border="1" cellspacing="0" cellpadding="0" style="border-size:1px;border-color:<?=$Clr1 ?>;border-collepse:collepse">
                          <tr> 
                            <td height="25" align="center" valign="top" bgcolor="<?=$Clr1 ?>" class="mhead">Manage <?=$m3?></td>
                          </tr>
                          <tr> 
                            <td valign="top"><table width="450" border="0" cellpadding="1" cellspacing="2">
                                <form action="addsection.php?lvl=<?=$lvl?>" method="post" enctype="multipart/form-data" name="frmnews" onSubmit="return checksecForm();">
                                  <input type="hidden" name="MSecID" value="<?=$MSecID?>">
                                  <tr> 
                                    <td width="29%" valign="top" bgcolor="<?=$Clr2 ?>">&nbsp;&nbsp;<strong>Name:</strong></td>
                                    <td width="71%" valign="top" bgcolor="<?=$Clr2 ?>"><input name="SecName" type="text" class="txtdefault" id="SecName2">
                                      &nbsp;<font color="#FF0000">*</font></td>
                                  </tr>
                                  <!--tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;<strong>&nbsp;Image:</strong></td>
                                    <td bgcolor="<?=$Clr2 ?>"><input name="bFile" type="file" class="txtfilefield1" id="bFile"></td>
                                  </tr-->
                          <?php if ($seo==true){?>
                                  <tr> 
                                    <td height="23" align="center" colspan="2" bgcolor="<?=$Clr1 ?>" class="mhead">Meta Tags</td>
                                  </tr> 
                                  <tr> 
                                    <td height="23" align="center" colspan="2" ><table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr bgcolor="<?=$Clr2 ?>">
                                <td width="32%" align="left" valign="top" style="padding-top:4px;"><strong>&nbsp;Description:</strong></td>
                                <td width="68%" align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_desc" cols="40" rows="6" id="seo_desc"></textarea>
                                </span></td>
                              </tr>
                              <tr bgcolor="<?=$Clr2 ?>">
                                <td align="left" valign="top" style="padding-top:4px;"><span class="norm1">&nbsp;<strong>Keywords<strong>:</strong></strong></span></td>
                                <td align="left" valign="top"><span class="norm1">
                                  <textarea name="seo_keywords" cols="40" rows="6" id="seo_keywords"></textarea>
                                </span></td>
                              </tr>
                            </table></td>
                                  </tr>           
                          <?php } ?> 
                                  <tr> 
                                    <td bgcolor="<?=$Clr2 ?>">&nbsp;</td>
                                    <td bgcolor="<?=$Clr2 ?>"><input type="image" src="img/add_section.jpg" width="91" height="24"></td>
                                  </tr>
                                </form>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <tr> 
                      <td align="center" class="norm1"><strong><a href="main-sections.php" class="managem">Top</a> 
                        &raquo; <a href="mmainsections.php?lvl=<?=$lvl?>"  class="managem"> <?=parent_name($lvl)?></a>  
                      </strong>&raquo; <?=$MSecName?></td>
                    </tr>
                    <? if ($sect==false){?>
                    <tr> 
                      <td height="20" align="right" class="norm1" style="padding-right:30px;"><a href="mitem.php?lvl=<?=$lvl?>&MSecID=<?=$MSecID?>&SecID=0&MainID=0&SubID=0" class="managem"><strong>Add Item</strong></a></td>
                    </tr>                
                    <? } ?>    
                    <tr> 
                      <td height="15" align="center"><img src="imgs/spacer.GIF" width="1" height="15"></td>
                    </tr>
                    <?
$qry=mysql_query($SQL) or die("Invalid Query ".mysql_error());
if($qry){
$rows = mysql_num_rows($qry);
if($rows>0){
?>
                    <tr> 
                      <td align="center" valign="top"><table border="1" cellpadding="3" cellspacing="0" bordercolor="<?=$Clr1 ?>">
                          <tr align="center"> 
                            <td width="40" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">SecID</strong></td>
                            <td width="200" height="20" bgcolor="<?=$Clr1 ?>"><strong class="shead">Name</strong></td>
                            <td height="20" colspan="8" bgcolor="<?=$Clr1 ?>"><strong class="shead">Actions</strong></td>
                          </tr>
                          <?
	for($i=1;$i<=$rows;$i++){
	$data=mysql_fetch_row($qry);
	if(!($data[4]=='')){
		$Lnk=$data[4];
	}else{
		$Lnk='&nbsp;';
	}
	if($data[9]=='y'){
		$sOption="Enabled";
	}elseif($data[9]=='n'){
		$sOption="Disabled";
	}
	if($data[7]=='y'){
		$sshow="Yes";
	}elseif($data[7]=='n'){
		$sshow="No";
	}
?>
                          <tr align="center"> 
                            <form name="frmupd<? echo($i);?>" method="post" action="editsection.php?lvl=<?=$lvl?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <td bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[2]);?></td>
                              <td align="left" valign="middle" bgcolor="<?=$Clr3 ?>" class="norm1"><? echo($data[3]);?>                              </td>
                              <td bgcolor="<?=$Clr3 ?>" width="12"><input type="image" src="img/edit.jpg" width="43" height="24"></td>
                            </form>
							<?
								$qrypChk=mysql_query("select * from tbl_items where MSecID='".$MSecID."' and SecID='".$data[2]."' and MainID='0' and SubID='0'") or die("Invalid Query ".mysql_error());
								if(mysql_num_rows($qrypChk)>0){
							?>
                            <!--td width="200" bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;</td-->
							<?
								}else{
							?>
                            <!--td width="125" bgcolor="<?=$Clr3 ?>" class="norm1"><a href="mcategories.php?MSecID=<?=$MSecID?>&SecID=<?=$data[2]?>" class="managem"><strong>Manage 
                              Categories</strong></a></td-->
                            <?
								}
					  $cRow=0;
					  	$qryChk=mysql_query("select * from tbl_main where MSecID='".$MSecID."' and SecID='".$data[2]."'") or die("Invalid Query ".mysql_error());
						if($qryChk){
							$cRow=mysql_num_rows($qryChk);
							if($cRow>0){
					  ?>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;</td>
                            <?
					  		}else{
								if($data[4]<>''){
						?>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1">&nbsp;</td>
                            <?
								}else{
						?>
                            <td bgcolor="<?=$Clr3 ?>" class="norm1"><a href="mitem.php?lvl=<?=$lvl?>&MSecID=<?=$MSecID?>&SecID=<?=$data[2]?>&MainID=0&SubID=0" class="managem"><strong>Items</strong></a></td>
                            <?	
								}
							}
							$cRow=0;
					  	}
						mysql_free_result($qryChk);
					  ?>
                            <form name="frmRank<? echo($i);?>" method="post" action="secrank.php?lvl=<?=$lvl?>" onSubmit="return checklrForm<? echo($i);?>()">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <input type="hidden" name="oldrank" value="<? echo($data[10]);?>">
                              <input type="hidden" name="RecID" value="<? echo($data[0]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="10"><!--select class="txtnorm1" style="width:46px;" id="txtrank" name="txtrank" onChange="javascript:document.frmRank<? echo($i);?>.submit();">
                              	<? for ($x=1;$x<=$rows;$x++){?>
                              	<option value="<?=$x?>" <? if ($x==$i){ echo " Selected";}?>><?=$x?></option>
                                <? }?>  
                                </select-->
                                <input name="txtrank" type="text" class="txtnorm1" id="txtrank" value="<?=$data[10]?>" size="6" style="width:40px;text-align:center;">
                              </td>
                            </form>
                            <form name="form1" method="post" action="delsection.php?lvl=<?=$lvl?>" onSubmit="javascript:if(confirm('Are You Sure you want to delete')) return true; else return false">
                              <input type="hidden" name="MSecID" value="<? echo($data[1]);?>">
                              <input type="hidden" name="SecID" value="<? echo($data[2]);?>">
                              <td bgcolor="<?=$Clr3 ?>" width="10"><input type="image" src="img/delete.jpg" width="59" height="24"></td>
                            </form>
                          </tr>
                          <?
	}
?>
                        </table></td>
                    </tr>
                    <tr>
                      <td align="center" valign="top">&nbsp;</td>
                    </tr>
                    <?
}
}
?>
                  </table></td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td height="29"><?include("btm.php");?></td>
        </tr>
      </table> </td>
    <td width="13" height="100%" align="center" valign="top"><table width="13" height="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="13" height="25"><img src="img/mrshadet.jpg" width="13" height="25"></td>
        </tr>
        <tr>
          <td width="13" height="100%" background="img/mrshade.jpg"><img src="img/spacer.gif" width="13" height="1"></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>