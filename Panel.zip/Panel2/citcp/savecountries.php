<?
require("connection.php");
include("chksession.php");
include("fclr.inc");
$zone_id = $_REQUEST["zone_id"]."";
$id = $_REQUEST["id"]."";
$sql = "UPDATE tbl_zone_countries SET zone_id = ".$zone_id." WHERE id = ".$id.";";
mysql_query($sql);
$page = $_SESSION["bpage"]."";
header("location:$page");
?>