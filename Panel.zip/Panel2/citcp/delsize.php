<?
require("connection.php");
require("chksession.php");
$size_id = $_REQUEST["size_id"];

if($size_id<>""){
	$qry=mysql_query("DELETE FROM tbl_size WHERE size_id = ".$size_id."") or die("Invalid Values: " . mysql_error());
}
header('Location:viewsizes.php');
?>