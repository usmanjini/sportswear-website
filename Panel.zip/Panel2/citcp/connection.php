<?php error_reporting(E_ALL ^ E_NOTICE);



	ob_start();

	session_start();

	

	$uIp = $HTTP_SERVER_VARS["REMOTE_ADDR"];

	$uBsr = $HTTP_SERVER_VARS["HTTP_USER_AGENT"];

	$crntPage = $HTTP_SERVER_VARS["SCRIPT_NAME"];

	if(isset($HTTP_SERVER_VARS['HTTP_REFERRER'])){

		$Referrer = $HTTP_SERVER_VARS['HTTP_REFERRER'];

	}else{

		$Referrer = "http://loviaal.com/";

	}

//	$Referrer = ""



	$sId = session_id();

	$Company="Loviaal";

	$CpTitle="Loviaal - Administrator Control Panel";

	$owner = "Jini Tech";

$owner_email = "mailto:info@loviaal.com?subject=Feedback for Loviaal";

	//$owner_email = "info@jinitech.com";

	$FSTitle="Loviaal";

	$EmlTo="info@loviaal.com";

	

	$img1="img/ms2.jpg";

	$img2="img/mmid.jpg";

	$myURL="http://loviaal.com/";



	$simgs="../uploads/";

	$defimg="8883/";

	$bimgs=$simgs."banner/";

	$bimgs1=$defimg.$simgs."banner/";

	$bsecimgs=$simgs."secbanner/";

	$bsecimgs1=$defimg.$simgs."secbanner/";

	$secimgs=$simgs."secimgs/";

	$secimgs1=$defimg.$simgs."secimgs/";

	$mainimgs=$simgs."mainimgs/";

	$mainimgs1=$defimg.$simgs."mainimgs/";

	$subimgs=$simgs."subimgs/";

	$subimgs1=$defimg.$simgs."subimgs/";

	$itmimgs=$simgs."itmimgs/";

	$itmimgs1=$defimg.$simgs."itmimgs/";

	$seo = true;

	



	$host = "localhost";

	$user = "loviaaluzz_admin";

	$password = "zSK55hmSL8b7ykA";

	$db = "loviaaluzz_db";	

	$connect = @mysql_connect($host, $user, $password);

	mysql_select_db($db);

	

	$cur = "$";

	function homeitem($itmid){

	$qry = mysql_query("SELECT * FROM tbl_items WHERE ItmID = $itmid");

	if (mysql_num_rows($qry)){

		$fld = mysql_fetch_array($qry);

		$return = $fld["ItmName"]." (".$fld["ArtNo"].")";

	}else{

		$return = "";

	}

	mysql_free_result($qry);

	return $return;

}
	function itemSize($itmid){
	$qry = mysql_query("SELECT * FROM tbl_size WHERE size_id = $itmid");
	if (mysql_num_rows($qry)){
		$fld = mysql_fetch_array($qry);
		$return = $fld["size_name"];
	}else{
		$return = "";
	}
	mysql_free_result($qry);
	return $return;
}

function itemColor($itmid){
	$qry = mysql_query("SELECT * FROM tbl_color WHERE ColorId = $itmid");
	if (mysql_num_rows($qry)){
		$fld = mysql_fetch_array($qry);
		$return = $fld["ColorName"];
	}else{
		$return = "";
	}
	mysql_free_result($qry);
	return $return;
}

?>