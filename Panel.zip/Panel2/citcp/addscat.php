<?
require("connection.php");
require("chksession.php");
$MSecID=$_REQUEST["MSecID"];
$SecID=$_REQUEST["SecID"];
$MainID=$_REQUEST["MainID"];
$SubName=$_REQUEST["SubName"];
$soption=$_REQUEST["soption"];
$bFile = $_FILES["bFile"]["name"];
$img="";
if($SubName<>""){

$qrySubID=mysql_query("select SubID from tbl_sub order by SubID desc") or die("Invalid Values: " . mysql_error());
if($qrySubID){
	$rows=mysql_num_rows($qrySubID);
	if($rows>0){
		$data=mysql_fetch_row($qrySubID);
		$SubID=$data[0]+1;
	}else{
		$SubID=10001;
	}
}
if (!($bFile=='')){
$img = "sub_".$SubID.".jpg";
}
$qryRank=mysql_query("select rank from tbl_sub where MSecID='".$MSecID."' and SecID='".$SecID."' and MainID='".$MainID."' order by rank desc") or die("Invalid Values: " . mysql_error());
if($qryRank){
	$rows=mysql_num_rows($qryRank);
	if($rows>0){
		$data=mysql_fetch_row($qryRank);
		$Rank=$data[0]+1;
	}else{
		$Rank=1;
	}
}
$qry=mysql_query("insert into tbl_sub(MSecID,SecID,MainID,SubID,SubName,soption,SubImg,Rank) values('".$MSecID."','".$SecID."','".$MainID."','".$SubID."','".$SubName."','".$soption."','".$img."','".$Rank."')") or die("Invalid Values: " . mysql_error());
if($qry){
if (!($bFile=='')){
move_uploaded_file($_FILES['bFile']['tmp_name'],$subimgs.$img);
}
}
}
header('Location:msubcats.php?MSecID='.$MSecID.'&SecID='.$SecID.'&MainID='.$MainID.'&mess=Sub+Category+added+successfully');
?>