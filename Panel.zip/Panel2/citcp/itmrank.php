<?
require("connection.php");
require("chksession.php");
$MSecID = $_REQUEST["M1"];
$SecID = $_REQUEST["SecID"];
$MainID = $_REQUEST["MainID"];
$SubID = $_REQUEST["SubID"];
$ItmID = $_REQUEST["ItmID"];
$Newrank = $_REQUEST["txtrank"];
$Oldrank = $_REQUEST["oldrank"];
$RecID = $_REQUEST["RecID"];
$Query1 = "Update tbl_items set rank=".$Newrank." where RecID = ".$RecID."";
$open = mysql_query($Query1);
//if($_REQUEST["ItmID"]){
//
//	$query = "select * from tbl_items where rank='".$Newrank."' and MSecID='".$MSecID."' and SecID='".$SecID."' and MainID='".$MainID."' and SubID='".$SubID."'";
//	$open = mysql_query($query);
//	if ($open){
//		$rows = mysql_num_rows($open);
//		if ($rows>0){
//			$frows = mysql_fetch_row($open);
//			$GetItmId = $frows[5];
//				$Query1 = "Update tbl_items set rank='".$Newrank."' where ItmID='".$ItmID."' and MSecID='".$MSecID."' and SecID='".$SecID."'";
////				echo $Query1;
//				$open = mysql_query($Query1);
//	
//				$Query2 = "Update tbl_items set rank='".$Oldrank."' where ItmID='".$GetItmId."' and MSecID='".$MSecID."' and SecID='".$SecID."'";
////				echo $Query1;
////				exit;
//				$open = mysql_query($Query2);
//		}
//	}
//
//}
header("location:mitem.php?lvl=".$lvl."&MSecID=".$MSecID."&SecID=".$SecID."&MainID=".$MainID."&SubID=".$SubID."#rank");
?>