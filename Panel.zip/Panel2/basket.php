<?php require_once("config.php");

$sql = $sqlBasket;
$qry2 = mysql_query($sql);
$rc = mysql_num_rows($qry2);
$Pagename = "Inquiry Basket";
$page_name= "Inquiry Basket | ".$web_title."";

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?=$page_name?></title>
    <meta name="description" content="">
   
    <!-- CSS 
    ========================= -->
    <?php include("css-inc.php");?>
 <script type="text/javascript" src="<?=$panel?>input_functions.js"></script>
<script language="javascript">
	function update_basket(rowid,key,basket_id){
		var qtyno = "qty"+basket_id;
		var qtybox = document.getElementById(qtyno);
		if (qtybox.value=="" || qtybox.value<=0){
			alert('Please enter quantity.');
			qtybox.focus();
			return false;
		}else{
			document.location.href='add_to_basket<?=$ext?>?id='+rowid+'&qty='+qtybox.value+'&key='+key+'&basket_id='+basket_id;
		}
	}
</script>
</head>

<body>

    <!--header area start-->
    <?php include("header-inc.php");?>
    <!--header area end-->
 <div class="breadcrumbs_area other_bread">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="<?=ROOT?>home">home</a></li>
                            <li>/</li>
                            <li><a href="javascript:;"><?=$Pagename?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
 
 
    
    
     <!--shopping cart area start -->
    <div class="shopping_cart_area">
        <div class="container">  
          <div class="row">
          
                						
							<? if ($rc>0){?>
            				
				
							<table class="table table-striped">
								<thead>
									<tr>
                                    <th>Image</th>
										<th>Description</th>
										<th>Quantity</th>
										<th>--</th>
										<th>  Action  </th>
									</tr>
								</thead>
								<tbody>
                                 <? while ($fld=mysql_fetch_array($qry2)){?>
									<tr>
										<td>
										
												<img src="<?=ROOT?>uploads/itmimgs/<?=$fld["ItmlImg"]?>" width="70" alt="<?=$fld["ItmName"].""?>-<?=$fld["ArtNo"].""?>" />
			
										</td>
                                        <td>
							
												
			
			<h5><?=$fld["ItmName"].""?></h5>
			<span><i>Art No :</i> <?=$fld["ArtNo"].""?></span>
			<span><i>Color :</i> <?=$fld["color_name"].""?></span>
            <span><i>Size :</i> <?=$fld["size_name"].""?></span>
						
									
										</td>
										
										<td>
											
								
                                            
                                                    <input style="width:100px;"  class="form-control" type="number"  name="qty<?=$fld["basket_id"]?>" id="qty<?=$fld["basket_id"]?>" value="<?=$fld["qty"]?>" onKeyPress="
			return typedKeyAllowedForNumericTextBox(event);
		"   />
								
										</td>
                                        <td> 	<div class="cart-btns">	        			<a class="btn btn-info"  style="background-color:
                                        #000;"href="javascript:;" onClick="return update_basket('<?=$fld["product_id"]?>','<?=$fld["size_id"]?>-<?=$fld["product_id"]?>-<?=$fld["price"]?>','<?=$fld["basket_id"]?>');">Update Cart</a></div></td>
										<td>
											
											<a class="btn btn-info" style="background-color:#000;" href="remove<?=$ext?>?rid=<?=$fld[0]?>&sd=<?=$sId?>" title=""><i class="fa fa-trash"></i></a>
										</td>
									</tr>
									   <? }?>
								</tbody>
							</table>
							<div  >
								<a class="btn btn-info" style="background-color:#000;margin-bottom:40px; margin-right:10px;" href="<?=$_SESSION["page"].""?>" title="">Continue Visiting Site</a>
							
								<a style="float:right; background-color:#000;" class="btn btn-info"  href="<?=ROOT?>finalize<?=$ext?>" title="">Proceed to Inquriy </a>
							</div><!-- Cart Buttons -->
						
                         <? }else{ ?>  
    
							<p align="center">Your Cart Is Empty</p>
							
					
                     
		<? }?>	
								
					
          </div>
        
        </div>     
    </div>
     <!--shopping cart area end -->
    

    <!--footer area start-->
    <?php include("footer-inc.php");?>
    <!--footer area end-->

<!-- JS
============================================ -->
<?php include("js-inc.php");?>


</body>

</html>